# **QUY TẮC PHÁT TRIỂN PHẦN MỀM (DEVELOPMENT & CODING GUIDELINES)**

## **DỰ ÁN: GYM CENTER MANAGEMENT SYSTEM (GCMS)**

Tài liệu này quy định các tiêu chuẩn làm việc nhóm về mặt quản lý mã nguồn (Git), coding convention (Java/JSP/Frontend) và quy trình phối hợp phát triển. Tất cả các thành viên trong dự án bắt buộc phải đọc kỹ và tuân thủ tuyệt đối các quy tắc dưới đây để đảm bảo chất lượng code ổn định và dễ bảo trì.

## **1\. QUY TẮC KHAI BÁO QUYỀN SỞ HỮU FILE (FILE OWNERSHIP COMMENT)**

Để thuận tiện cho việc theo dõi, hỗ trợ sửa lỗi và phân chia trách nhiệm, dự án áp dụng quy tắc: **Ai quản lý/lập trình file nào thì bắt buộc phải ghi thông tin tác giả ở đầu file đó.**

### **1.1. Đối với file Java (.java), JavaScript (.js), CSS (.css)**

Sử dụng khối chú thích Javadoc/Block Comment đặt ở vị trí dòng đầu tiên của file:  
`/**`  
 `* =========================================================================`  
 `* @file          : [Tên File, ví dụ: PtDashboardController.java]`  
 `* @description   : [Mô tả ngắn gọn chức năng của file, ví dụ: Quản lý các view điều phối của PT]`  
 `* @author        : [Tên Thành Viên - ví dụ: Nguyễn Văn A]`  
 `* @created       : [Ngày tạo file theo định dạng YYYY-MM-DD - ví dụ: 2026-05-28]`  
 `* @last_modified : [Ngày chỉnh sửa gần nhất - YYYY-MM-DD] bởi [Tên người chỉnh sửa]`  
 `* =========================================================================`  
 `*/`

### **1.2. Đối với file JSP (.jsp)**

Sử dụng khối chú thích của JSP đặt ở dòng đầu tiên của file (dưới chỉ thị Page directive nếu có):  
`<%--`   
  `=========================================================================`  
  `Document    : [Tên file - ví dụ: dashboard_footer.jsp]`  
  `Created on  : [Ngày tạo - YYYY-MM-DD]`  
  `Author      : [Tên Thành Viên]`  
  `Description : [Mô tả ngắn gọn chức năng]`  
  `=========================================================================`  
`--%>`

### **1.3. Đối với file XML (.xml) hoặc SQL (.sql)**

Sử dụng định dạng chú thích XML/SQL tương ứng:

* **XML:** \<\!-- Author: Nguyen Van A | Created: 2026-05-28 \--\> ở dòng đầu tiên.  
* **SQL:** \-- Author: Nguyen Van A | Created: 2026-05-28 ở đầu script.

## **2\. QUY TẮC COMMIT GIT (GIT COMMIT CONVENTIONS)**

Dự án áp dụng chuẩn **Conventional Commits** để tự động hóa quá trình sinh log và giữ cho lịch sử commit luôn rõ ràng, dễ tra cứu.

### **2.1. Cấu trúc Message Commit**

`<type>(<scope>): <chủ đề commit viết bằng tiếng Việt không dấu hoặc có dấu nhưng ngắn gọn>`

### **2.2. Các loại Commit Type chính (\<type\>)**

| Type | Ý nghĩa | Ví dụ   |
| :---- | :---- | :---- |
| **feat** | Thêm tính năng mới (Feature) cho hệ thống | feat(auth): tich hop trang login demo |
| **fix** | Sửa lỗi (Bug fix) | fix(equipment): sua loi hien thi trang thai thiet bi |
| **docs** | Thay đổi tài liệu, ghi chú hoặc sơ đồ | docs(convention): tao file huong dan code cho nhom |
| **style** | Định dạng code (khoảng trắng, thụt lề, dấu chấm phẩy) \- *không làm thay đổi logic* | style(header): can chinh lai margin cho nut tim kiem |
| **refactor** | Tái cấu trúc code \- *không sửa lỗi cũng không thêm tính năng* | refactor(user): toi uu hoa vong lap tim kiem khach hang |
| **test** | Bổ sung hoặc sửa đổi các đoạn kiểm thử (Unit test, Integration test) | test(service): bo sung test case cho dang ky goi tap |
| **chore** | Cập nhật nhỏ liên quan tới build-tool, package dependencies hoặc file cấu hình | chore(git): cap nhat file .gitignore |

### **2.3. Quy định về phân nhánh (Branching Strategy)**

* Nhánh **main** (hoặc **master**): Nhánh chạy môi trường Production, hoạt động cực kỳ ổn định. Không commit trực tiếp lên nhánh này.  
* Nhánh **dev** (hoặc **develop**): Nhánh tích hợp mã nguồn chung của nhóm. Tất cả các tính năng sau khi test chạy ổn định sẽ merge vào đây.  
* Nhánh tính năng **feature/\<ten-tinh-nang\>** hoặc **dev/\<ten-thanh-vien\>/\<ten-tinh-nang\>**: Nhánh làm việc cá nhân. Từ nhánh cá nhân, thành viên sẽ tạo **Pull Request (PR)** để merge vào nhánh dev.

## **3\. CODING CONVENTIONS (QUY TẮC VIẾT MÃ NGUỒN)**

### **3.1. Quy tắc lập trình Java (Backend)**

* **Quy tắc đặt tên (Naming Conventions):**  
  * **Class & Interface:** Viết kiểu PascalCase (ví dụ: StaffDashboardController, EquipmentService).  
  * **Method & Variable:** Viết kiểu camelCase (ví dụ: getUserById(), activePtCount).  
  * **Hằng số (Constants):** Viết chữ IN HOA và phân cách bằng dấu gạch dưới UPPER\_SNAKE\_CASE (ví dụ: MAX\_UPLOAD\_SIZE, DEFAULT\_PAGE\_SIZE).  
  * **Package:** Viết chữ thường hoàn toàn, dùng dấu chấm phân cách (ví dụ: com.mycompany.gymcentermanagement.controller).  
* **Quy tắc viết code sạch (Clean Code):**  
  * **Độ dài hàm:** Mỗi hàm nên thực hiện **một nhiệm vụ duy nhất** (Single Responsibility) và độ dài không vượt quá 50 dòng code.  
  * **Độ lồng nhau (Nesting levels):** Tránh viết các vòng lặp hay cấu trúc điều kiện if-else lồng nhau quá 3 cấp. Hãy sử dụng **Guard Clauses (return sớm)** để giữ cho code thẳng hàng.  
  * **Xử lý ngoại lệ (Exception Handling):** Không bao giờ được bắt ngoại lệ rồi bỏ trống block catch (catch (Exception e) {}). Ít nhất phải ghi log lỗi (e.printStackTrace() hoặc log logger) để phục vụ debug.

### **3.2. Quy tắc lập trình JSP & Frontend**

* **Tối ưu hóa JSP:**  
  * Không viết code logic Java (scriptlet \<% ... %\>) trực tiếp trên file JSP.  
  * Sử dụng thẻ **JSTL** (\<c:if\>, \<c:forEach\>) và **Expression Language** (${user.name}) để xử lý hiển thị dữ liệu.  
* **HTML & CSS:**  
  * Thụt lề (Indentation): Sử dụng **4 spaces** (hoặc nhất quán tab tùy chỉnh) để căn chỉnh thụt lề, không pha trộn khoảng trắng và phím tab.  
  * Đặt tên Class CSS: Sử dụng định dạng kebab-case (ví dụ: .kpi-card, .btn-primary-custom).  
* **JavaScript:**  
  * Viết theo chuẩn ES6+. Sử dụng const cho các biến không thay đổi giá trị và let cho các biến thay đổi. Tránh tuyệt đối sử dụng var.  
  * Tên biến/hàm viết dạng camelCase.

## **4\. QUY TRÌNH HỢP NHẤT CODE (PULL REQUEST & CODE REVIEW)**

Để tránh xung đột code (Conflict) và lỗi không biên dịch được khi merge code chung:

1. **Pull Code Thường Xuyên:** Trước khi bắt đầu viết code mới hoặc trước khi push code lên Git, thành viên bắt buộc phải pull code mới nhất từ nhánh dev về để merge vào nhánh của mình.  
2. **Kiểm tra trên máy cá nhân (Local Build):** Bắt buộc phải chạy thử ứng dụng và biên dịch thành công (clean build bằng Maven) trên máy cá nhân trước khi push code lên repo.  
3. **Quy trình Code Review:**  
   * Mọi Pull Request muốn merge vào nhánh dev đều phải được review bởi ít nhất một thành viên khác trong nhóm.  
   * Chỉ khi được duyệt (Approve) và không có xung đột (No conflicts), PR mới được merge.