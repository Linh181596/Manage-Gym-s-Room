﻿# Danh sách các Thực thể (Business Entities)

Tài liệu này liệt kê các bảng đối tượng (Entity) cốt lõi ở tầng Business của hệ thống Gym Center Management, được trích xuất trực tiếp từ file `ScriptDatabase.sql`. Các bảng trung gian thuần túy (ví dụ: `UserRoles`, `NotificationRecipients`) được bỏ qua để giữ tính trọng tâm.
Khóa chính (Primary Key) được biểu thị bằng dấu <u>gạch chân</u>.

## 1. Phân hệ Quản lý Tài khoản & Hồ sơ (User & Profile Management)
| Tên Entity | Các Thuộc tính (Attributes) | Mô tả |
| :--- | :--- | :--- |
| **Users** | <u>UserID</u>, Email, PasswordHash, DisplayName, Phone, Status, MustChangePassword | Lưu trữ thông tin tài khoản cốt lõi, xác thực và trạng thái. |
| **Roles** | <u>RoleID</u>, RoleName, RoleLevel | Danh mục các vai trò (Admin, Staff, Member, PT). |
| **Members** | <u>MemberID</u>, Gender, DateOfBirth, Address, MembershipStatus | Hồ sơ chi tiết hội viên. |
| **Staffs** | <u>StaffID</u>, Position, Status | Hồ sơ nhân viên phòng tập. |
| **PersonalTrainers** | <u>PTID</u>, Specialization, Description, Status, CareerStartDate, CertificateFileName, CertificateFilePath, FullName, DisplayName, AvatarPath | Hồ sơ chi tiết của Huấn luyện viên cá nhân (PT). |
| **StaffPTAttendance** | <u>AttendanceID</u>, UserRole, CheckedInAt, CheckedOutAt, AttendanceDate, ShiftBlock, Status, Note | Lưu trữ dữ liệu chấm công cho Staff và PT. |

## 2. Phân hệ Quản lý Gói tập & Tài chính (Package & Payment Management)
| Tên Entity | Các Thuộc tính (Attributes) | Mô tả |
| :--- | :--- | :--- |
| **GymPackages** | <u>PackageID</u>, PackageName, DurationMonths, Price, Description, Status | Danh mục các gói tập (1 tháng, 1 năm...) |
| **MemberPackages** | <u>MemberPackageID</u>, StartDate, EndDate, Status | Ghi nhận việc hội viên sở hữu 1 gói tập cụ thể. |
| **Invoices** | <u>InvoiceID</u>, Amount, PaymentMethod, PaymentDate, Status | Hóa đơn thanh toán cho mua gói tập/thuê PT. |

## 3. Phân hệ Quản lý Dịch vụ PT (PT Services & Scheduling)
| Tên Entity | Các Thuộc tính (Attributes) | Mô tả |
| :--- | :--- | :--- |
| **PTPackageTypes** | <u>PTPackageTypeID</u>, PackageName, Description, DurationMonths, NumberOfSessions, Status | Danh mục các loại gói dịch vụ PT. |
| **PTServicePrices** | <u>PTServicePriceID</u>, Price, Status | Bảng định giá dịch vụ PT cụ thể theo từng huấn luyện viên. |
| **PTRegistrations** | <u>PTRegistrationID</u>, PreferredStartDate, StartDate, EndDate, Status, Note, TotalAmount, PaymentStatus, ProcessedAt | Ghi nhận đăng ký gói PT của hội viên. |
| **PTSchedules** | <u>PTScheduleID</u>, SessionDate, StartTime, EndTime, SessionStatus, PTAttendanceResult, Note | Lịch tập chi tiết cho từng buổi. |

## 4. Phân hệ Quản lý Thiết bị (Equipment Management)
| Tên Entity | Các Thuộc tính (Attributes) | Mô tả |
| :--- | :--- | :--- |
| **Equipments** | <u>EquipmentID</u>, EquipmentCode, EquipmentName, PurchaseDate, WarrantyDate, Location, ImageURL, Status, EquipmentType | Danh mục tài sản, thiết bị vật lý. |
| **EquipmentIssues** | <u>IssueID</u>, IssueType, Description, ReportedAt, Status, IssueImageURL | Ghi nhận các báo cáo sự cố thiết bị. |
| **MaintenanceSchedules** | <u>MaintenanceScheduleID</u>, ScheduledDate, MaintenanceType, Description, Status, CompletionDate, CompletionNote, CompletionImageURL, SubmittedForApprovalAt, SubmittedBy, RequestedIssueResolution, ApprovedBy, ApprovedAt, ApprovalNote | Lịch trình và phê duyệt nghiệm thu bảo trì thiết bị. |

## 5. Phân hệ Hệ thống & Tiện ích (System & Utilities)
| Tên Entity | Các Thuộc tính (Attributes) | Mô tả |
| :--- | :--- | :--- |
| **Notifications** | <u>NotificationID</u>, Title, Content, TargetRole, PublishDate, ExpiryDate, NotificationImageURL | Lưu trữ các thông báo hệ thống. |
| **PublicContents** | <u>ContentID</u>, Title, Summary, Body, ContentType, Category, ThumbnailURL, Status, PublishedAt | Quản lý nội dung công khai (Tin tức, Blog, Chính sách). |
| **User_Tokens** | <u>TokenID</u>, TokenValue, TokenType, CreatedAt, ExpiresAt, IsUsed | Lưu trữ token xác thực (VD: quên mật khẩu). |

---

## 6. Sơ đồ Quan hệ Thực thể (ERD Diagram - Tầng Business)
Sơ đồ dưới đây biểu thị trực quan mối quan hệ giữa các thực thể cốt lõi.

```mermaid
erDiagram
    Users ||--o| Members : "acts as"
    Users ||--o| Staffs : "acts as"
    Users ||--o| PersonalTrainers : "acts as"
    Users ||--o{ StaffPTAttendance : "clocks in"
    Roles ||--o{ Users : "assigned to"
    
    Members ||--o{ MemberPackages : "registers"
    GymPackages ||--o{ MemberPackages : "includes"
    
    PersonalTrainers ||--o{ PTServicePrices : "sets price for"
    PTPackageTypes ||--o{ PTServicePrices : "priced in"
    
    Members ||--o{ PTRegistrations : "books"
    PTServicePrices ||--o{ PTRegistrations : "applies"
    
    Members ||--o{ Invoices : "pays"
    Users ||--o{ Invoices : "processed by"
    MemberPackages ||--o| Invoices : "billed via"
    PTRegistrations ||--o| Invoices : "billed via"
    
    PTRegistrations ||--o{ PTSchedules : "divided into"
    PersonalTrainers ||--o{ PTSchedules : "teaches"
    Members ||--o{ PTSchedules : "attends"
    
    Equipments ||--o{ EquipmentIssues : "has"
    Users ||--o{ EquipmentIssues : "reported by"
    
    Equipments ||--o{ MaintenanceSchedules : "undergoes"
    EquipmentIssues ||--o| MaintenanceSchedules : "triggers"
    
    Users ||--o{ Notifications : "created by"
```
