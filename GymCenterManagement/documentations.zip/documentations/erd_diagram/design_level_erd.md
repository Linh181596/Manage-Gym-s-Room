# Thiết kế Cơ sở dữ liệu (Database Design ERD)

Tài liệu này liệt kê chi tiết toàn bộ các bảng trong CSDL thực tế, bao gồm cả bảng thực thể (Entities) và bảng quan hệ (Junction Tables).
Các trường Khóa chính (Primary Key) được đánh dấu `PK`.

### Bảng: **EquipmentIssues**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| IssueID | `int` | NOT NULL |
| EquipmentID | `int` | NOT NULL |
| ReportedBy | `int` | NOT NULL |
| IssueType | `nvarchar(100)` | NOT NULL |
| Description | `nvarchar(max)` | NULL |
| ReportedAt | `datetime2(7)` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |
| IssueImageURL | `varchar(255)` | NULL |

### Bảng: **Equipments**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| EquipmentID | `int` | NOT NULL |
| EquipmentCode | `varchar(50)` | NOT NULL |
| EquipmentName | `nvarchar(100)` | NOT NULL |
| PurchaseDate | `date` | NOT NULL |
| WarrantyDate | `date` | NULL |
| Location | `nvarchar(100)` | NULL |
| ImageURL | `varchar(255)` | NULL |
| Status | `varchar(50)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |
| EquipmentType | `nvarchar(50)` | NULL |

### Bảng: **GymPackages**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PackageID | `int` | NOT NULL |
| PackageName | `nvarchar(100)` | NOT NULL |
| DurationMonths | `int` | NOT NULL |
| Price | `decimal(12, 2)` | NOT NULL |
| Description | `nvarchar(max)` | NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **Invoices**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| InvoiceID | `int` | NOT NULL |
| MemberID | `int` | NOT NULL |
| ProcessBy | `int` | NOT NULL |
| MemberPackageID | `int` | NULL |
| PTRegistrationID | `int` | NULL |
| Amount | `decimal(12, 2)` | NOT NULL |
| PaymentMethod | `varchar(50)` | NOT NULL |
| PaymentDate | `datetime2(7)` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| TransactionData | `nvarchar(max)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **MemberPackages**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| MemberPackageID | `int` | NOT NULL |
| MemberID | `int` | NOT NULL |
| PackageID | `int` | NOT NULL |
| StartDate | `date` | NOT NULL |
| EndDate | `date` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **Members**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| MemberID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| Gender | `nvarchar(10)` | NULL |
| DateOfBirth | `date` | NULL |
| Address | `nvarchar(255)` | NULL |
| MembershipStatus | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **PublicContents**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| ContentID | `int` | NOT NULL |
| Title | `nvarchar(200)` | NOT NULL |
| Summary | `nvarchar(500)` | NULL |
| Body | `nvarchar(max)` | NOT NULL |
| ContentType | `varchar(20)` | NOT NULL |
| Category | `nvarchar(100)` | NULL |
| ThumbnailURL | `nvarchar(255)` | NULL |
| Status | `varchar(20)` | NOT NULL |
| PublishedAt | `datetime2(7)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedAt | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedAt | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **Notifications**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| NotificationID | `int` | NOT NULL |
| Title | `nvarchar(255)` | NOT NULL |
| Content | `nvarchar(max)` | NOT NULL |
| CreatedBy | `int` | NOT NULL |
| TargetRole | `varchar(50)` | NOT NULL |
| CreatedByRole | `nvarchar(50)` | NULL |
| PublishDate | `datetime2(7)` | NOT NULL |
| ExpiryDate | `datetime2(7)` | NULL |
| NotificationImageURL | `varchar(255)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **PersonalTrainers**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PTID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| Specialization | `nvarchar(255)` | NULL |
| Description | `nvarchar(max)` | NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |
| CareerStartDate | `date` | NOT NULL |
| CertificateFileName | `nvarchar(255)` | NULL |
| CertificateFilePath | `nvarchar(255)` | NULL |
| FullName | `nvarchar(100)` | NOT NULL |
| DisplayName | `nvarchar(100)` | NULL |
| AvatarPath | `nvarchar(255)` | NULL |

### Bảng: **PTPackageTypes**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PTPackageTypeID | `int` | NOT NULL |
| PackageName | `nvarchar(100)` | NOT NULL |
| Description | `nvarchar(max)` | NULL |
| DurationMonths | `int` | NOT NULL |
| NumberOfSessions | `int` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **PTRegistrations**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PTRegistrationID | `int` | NOT NULL |
| MemberID | `int` | NOT NULL |
| PTServicePriceID | `int` | NOT NULL |
| PreferredStartDate | `date` | NULL |
| StartDate | `date` | NULL |
| EndDate | `date` | NULL |
| Status | `varchar(20)` | NOT NULL |
| Note | `nvarchar(max)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |
| TotalAmount | `decimal(12, 2)` | NOT NULL |
| PaymentStatus | `varchar(20)` | NOT NULL |
| ProcessedByUserID | `int` | NULL |
| ProcessedAt | `datetime2(7)` | NULL |

### Bảng: **PTSchedules**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PTScheduleID | `int` | NOT NULL |
| PTRegistrationID | `int` | NOT NULL |
| PTID | `int` | NOT NULL |
| MemberID | `int` | NOT NULL |
| SessionDate | `date` | NOT NULL |
| StartTime | `time(7)` | NOT NULL |
| EndTime | `time(7)` | NOT NULL |
| SessionStatus | `varchar(20)` | NOT NULL |
| PTAttendanceResult | `varchar(20)` | NOT NULL |
| CreatedByUserID | `int` | NOT NULL |
| Note | `nvarchar(max)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **PTServicePrices**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| PTServicePriceID | `int` | NOT NULL |
| PTID | `int` | NOT NULL |
| PTPackageTypeID | `int` | NOT NULL |
| Price | `decimal(12, 2)` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **Roles**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| RoleID | `int` | NOT NULL |
| RoleName | `varchar(50)` | NOT NULL |
| RoleLevel | `int` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **Staffs**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| StaffID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| Position | `nvarchar(100)` | NULL |
| Status | `varchar(20)` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **StaffPTAttendance**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| AttendanceID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| UserRole | `varchar(20)` | NOT NULL |
| CheckedInAt | `datetime2(7)` | NOT NULL |
| CheckedOutAt | `datetime2(7)` | NULL |
| AttendanceDate | `Computed` | PERSISTED |
| ShiftBlock | `varchar(20)` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CheckedBy | `int` | NOT NULL |
| Note | `nvarchar(500)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **User_Tokens**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| TokenID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| TokenValue | `varchar(255)` | NOT NULL |
| TokenType | `varchar(50)` | NOT NULL |
| CreatedAt | `datetime2(7)` | NOT NULL |
| ExpiresAt | `datetime2(7)` | NOT NULL |
| IsUsed | `bit` | NOT NULL |

### Bảng: **UserRoles**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| UserID | `int` | NOT NULL |
| RoleID | `int` | NOT NULL |

### Bảng: **Users**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| UserID | `int` | NOT NULL |
| Email | `varchar(100)` | NOT NULL |
| PasswordHash | `varchar(255)` | NOT NULL |
| DisplayName | `nvarchar(100)` | NOT NULL |
| Phone | `varchar(10)` | NULL |
| Status | `varchar(20)` | NOT NULL |
| MustChangePassword | `bit` | NOT NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **MaintenanceSchedules**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| MaintenanceScheduleID | `int` | NOT NULL |
| EquipmentID | `int` | NOT NULL |
| IssueID | `int` | NULL |
| ScheduledDate | `date` | NOT NULL |
| MaintenanceType | `varchar(20)` | NOT NULL |
| Description | `nvarchar(max)` | NOT NULL |
| Status | `varchar(20)` | NOT NULL |
| CompletionDate | `datetime2(7)` | NULL |
| CompletionNote | `nvarchar(max)` | NULL |
| CompletionImageURL | `varchar(255)` | NULL |
| SubmittedForApprovalAt | `datetime2(7)` | NULL |
| SubmittedBy | `nvarchar(50)` | NULL |
| RequestedIssueResolution | `bit` | NOT NULL |
| ApprovedBy | `nvarchar(50)` | NULL |
| ApprovedAt | `datetime2(7)` | NULL |
| ApprovalNote | `nvarchar(max)` | NULL |
| CreatedBy | `nvarchar(50)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |
| UpdatedBy | `nvarchar(50)` | NULL |
| UpdatedDate | `datetime2(7)` | NULL |
| IsDeleted | `bit` | NOT NULL |

### Bảng: **NotificationRecipients**
| Tên cột (Column) | Kiểu dữ liệu (Data Type) | Ràng buộc (Constraint) |
| :--- | :--- | :--- |
| NotificationRecipientID | `int` | NOT NULL |
| NotificationID | `int` | NOT NULL |
| UserID | `int` | NOT NULL |
| IsRead | `bit` | NOT NULL |
| ReadAt | `datetime2(7)` | NULL |
| CreatedDate | `datetime2(7)` | NOT NULL |

---

## Sơ đồ Quan hệ Thực thể Chi tiết (Detailed ERD - Mermaid)
Sơ đồ dưới đây biểu thị mối quan hệ giữa **tất cả** các bảng trong CSDL (bao gồm cả bảng trung gian).

```mermaid
erDiagram
    Users ||--o{ UserRoles : "has"
    Roles ||--o{ UserRoles : "belongs to"
    
    Users ||--o{ User_Tokens : "generates"
    Users ||--o| Members : "acts as"
    Users ||--o| Staffs : "acts as"
    Users ||--o| PersonalTrainers : "acts as"
    Users ||--o{ StaffPTAttendance : "clocks in"
    
    Members ||--o{ MemberPackages : "registers"
    GymPackages ||--o{ MemberPackages : "includes"
    
    PersonalTrainers ||--o{ PTServicePrices : "sets price for"
    PTPackageTypes ||--o{ PTServicePrices : "priced in"
    
    Members ||--o{ PTRegistrations : "books"
    PTServicePrices ||--o{ PTRegistrations : "applies"
    
    Members ||--o{ Invoices : "pays"
    Users ||--o{ Invoices : "processed by"
    MemberPackages ||--o| Invoices : "billed via"
    PTRegistrations ||--o| Invoices : "billed via"
    
    PTRegistrations ||--o{ PTSchedules : "divided into"
    PersonalTrainers ||--o{ PTSchedules : "teaches"
    Members ||--o{ PTSchedules : "attends"
    
    Equipments ||--o{ EquipmentIssues : "has"
    Users ||--o{ EquipmentIssues : "reported by"
    
    Equipments ||--o{ MaintenanceSchedules : "undergoes"
    EquipmentIssues ||--o| MaintenanceSchedules : "triggers"
    
    Users ||--o{ Notifications : "created by"
    Notifications ||--o{ NotificationRecipients : "sent to"
    Users ||--o{ NotificationRecipients : "receives"
    
    Users ||--o{ PublicContents : "manages"
```
