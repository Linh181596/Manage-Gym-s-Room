SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ARITHABORT ON
GO
SET NUMERIC_ROUNDABORT OFF
GO

USE [GymCenterManagement]
GO

DECLARE @DemoNote nvarchar(500) = N'DEMO_ATTENDANCE_2026_07_01_TO_26';
DECLARE @StartDate date = CAST(N'2026-07-01' AS date);
DECLARE @EndDate date = CAST(N'2026-07-26' AS date);

;WITH DemoUsers AS
(
    SELECT v.UserID, v.UserRole, v.UserOffset
    FROM (VALUES
        (2, N'Staff', 0),
        (3, N'PT',    1),
        (5, N'PT',    2)
    ) v(UserID, UserRole, UserOffset)
    INNER JOIN dbo.Users u
        ON u.UserID = v.UserID
       AND u.IsDeleted = 0
),
DemoDates AS
(
    SELECT @StartDate AS WorkDate
    UNION ALL
    SELECT DATEADD(DAY, 1, WorkDate)
    FROM DemoDates
    WHERE WorkDate < @EndDate
),
DemoShifts AS
(
    SELECT *
    FROM (VALUES
        (N'Morning',   8 * 60,       12 * 60,      0),
        (N'Afternoon', 13 * 60 + 15, 16 * 60 + 45, 1),
        (N'Evening',   17 * 60,      20 * 60 + 30, 2)
    ) v(ShiftBlock, ShiftStartMinute, ShiftEndMinute, ShiftOffset)
),
DemoRows AS
(
    SELECT
        u.UserID,
        u.UserRole,
        d.WorkDate,
        s.ShiftBlock,
        s.ShiftStartMinute,
        s.ShiftEndMinute,
        (DATEDIFF(DAY, @StartDate, d.WorkDate) + u.UserOffset + (s.ShiftOffset * 2)) % 6 AS DemoPattern
    FROM DemoDates d
    CROSS JOIN DemoShifts s
    CROSS JOIN DemoUsers u
)
INSERT INTO dbo.StaffPTAttendance
    (UserID, UserRole, CheckedInAt, CheckedOutAt, ShiftBlock,
     Status, CheckedBy, Note, CreatedBy, CreatedDate,
     UpdatedBy, UpdatedDate, IsDeleted)
SELECT
    r.UserID,
    r.UserRole,
    DATEADD(MINUTE,
        r.ShiftStartMinute
        + CASE r.DemoPattern
            WHEN 1 THEN 10
            WHEN 3 THEN 10
            ELSE 2
          END,
        CAST(r.WorkDate AS datetime2)),
    CASE
        WHEN r.DemoPattern = 4 THEN NULL
        ELSE DATEADD(MINUTE,
            r.ShiftEndMinute
            + CASE r.DemoPattern
                WHEN 2 THEN -20
                WHEN 3 THEN -20
                ELSE 5
              END,
            CAST(r.WorkDate AS datetime2))
    END,
    r.ShiftBlock,
    N'Active',
    1,
    @DemoNote,
    N'Demo Admin',
    DATEADD(MINUTE,
        r.ShiftStartMinute
        + CASE r.DemoPattern
            WHEN 1 THEN 10
            WHEN 3 THEN 10
            ELSE 2
          END,
        CAST(r.WorkDate AS datetime2)),
    CASE WHEN r.DemoPattern = 4 THEN NULL ELSE N'1' END,
    CASE
        WHEN r.DemoPattern = 4 THEN NULL
        ELSE DATEADD(MINUTE,
            r.ShiftEndMinute
            + CASE r.DemoPattern
                WHEN 2 THEN -20
                WHEN 3 THEN -20
                ELSE 5
              END,
            CAST(r.WorkDate AS datetime2))
    END,
    0
FROM DemoRows r
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.StaffPTAttendance existing
    WHERE existing.UserID = r.UserID
      AND existing.UserRole = r.UserRole
      AND existing.AttendanceDate = r.WorkDate
      AND existing.ShiftBlock = r.ShiftBlock
      AND existing.IsDeleted = 0
)
OPTION (MAXRECURSION 100);
GO

SELECT
    UserID,
    UserRole,
    COUNT(*) AS DemoRecords,
    MIN(AttendanceDate) AS FromDate,
    MAX(AttendanceDate) AS ToDate
FROM dbo.StaffPTAttendance
WHERE Note = N'DEMO_ATTENDANCE_2026_07_01_TO_26'
GROUP BY UserID, UserRole
ORDER BY UserRole, UserID;
GO