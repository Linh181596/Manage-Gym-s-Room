# Checklist Kiểm Tra & Review Tài Liệu (SRS & SDS)

## I. Checklist Định Dạng Tài Liệu (Formatting)
- [ ] Tiêu mục (heading) và ảnh minh họa tương ứng nằm trên cùng một trang (không ngắt trang giữa chừng).
- [ ] Mục lục đã được format gọn gàng, không có các heading trống thừa thãi.
- [ ] Đánh số trang chính xác, liên tục.
- [ ] Đánh số mục chính xác, không trùng lặp (VD: không có 2 mục 2.1.20).
- [ ] Đánh số mục liên tục, không nhảy cóc (VD: có mục 4 rồi mới đến 4.1, 4.2).
- [ ] **TẤT CẢ** các hình vẽ, sơ đồ đều có caption theo chuẩn (VD: `Figure 1. Context diagram`).

## II. Checklist SRS (Software Requirements Specification)
### 1. Actor & Use Case (Tính Nhất Quán)
- [ ] Danh sách External Entity khớp với danh sách Actor trong Activity/Swimlane diagram.
- [ ] Danh sách Actor khớp với danh sách Actor trong đặc tả Use cases.
- [ ] Thống nhất tên gọi của các Actor ở toàn bộ tài liệu (đảm bảo không bị lọt các tên Actor từ dự án khác vào, các Actor chuẩn của Gym như Admin, Staff, Member, Personal Trainer... phải đồng nhất).
- [ ] **Số lượng Use case:** Khớp nhau giữa bảng Use case list (mục 1.3.2) và danh sách đặc tả chi tiết (mục 2.1).
- [ ] **Số lượng Use case:** Khớp với số lượng trong Use case diagram.
- [ ] **Tên Use case:** Tên trong bảng Use case list (1.3.2) KHỚP HOÀN TOÀN với tên trong Use case diagram.
- [ ] **Phân quyền (Authorization):** Phân quyền actor trong 1.3.2, 2.1, và trên sơ đồ phải KHỚP với bảng phân quyền màn hình.
- [ ] Tên gọi Use case trang chủ phải là `View Homepage` (không dùng `Home page`).
- [ ] Các bảng danh sách Use case đã đổi tên cột `Function` thành `Use case name`.

### 2. Đặc tả (Specification) & Diagram
- [ ] Use Case Diagram **KHỚP 100%** với Use Case Specification.
- [ ] Đặc tả viết bằng ngôn ngữ nghiệp vụ đơn giản, **KHÔNG** chứa code hay logic lập trình chi tiết.
- [ ] Các Swimlane/Activity diagram đều có mô tả các bước bằng **tiếng Việt** (bên dưới phần tiếng Anh).
- [ ] Cú pháp mô tả chuẩn: `Step X: S (actor/system) + V + O`.
- [ ] Có ghi chú tên tiếng Anh của actor bên cạnh tên tiếng Việt trong mô tả (VD: `Nhà tuyển dụng (Recruiter)`).
- [ ] Có chữ "**kết thúc**" rõ ràng ở bước cuối cùng của một chu trình/luồng.

### 3. Database Logic & Các yêu cầu khác
- [ ] Mô hình Logical ERD **KHÔNG** chứa khóa ngoại (FK).
- [ ] Có phần mô tả tiếng Việt cho Database Logic Diagram (ERD), giải thích rõ các mối quan hệ (1-n, 1-1, n-n) giữa các thực thể.
- [ ] Tài liệu đã cập nhật: Tách màn hình của Notification ra độc lập.
- [ ] Tài liệu đã cập nhật: Có tính năng/Use case "Lịch tự động hiển thị blog".

## III. Checklist SDS (Software Design Specification)
- [ ] Danh sách công nghệ ghi trong tài liệu khớp với công nghệ sử dụng trong source code.
- [ ] Package Diagram đầy đủ các lớp và khớp với code (Ví dụ: phải có package `impl` cho dao/service, hiển thị rõ số cấp phân chia).
- [ ] Class Diagram nhất quán với source code.
- [ ] Các mũi tên quan hệ trong Class Diagram (`import`, `implement`, `extend`...) trỏ ĐÚNG chiều theo nguyên tắc UML.
- [ ] Source code và tài liệu thiết kế tuân thủ đúng Coding Convention (quy tắc đặt tên, format code...).
