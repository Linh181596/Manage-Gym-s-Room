# Phân Tích Thiết Kế Kiến Trúc — GymCenterManagement

**Project:** Gym Center Management System (GCMS)  
**Framework:** Jakarta EE 10 (Servlet/JSP) trên Maven  
**Database:** Microsoft SQL Server  
**UI Template:** DashMin (Bootstrap 5 Admin Dashboard)

---

## 1. Tổng Quan Kiến Trúc

Project được thiết kế theo mô hình **3-Layer Architecture** (Controller → Service → DAO) kết hợp với **MVC Pattern** cho phần Presentation Layer.

```mermaid
flowchart TD
    classDef client fill:#e1f5fe,stroke:#039be5,stroke-width:2px;
    classDef container fill:#fff3e0,stroke:#ffb74d,stroke-width:2px;
    classDef layer fill:#f1f8e9,stroke:#8bc34a,stroke-width:2px;
    classDef db fill:#eceff1,stroke:#607d8b,stroke-width:2px;
    classDef util fill:#eceff1,stroke:#455a64,stroke-width:1px;

    Client["💻 CLIENT (Web Browser)<br/>HTML / CSS / JS / Bootstrap 5"]:::client

    subgraph Server["SERVLET CONTAINER (Tomcat/GlassFish)"]
        direction TB
        
        subgraph Filters["Filter Chain"]
            EncodingFilter["EncodingFilter<br/>(UTF-8 toàn bộ, url: /*)"]
            AuthenticationFilter["AuthenticationFilter<br/>(RBAC, url: /admin/*, /staff/*, /member/*, /pt/*)"]
            EncodingFilter --> AuthenticationFilter
        end

        subgraph ControllerLayer["CONTROLLER LAYER (Servlets)"]
            LoginCtrl["LoginController (/login)"]
            LogoutCtrl["LogoutController (/logout)"]
            DashCtrls["Dashboard Controllers<br/>(/admin/dashboard, /staff/dashboard,<br/>/pt/dashboard, /member/dashboard)"]
        end

        subgraph ServiceLayer["SERVICE LAYER (Business Logic)"]
            UserService["UserService (Interface)"]
            UserServiceImpl["UserServiceImpl<br/>- login(email, rawPassword)<br/>- registerMember(user, rawPassword)<br/>- getProfile(userId)<br/>- updateProfile(user)"]
            UserService --> UserServiceImpl
        end

        subgraph DAOLayer["DAO LAYER (Data Access)"]
            BaseDAO["BaseDAO (Abstract Class)"]
            UserDAO["UserDAO (Interface)"]
            UserDAOImpl["UserDAOImpl<br/>- findByEmail(email)<br/>- findById(userId)<br/>- insert(user)<br/>- update(user)<br/>- delete(userId) (soft delete)<br/>- findAllActive()"]
            UserDAOImpl --extends--> BaseDAO
            UserDAO --> UserDAOImpl
        end

        subgraph Utils["UTILITIES"]
            DBContext["DBContext<br/>(JDBC Connection db.properties)"]:::util
            PasswordUtils["PasswordUtils<br/>(SHA-256 hash & verify)"]:::util
        end
    end

    Database[("🛢️ Microsoft SQL Server<br/>DB: GymCenterManagement<br/>Table: users")]:::db

    Client <-->|"HTTP Request / Response"| Filters
    Filters --> ControllerLayer
    ControllerLayer --> ServiceLayer
    ServiceLayer --> DAOLayer
    DAOLayer <-->|"JDBC (mssql-jdbc)"| Database
    UserDAOImpl -.-> DBContext
    UserServiceImpl -.-> PasswordUtils
```

---

## 2. Sơ Đồ Cấu Trúc Thư Mục (Directory Tree)

### 2.1. Toàn Bộ Project

```text
GymCenterManagement/
├── pom.xml                                ← Maven build config (Jakarta EE 10, MSSQL JDBC)
├── nb-configuration.xml                   ← NetBeans IDE config
│
├── DashMin/                               ← Template gốc (chỉ tham khảo, không deploy)
│   ├── index.html                         ← Dashboard mẫu
│   ├── signin.html                        ← Login mẫu
│   ├── 404.html, blank.html, ...          ← Các trang mẫu khác
│   ├── css/
│   ├── js/
│   ├── img/
│   ├── lib/
│   └── scss/
│
├── documentations/                        ← Tài liệu dự án
│   └── architecture.md                    ← File này
│
└── src/
    └── main/
        ├── java/                          ← Java source code (backend)
        ├── resources/                     ← Config files
        └── webapp/                        ← Web resources (frontend + deployment)
```

### 2.2. Backend — Java Source Code

```text
src/main/java/
└── com/mycompany/gymcentermanagement/
    │
    ├── controller/                      ← [LAYER 1] Controller / Servlet Layer
    │   ├── auth/
    │   │   ├── LoginController.java       /login         (GET → show form, POST → authenticate)
    │   │   └── LogoutController.java      /logout        (GET → invalidate session)
    │   ├── admin/
    │   │   └── AdminDashboardController.java     /admin/dashboard
    │   ├── staff/
    │   │   └── StaffDashboardController.java     /staff/dashboard
    │   ├── pt/
    │   │   └── PtDashboardController.java        /pt/dashboard
    │   └── member/
    │       └── MemberDashboardController.java    /member/dashboard
    │
    ├── service/                         ← [LAYER 2] Business Logic Layer
    │   ├── UserService.java                      Interface định nghĩa business operations
    │   └── impl/
    │       └── UserServiceImpl.java              Xử lý login, register, profile CRUD
    │
    ├── dao/                             ← [LAYER 3] Data Access Layer
    │   ├── BaseDAO.java                          Abstract class quản lý resource & transaction
    │   ├── UserDAO.java                          Interface định nghĩa DB operations
    │   └── impl/
    │       └── UserDAOImpl.java                  JDBC implementation (SQL Server queries)
    │
    ├── model/                           ← Entity / Domain Model
    │   └── entity/
    │       └── User.java                         Entity class (Role enum, AccountStatus enum)
    │
    ├── filter/                          ← Servlet Filters (Cross-cutting concerns)
    │   ├── EncodingFilter.java                   UTF-8 encoding cho mọi request (urlPattern: /*)
    │   └── AuthenticationFilter.java             Xác thực & phân quyền RBAC
    │                                             (urlPattern: /admin/*, /staff/*, /member/*, /pt/*)
    │
    └── utils/                           ← Tiện ích dùng chung
        ├── DBContext.java                        JDBC Connection Factory (đọc db.properties)
        └── PasswordUtils.java                    SHA-256 hash & verify password
```

### 2.3. Resources — Cấu Hình

```text
src/main/resources/
├── META-INF/
└── db.properties                        ← Database connection config
                                             (db.driver, db.url, db.username, db.password)
```

### 2.4. Frontend — Web Application

```text
src/main/webapp/
├── css/                                 ← DashMin styles
│   ├── bootstrap.min.css                         Bootstrap 5 (customized theme)
│   └── style.css                                 DashMin custom CSS (sidebar, navbar, widgets)
│
├── js/                                  ← DashMin scripts
│   └── main.js                                   Sidebar toggler, spinner, chart initialization
│
├── img/                                 ← DashMin images
│   ├── user.jpg                                  Default user avatar
│   ├── testimonial-1.jpg
│   └── testimonial-2.jpg
│
├── lib/                                 ← Third-party JS libraries
│   ├── chart/
│   │   └── chart.min.js                          Chart.js (biểu đồ)
│   ├── easing/
│   │   ├── easing.js
│   │   └── easing.min.js                         jQuery easing animations
│   ├── owlcarousel/
│   │   ├── owl.carousel.min.js                   Carousel slider
│   │   └── assets/                               Carousel CSS + assets
│   ├── tempusdominus/
│   │   ├── css/
│   │   │   └── tempusdominus-bootstrap-4.min.css
│   │   └── js/
│   │       ├── moment.min.js                     Moment.js (date/time)
│   │       ├── moment-timezone.min.js
│   │       └── tempusdominus-bootstrap-4.min.js  Date/Time picker
│   └── waypoints/
│   │   └── waypoints.min.js                      Scroll trigger animations
│   │
├── index.html                           ← Landing page (static)
│
├── META-INF/
│
└── WEB-INF/
    ├── beans.xml                        ← CDI config
    ├── web.xml                          ← Deployment descriptor (session timeout: 30 min)
    │
    └── views/                           ← JSP Views (protected, không truy cập trực tiếp)
        │
        ├── common/                      ← Shared layout fragments (include vào các page)
        │   ├── dashboard_header.jsp              <head>, spinner, sidebar (dynamic theo role)
        │   ├── dashboard_navbar.jsp              Top navigation bar, user dropdown, logout
        │   ├── dashboard_footer.jsp              Footer, <script> libraries
        │   ├── header.jsp                        Header cũ (dùng cho login, error pages)
        │   ├── footer.jsp                        Footer cũ (dùng cho login, error pages)
        │   └── error-403.jsp                     Trang lỗi 403 Forbidden
        │
        ├── auth/
        │   └── login.jsp                         Trang đăng nhập (DashMin sign-in layout)
        │
        ├── admin/
        │   └── dashboard.jsp                     Admin dashboard (KPIs, charts, user table, calendar)
        │
        ├── staff/
        │   └── dashboard.jsp                     Staff dashboard (check-ins, registrations, quick actions)
        │
        ├── pt/
        │   └── dashboard.jsp                     PT dashboard (clients, sessions, checklists)
        │
        └── member/
            └── dashboard.jsp                     Member dashboard (bookings, membership, quick actions)
```

---

## 3. Sơ Đồ Luồng Xử Lý Request (Request Flow)

### 3.1. Luồng Đăng Nhập

```mermaid
sequenceDiagram
    autonumber
    actor Browser as Client Browser
    participant Filter as EncodingFilter
    participant LoginCtrl as LoginController
    participant Service as UserService
    participant DAO as UserDAO
    participant DB as SQL Server
    
    Note over Browser, LoginCtrl: Luồng GET /login (Hiển thị trang đăng nhập)
    Browser->>Filter: GET /login
    activate Filter
    Filter->>Filter: Set UTF-8 encoding
    Filter->>LoginCtrl: Forward request
    activate LoginCtrl
    LoginCtrl->>LoginCtrl: Kiểm tra session có currentUser?
    alt session đã có currentUser
        LoginCtrl-->>Browser: Redirect về /{role}/dashboard (302)
    else session chưa có currentUser
        LoginCtrl-->>Browser: Forward sang views/auth/login.jsp (200 OK)
    end
    deactivate LoginCtrl
    deactivate Filter

    Note over Browser, DB: Luồng POST /login (Thực hiện đăng nhập)
    Browser->>Filter: POST /login (email, password)
    activate Filter
    Filter->>Filter: Set UTF-8 encoding
    Filter->>LoginCtrl: Forward request
    activate LoginCtrl
    LoginCtrl->>Service: login(email, rawPassword)
    activate Service
    Service->>DAO: findByEmail(email)
    activate DAO
    DAO->>DB: SELECT * FROM users WHERE email=?
    activate DB
    DB-->>DAO: Trả về dữ liệu User
    deactivate DB
    DAO-->>Service: Trả về đối tượng User
    deactivate DAO
    
    alt User tồn tại
        Service->>Service: Verify password (SHA-256)
        Service->>Service: Kiểm tra AccountStatus == Active
        Service-->>LoginCtrl: Đối tượng User hợp lệ
    else Không tìm thấy / Sai pass / Bị khóa
        Service-->>LoginCtrl: Trả về null / Ném exception
    end
    deactivate Service

    alt Đăng nhập thành công
        LoginCtrl->>LoginCtrl: session.setAttribute("currentUser", user)
        LoginCtrl-->>Browser: Redirect về /{role}/dashboard (302)
    else Đăng nhập thất bại
        LoginCtrl->>LoginCtrl: request.setAttribute("errorMessage", ...)
        LoginCtrl-->>Browser: Forward sang login.jsp (200 OK)
    end
    deactivate LoginCtrl
    deactivate Filter
```

### 3.2. Luồng Truy Cập Dashboard (sau khi đăng nhập)

```mermaid
sequenceDiagram
    autonumber
    actor Browser as Client Browser
    participant Filter as EncodingFilter
    participant AuthFilter as AuthenticationFilter
    participant DashCtrl as AdminDashboardController
    participant View as dashboard.jsp
    
    Browser->>Filter: GET /admin/dashboard
    activate Filter
    Filter->>Filter: Set UTF-8 encoding
    Filter->>AuthFilter: Forward request
    activate AuthFilter
    
    AuthFilter->>AuthFilter: Lấy session.getAttribute("currentUser")
    alt user == null
        AuthFilter-->>Browser: Redirect về /login (302)
    else user != null
        alt user.role == Admin
            AuthFilter->>DashCtrl: chain.doFilter() (Cho qua)
            activate DashCtrl
            DashCtrl->>View: Forward sang /WEB-INF/views/admin/dashboard.jsp
            activate View
            Note over View: jsp:include các component:<br/>- dashboard_header.jsp<br/>- dashboard_navbar.jsp<br/>- dashboard_footer.jsp
            View-->>Browser: Render giao diện HTML hoàn chỉnh (200 OK)
            deactivate View
            deactivate DashCtrl
        else user.role != Admin
            AuthFilter-->>Browser: Forward sang error-403.jsp (403 Forbidden)
        end
    end
    deactivate AuthFilter
    deactivate Filter
```

---

## 4. Sơ Đồ Quan Hệ Các Class (Class Dependency)

```mermaid
flowchart TD
    %% Define Styles
    classDef controller fill:#e3f2fd,stroke:#1565c0,stroke-width:2px;
    classDef filter fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px;
    classDef service fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px;
    classDef dao fill:#fffde7,stroke:#fbc02d,stroke-width:2px;
    classDef model fill:#ffebee,stroke:#c62828,stroke-width:2px;
    classDef util fill:#eceff1,stroke:#37474f,stroke-width:2px;

    %% Filters
    EncodingFilter["EncodingFilter<br/>(urlPattern: /*)"]:::filter
    AuthFilter["AuthenticationFilter<br/>(urlPattern: /admin/*, /staff/*, /pt/*, /member/*)"]:::filter

    %% Controllers
    LoginCtrl["LoginController<br/>(/login)"]:::controller
    LogoutCtrl["LogoutController<br/>(/logout)"]:::controller
    AdminDashCtrl["AdminDashboardController<br/>(/admin/dashboard)"]:::controller
    StaffDashCtrl["StaffDashboardController<br/>(/staff/dashboard)"]:::controller
    PtDashCtrl["PtDashboardController<br/>(/pt/dashboard)"]:::controller
    MemberDashCtrl["MemberDashboardController<br/>(/member/dashboard)"]:::controller

    %% Services
    UserService["&laquo;interface&raquo;<br/>UserService"]:::service
    UserServiceImpl["UserServiceImpl"]:::service

    %% DAOs
    BaseDAO["&laquo;abstract&raquo;<br/>BaseDAO"]:::dao
    UserDAO["&laquo;interface&raquo;<br/>UserDAO"]:::dao
    UserDAOImpl["UserDAOImpl"]:::dao

    %% Models & Utils
    User["User (Entity)<br/>- Role (Enum)<br/>- AccountStatus (Enum)"]:::model
    PasswordUtils["PasswordUtils<br/>(SHA-256)"]:::util
    DBContext["DBContext"]:::util
    DB[("Microsoft SQL Server")]:::util

    %% Relationships
    EncodingFilter --> AuthFilter
    AuthFilter -.->|depends on| User
    AuthFilter --> LoginCtrl & LogoutCtrl & AdminDashCtrl & StaffDashCtrl & PtDashCtrl & MemberDashCtrl

    LoginCtrl -->|uses| UserService
    AdminDashCtrl & StaffDashCtrl & PtDashCtrl & MemberDashCtrl -.->|session| User
    
    UserService <|.. UserServiceImpl
    UserServiceImpl -->|uses| UserDAO
    UserServiceImpl -->|uses| PasswordUtils
    UserServiceImpl -.->|returns| User

    UserDAO <|.. UserDAOImpl
    BaseDAO <|-- UserDAOImpl
    UserDAOImpl -->|uses| DBContext
    UserDAOImpl -.->|returns| User
    DBContext -->|JDBC connection| DB
```

---

## 5. Sơ Đồ Phân Quyền (RBAC — Role-Based Access Control)

```mermaid
flowchart TD
    Role["User.Role (Enum)"]
    
    Admin["Admin<br/>(/admin/*)"]
    Staff["Staff<br/>(/staff/*)"]
    PT["PT (Personal Trainer)<br/>(/pt/*)"]
    Member["Member<br/>(/member/*)"]

    Role --> Admin & Staff & PT & Member

    Admin --- AdminActions["• Dashboard<br/>• Manage Users<br/>• Equipment<br/>• Classes<br/>• Reports"]
    Staff --- StaffActions["• Dashboard<br/>• Check-in<br/>• Register Member<br/>• Bookings"]
    PT --- PTActions["• Dashboard<br/>• Clients<br/>• Sessions<br/>• Workout Plans"]
    Member --- MemberActions["• Dashboard<br/>• Book Class<br/>• Book PT<br/>• Membership Info"]

    classDef roleNode fill:#f9f9f9,stroke:#333,stroke-width:2px;
    classDef actionNode fill:#fff,stroke:#777,stroke-dasharray: 5 5;
    class Role,Admin,Staff,PT,Member roleNode;
    class AdminActions,StaffActions,PTActions,MemberActions actionNode;
```

---

## 6. Sơ Đồ Cấu Trúc JSP Layout (View Composition)

```mermaid
flowchart TD
    subgraph JSPLayout["dashboard_layout Structure (dashboard_header.jsp to dashboard_footer.jsp)"]
        direction TB
        Header["📄 dashboard_header.jsp<br/>• DOCTYPE html, head, Meta tags<br/>• CSS (Bootstrap 5, style.css, Fonts, Icons)<br/>• Spinner & Sidebar Navigation Menu (dynamic by role)"]
        
        Navbar["📄 dashboard_navbar.jsp<br/>• Top Navigation Bar<br/>• Sidebar Toggle, Search<br/>• User Dropdown (Profile, Logout)"]
        
        Content["🖥️ [PAGE-SPECIFIC CONTENT]<br/>e.g., admin/dashboard.jsp<br/>• KPI Cards Row<br/>• Charts Row<br/>• Recent Users Table<br/>• Widgets Row (Calendar + Tasks)"]
        
        Footer["📄 dashboard_footer.jsp<br/>• Footer (Copyright)<br/>• Closing HTML tags<br/>• JavaScript Libraries (jQuery, Bootstrap, Chart.js, main.js)"]
        
        Header --> Navbar --> Content --> Footer
    end
```

---

## 7. Technology Stack

| Layer | Technology | Phiên bản |
| :--- | :--- | :--- |
| **Language** | Java | 11+ (Runtime: JDK 21) |
| **Platform** | Jakarta EE | 10.0.0 |
| **Build Tool** | Apache Maven | — |
| **Web Server** | Tomcat / GlassFish | Jakarta EE 10 compatible |
| **Database** | Microsoft SQL Server | — |
| **JDBC Driver** | mssql-jdbc | 12.6.1.jre11 |
| **View Engine** | JSP + JSTL | Jakarta Tags |
| **UI Framework** | Bootstrap | 5.0.0 |
| **UI Template** | DashMin | Free Admin Template |
| **Icons** | Font Awesome 5 + Bootstrap Icons | 5.10.0 / 1.4.1 |
| **Charts** | Chart.js | — |
| **Date/Time** | Moment.js + TempusDominus | — |
| **IDE** | Apache NetBeans | — |

---

## 8. Nguyên Tắc Thiết Kế Áp Dụng

| Nguyên tắc | Mô tả | Ví dụ trong project |
| :--- | :--- | :--- |
| **Separation of Concerns** | Mỗi layer chỉ xử lý 1 trách nhiệm | Controller không chứa SQL, DAO không chứa business logic |
| **Interface Segregation** | Sử dụng interface cho Service và DAO | UserService, UserDAO là interface, implementation riêng |
| **DRY (Don't Repeat Yourself)** | Tái sử dụng layout fragments | dashboard_header/navbar/footer.jsp dùng chung cho 4 dashboards |
| **Soft Delete** | Không xóa vật lý, chỉ đánh dấu is_deleted | UserDAOImpl.delete() dùng UPDATE SET is_deleted=1 |
| **RBAC** | Phân quyền theo Role | AuthenticationFilter kiểm tra User.Role vs URL path |
| **Transaction Support** | DAO hỗ trợ shared connection | BaseDAO nhận connection từ Service layer cho transaction |
