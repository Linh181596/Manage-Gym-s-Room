# Tài liệu Tổng hợp Lưu ý Chỉnh sửa & Review (SRS & SDS)

## I. Yêu cầu về Định dạng Tài liệu
*   **Layout:** Đảm bảo **tiêu mục (heading) và ảnh minh họa tương ứng nằm trên cùng 1 trang** (tránh tình trạng tiêu đề ở trang trước, ảnh ở trang sau).
*   **Mục lục & Heading:** Chỉnh sửa lại format mục lục đang lộn xộn, xóa bỏ các heading trống thừa thãi.
*   **Đánh số trang:** Kiểm tra và sửa lại lỗi đánh số trang bị sai.
*   **Đánh số mục:** 
    *   Kiểm tra các mục con trùng tên (VD: có 2 mục con trùng tên `2.1.20`).
    *   Sửa lỗi đánh số nhảy cóc (VD: Không có mục `4` nhưng lại có mục con `4.1`, `4.2`,...).
*   **Hình ảnh & Sơ đồ:** Tất cả các hình vẽ, sơ đồ đều phải có caption theo format chuẩn (Ví dụ: `Figure 1. Context diagram`, `Figure 2. ...`).

---

## II. Lưu ý chỉnh sửa SRS (Software Requirements Specification)

### 1. Tính nhất quán của Actor và Use Case
*   **Actor & External Entity:** Đảm bảo tính nhất quán giữa danh sách external entity với danh sách actor trong các Swimlane activity diagram và đặc tả use cases.
*   **Danh sách Actor trong đặc tả chi tiết:** Phải rà soát và đảm bảo các Actor (như Admin, Member, Staff, Personal Trainer...) xuất hiện trong đặc tả (mục 2.1) khớp hoàn toàn với danh sách Actor khai báo ở đầu tài liệu và trong Use case diagram. Không để lọt các Actor lạ không thuộc hệ thống.
*   **Số lượng và đánh số Use Case:** Rà soát và đồng nhất vì hiện tại đang có sự chênh lệch:
    *   Bảng use cases đang có 47 use cases (mục 1.3.2).
    *   Danh sách đặc tả use cases lại có 52 use cases (mục 2.1).
    *   Lệch số lượng với các use cases chi tiết hiển thị trong Use case diagram.
*   **Tên Use Case:** Danh sách tên use cases trong bảng Use case list (mục 1.3.2) đang bị lệch với tên trong Use case diagram.
*   **Phân quyền (Authorization):** Phân quyền actor thực hiện use case trong mục 1.3.2 và 2.1 cũng như sơ đồ đang bị lệch nhau $\rightarrow$ Dẫn đến lệch với bảng danh sách phân quyền theo màn hình.
*   **Quy tắc đặt tên:** "Home page" không phải là use case, nhưng "**View Homepage**" thì được tính là một Use case.
*   **Bảng mô tả:** Đổi tên cột `Function` thành cột `Use case name`.

### 2. Quy chuẩn viết Đặc tả & Swimlane Diagram
*   **Đặc tả (Specification):**
    *   **USE CASE DIAGRAM phải khớp hoàn toàn với Use case specification.**
    *   Đặc tả viết đơn giản, tập trung vào nghiệp vụ, **tuyệt đối không nêu rõ code/logic lập trình** trong phần này.
*   **Mô tả các Diagram (Ví dụ: Swimlane diagram):** Viết mô tả theo khung chuẩn, bằng tiếng Việt (viết ngay dưới phần description tiếng Anh hiện có).
    *   **Cú pháp từng bước:** `Step X: S (actor/system) + V + O`
    *   **Lưu ý:** Ghi chú tên tiếng Anh của actor bên cạnh tên tiếng Việt. Thêm chữ "**kết thúc**" khi một quá trình nào đó hoàn thành.
    *   **Ví dụ chuẩn:**
        *   *Step 1:* Nhà tuyển dụng (Recruiter) [S] đăng ký [V] tài khoản nhà tuyển dụng [O].
        *   *Step 2:* Nhà tuyển dụng (Recruiter) hoàn tất hồ sơ công ty.
        *   *Step 3:* Hệ thống (System) thẩm định việc hoàn tất hồ sơ của công ty.
        *   *Step 4:* Nếu hồ sơ đã hoàn tất, hệ thống gửi thông báo đã hoàn tất hồ sơ và **kết thúc**; nếu hồ sơ chưa hoàn tất hệ thống yêu cầu kiểm duyệt viên (Moderator) xác thực công ty.
        *   *Step 5:* Kiểm duyệt viên (Moderator) xem xét yêu cầu xác thực.

### 3. Database Logic & ERD
*   **Mô tả thực thể ERD:** Ở mức mô hình Logic (Logical ERD) trong SRS **chưa cần xác định khóa ngoại (Foreign Key - FK)**. Việc có khóa ngoại đang bị sai mức của mô hình.
*   **Mô tả quan hệ:** Viết mô tả lại theo dạng tiếng Việt cho Database logic diagram. Giải thích rõ ràng các mối quan hệ (Relationship 1 - N, 1 - 1, N - N) giữa các thực thể.

### 4. Các yêu cầu UI/UX và Functional bổ sung
*   **Notification:** Tách màn hình của Notification ra độc lập/rõ ràng hơn.
*   **Blog:** Tính năng lịch tự động hiển thị blog.

---

## III. Lưu ý chỉnh sửa SDS (Software Design Specification)

*   **Công nghệ:** Kiểm tra lại kỹ danh sách công nghệ sử dụng trong tài liệu xem đã đúng với cấu hình thực tế chưa.
*   **Coding Convention:** Kiểm tra thật kỹ các quy tắc về coding convention (đặt tên biến, class, format,...).
*   **Software Architecture & Package Diagram:**
    *   Biểu đồ Package Diagram phải thể hiện **đủ và khớp** so với source code thực tế.
    *   Nhớ chia thành các package `impl` (để mô tả chi tiết các package ở layer sâu hơn).
    *   Xác định rõ hệ thống được chia package thành mấy cấp.
*   **Class Diagram:**
    *   Kiểm tra sự nhất quán giữa Class diagram và Source Code.
    *   Đảm bảo các quan hệ (`import`, `implement`, `extend`) trong code phải khớp hoàn toàn với chiều mũi tên vẽ quan hệ trong Class diagram.
