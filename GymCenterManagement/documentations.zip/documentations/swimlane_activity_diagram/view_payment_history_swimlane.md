# Sơ đồ Swimlane Activity Diagram - Xem Lịch Sử Thanh Toán (View Payment History - UC-19)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Xem lịch sử thanh toán (View Payment History)** dành cho cả **Staff** và **Admin**.

---

## 1. Sơ đồ Hoạt Động (Swimlane Activity Diagram)

```plantuml
@startuml
|User|
start
:Click Payment Menu link;
|System|
:Load all invoices;
:Query all invoices;
:Return records;
:Return entities;
:Forward request;
:Render payment-list.jsp;
|User|
:Input filters: Search text, Status, Date range;
|System|
:Update rows visibility via JS;
|User|
:Click View Detail button;
|System|
:Load invoice by ID;
:Query invoice by ID;
:Return record;
:Return Entity;
:Return object;
:Forward with backUrl attributes;
:Render payment-record-detail.jsp;
|User|
:View payment details;
stop
@enduml
```

