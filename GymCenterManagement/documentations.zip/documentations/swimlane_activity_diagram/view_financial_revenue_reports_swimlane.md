# Sơ đồ Swimlane Activity Diagram - Xem Báo Cáo Tài Chính & Doanh Thu (View Financial & Revenue Reports - UC-20)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Xem Báo Cáo Tài Chính & Doanh Thu**. Dữ liệu doanh thu được biểu diễn trực quan trên trang Dashboard chính của Admin.

---

## 1. Sơ đồ: Luồng Xem Báo Cáo (View Reports Flow)

```plantuml
@startuml
|Admin|
start
:Access Admin Dashboard from menu;
|System|
:Receive dashboard request;
:Get admin dashboard data;
:Query revenue trend;
:Return revenue records;
:Process missing days;
:Build JSON data;
:Set dashboardData attribute;
:Forward to View;
:Render dashboard.jsp;
:Render chart with JSON data;
|Admin|
:View revenue chart;
stop
@enduml
```
