# Tài liệu Thiết kế Chi tiết: Swimlane Activity Diagram - Quản lý Gói Tập (Manage Package - UC-15)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Quản lý Gói Tập (Manage Package)** dành cho quản trị viên (**Admin**). Tài liệu phân tách luồng thành 4 sơ đồ độc lập: Xem danh sách (Read), Tạo mới (Create), Cập nhật (Update), và Xóa mềm (Soft Delete). Thiết kế loại bỏ hoàn toàn các nút Bắt đầu/Kết thúc dư thừa và bổ sung các nút điều kiện rẽ nhánh (Quyết định) khi xác thực hoặc xác nhận.

---

## 1. Thành phần tham gia (Swimlanes/Lanes)

Sơ đồ được phân chia thành 2 làn chính đại diện cho các Actor tương tác:
1. **Actor**: Nhân viên, Quản trị viên hoặc Hội viên thực hiện thao tác.
2. **System**: Hệ thống phần mềm tiếp nhận, xử lý logic và lưu trữ dữ liệu.

---

## 2. Các luồng xử lý chi tiết (Swimlane Activity Diagrams)

### 2.1. Luồng Xem Danh Sách Gói Tập (Read)

```plantuml
@startuml
|Admin|
start
:Access Gym Package Management Menu;
|System|
:Get all packages;
:Query all active packages;
:Return package list;
:Set packages attribute;
:Forward request;
:Render package-list.jsp;
|Admin|
:View package list;
stop
@enduml
```

---

### 2.2. Luồng Tạo Mới Gói Tập (Create)

```plantuml
@startuml
|Admin|
start
:Click Create Gym Package button;
|System|
:Forward request;
:Render empty package-form.jsp;
|Admin|
:Enter package info and click Save;
|System|
if (Validate Client-side?) then (Valid)
  :Submit POST form data;
  if (Validate Server-side?) then (Valid)
    :Create package;
    :Insert new package;
    :Execute INSERT query;
    :Return result;
    :Return success;
    :Redirect to package list with successMsg;
    |Admin|
    :View updated list;
  else (Invalid)
|System|
    :Set error message;
    :Display error;
    |Admin|
    :View error;
  endif
else (Invalid)
|System|
  :Display client-side error;
  |Admin|
  :View error;
endif
stop
@enduml
```

---

### 2.3. Luồng Chỉnh Sửa Gói Tập (Update)

```plantuml
@startuml
|Admin|
start
:Click Edit button on package row;
|System|
:Return result;
:Return Entity;
:Return object;
:Set package attribute;
:Forward request;
:Render package-form.jsp with existing data;
|Admin|
:Modify package info and click Save;
|System|
if (Validate Client-side?) then (Valid)
  :Submit POST form data with ID;
  if (Validate Server-side?) then (Valid)
    :Update package;
    :Update package record;
    :Confirm update;
    :Return result;
    :Return success;
    :Redirect to package list with successMsg;
    |Admin|
    :View updated list;
  else (Invalid)
|System|
    :Set error message;
    :Display error;
    |Admin|
    :View error;
  endif
else (Invalid)
|System|
  :Display client-side error;
  |Admin|
  :View error;
endif
stop
@enduml
```

---

### 2.4. Luồng Xóa Mềm Gói Tập (Soft Delete)

```plantuml
@startuml
|Admin|
start
:Click Delete button on the package row;
|System|
:Display Confirmation Modal;
|Admin|
if (Confirm delete?) then (Yes)
|System|
  :Send GET delete request with packageId;
  :Receive GET delete request;
  :Delete package;
  :Soft delete package;
  :Confirm update success;
  :Return result;
  :Return success;
  :Redirect to package list with successMsg;
  |Admin|
  :View updated list;
else (No)
|System|
  :Close modal;
  |Admin|
  :Return to package list;
endif
stop
@enduml
```

---

## 3. Mô tả chi tiết luồng xử lý (Step-by-Step Execution)

### 3.1. Luồng xem danh sách (GET /admin/packages)
1.  **Admin** truy cập vào chức năng Quản lý gói tập từ menu chính.
2.  Trang gửi yêu cầu `GET /admin/packages` đến **ManagePackageController**.
3.  **ManagePackageController** gọi phương thức `gymPackageService.getAllPackages()`.
4.  **GymPackageServiceImpl** chuyển tiếp yêu cầu tới `GymPackageDAOImpl.findAll()`.
5.  **GymPackageDAOImpl** thực thi câu lệnh SQL để truy vấn tất cả các gói tập chưa bị xóa:
    ```sql
    SELECT * FROM GymPackages WHERE IsDeleted = 0 ORDER BY PackageID DESC
    ```
6.  Kết quả ResultSet được ánh xạ thành danh sách đối tượng `List<GymPackage>` và trả về cho Controller.
7.  **ManagePackageController** lưu danh sách này vào request attribute `packages` và forward sang trang hiển thị **package-list.jsp**.

### 3.2. Luồng thêm mới gói tập (POST /admin/packages - Không có ID)
1.  **Admin** click nút "Tạo mới", Controller forward sang trang **package-form.jsp** hiển thị một form nhập liệu trống.
2.  **Admin** điền đầy đủ các thông tin: Tên gói, số tháng hiệu lực, đơn giá, mô tả và trạng thái.
3.  Trình duyệt thực hiện validate phía Client (đảm bảo các trường không bỏ trống, số tháng và đơn giá không âm).
4.  Khi Admin click "Lưu", trình duyệt gửi yêu cầu `POST /admin/packages` lên **ManagePackageController**.
5.  **ManagePackageController** thực hiện validate phía Server để chống giả mạo dữ liệu:
    *   Trích xuất thông tin Admin đang đăng nhập từ HTTP Session để thiết lập trường `createdBy` (Người tạo).
    *   Gọi `gymPackageService.createPackage(pkg)`.
6.  **GymPackageDAOImpl** thực hiện câu lệnh SQL INSERT để thêm mới bản ghi:
    ```sql
    INSERT INTO GymPackages (PackageName, DurationMonths, Price, Description, Status, CreatedBy, CreatedDate, IsDeleted) 
    VALUES (?, ?, ?, ?, ?, ?, GETDATE(), 0)
    ```
7.  **ManagePackageController** nhận kết quả thành công, thực hiện chuyển hướng (`Redirect`) về lại trang danh sách kèm theo thông báo thành công.

### 3.3. Luồng cập nhật thông tin gói tập (POST /admin/packages - Có ID ẩn)
1.  **Admin** click "Sửa" trên dòng gói tập. Controller đón nhận ID, gọi Service/DAO truy vấn thông tin gói từ database qua câu lệnh `SELECT` theo ID.
2.  Controller forward đối tượng `pkg` sang trang **package-form.jsp** để đổ dữ liệu cũ vào các trường nhập liệu.
3.  **Admin** chỉnh sửa các thông tin cần thiết và nhấp "Lưu".
4.  Form gửi yêu cầu `POST` chứa ID gói tập trong thẻ `input type="hidden"` lên **ManagePackageController**.
5.  Controller trích xuất thông tin Admin từ session để gán cho trường `updatedBy` (Người cập nhật) và gọi `gymPackageService.updatePackage(pkg)`.
6.  **GymPackageDAOImpl** thực thi câu lệnh SQL UPDATE:
    ```sql
    UPDATE GymPackages 
    SET PackageName = ?, DurationMonths = ?, Price = ?, Description = ?, Status = ?, UpdatedBy = ?, UpdatedDate = GETDATE() 
    WHERE PackageID = ? AND IsDeleted = 0
    ```
7.  Controller nhận kết quả thành công, thực hiện chuyển hướng (`Redirect`) về lại trang danh sách gói tập.

### 3.4. Luồng xóa mềm gói tập (GET /admin/packages?action=delete&id=...)
1.  Tại trang danh sách, **Admin** click nút "Xóa" bên cạnh gói tập mong muốn.
2.  Giao diện hiển thị một Modal Confirmation của Bootstrap yêu cầu xác nhận.
3.  Khi Admin bấm đồng ý xóa, trình duyệt gửi yêu cầu `GET` với tham số `action=delete` và `id={packageId}` lên **ManagePackageController**.
4.  **ManagePackageController** gọi phương thức xóa của Service và DAO.
5.  **GymPackageDAOImpl** thực thi câu lệnh cập nhật trạng thái xóa logic của bản ghi (Soft Delete):
    ```sql
    UPDATE GymPackages SET IsDeleted = 1 WHERE PackageID = ?
    ```
    *Ưu điểm*: Phương pháp này không xóa bản ghi vật lý ra khỏi cơ sở dữ liệu để bảo toàn các ràng buộc khóa ngoại (Foreign Key Constraints) với các bảng đăng ký gói tập của hội viên (`MemberPackages`) đã tồn tại trước đó.
6.  Controller nhận kết quả thành công và thực hiện chuyển hướng (`Redirect`) về lại danh sách gói tập.

---

## 4. Sơ đồ Chuyển Trạng Thái Thực Thể Gói Tập (`GymPackage`)

Thực thể gói tập được cấu hình trạng thái qua thuộc tính `Status` và `IsDeleted` dưới dạng các **Tính từ (Adjective)**:

```mermaid
stateDiagram-v2
    [*] --> Inactive : Create new package in locked state (default)
    [*] --> Active : Create active package (available for sale)
    Inactive --> Active : Activate package for sale
    Active --> Inactive : Temporarily suspend package sale
    Active --> SoftDeleted : Delete package (set IsDeleted = 1)
    Inactive --> SoftDeleted : Delete package (set IsDeleted = 1)
    SoftDeleted --> [*]
```

