# Cập Nhật Swimlane Activity: Membership & Payment (Tích hợp VNPay)

Tài liệu này cập nhật lại quy trình **Đăng ký gói tập đến thanh toán** dựa trên thay đổi mới của hệ thống khi tích hợp cổng thanh toán trực tuyến **VNPAY**.

---

## 1. Giải đáp thắc mắc về Actor

> **Câu hỏi:** Payment gateway (VNPay) có tính là 1 actor không? Nếu có thì liệu mình có thiếu actor hoặc external actor nào nữa của hệ thống?

**Trả lời:**
- **Có, VNPay hoàn toàn được tính là một Actor (External Actor/Hệ thống bên ngoài)**. Trong các sơ đồ UML (Use Case, Activity), bất kỳ hệ thống, dịch vụ, hoặc thiết bị bên ngoài nào tương tác trực tiếp với hệ thống của bạn đều là một Actor. Việc tách VNPay thành một swimlane riêng biệt giúp làm rõ ranh giới trách nhiệm: phần nào do code hệ thống GCMS xử lý (ví dụ: tạo URL, verify checksum) và phần nào do VNPay xử lý (hiển thị form nhập thẻ, trừ tiền ngân hàng).
- **Các External Actor khác có thể có:** 
  - **Email/SMS Server (VD: SendGrid, SMTP Server):** Nếu hệ thống của bạn có chức năng gửi email hóa đơn điện tử hoặc email thông báo gia hạn thành công cho Member sau khi thanh toán.
  - **Hệ thống Ngân hàng (Bank):** Thường đứng sau VNPay, nhưng trong sơ đồ mức hệ thống nội bộ, gộp chung vào VNPay Gateway là đủ và hợp lý.

---

## 2. Các Sơ đồ Activity Diagram (Swimlane) được tách biệt

Để đảm bảo chuẩn UML (tránh lỗi ngã rẽ song song từ nút Start) và giúp các luồng nghiệp vụ rõ ràng, quy trình đã được tách thành 3 sơ đồ riêng biệt: Đăng ký mới, Gia hạn, và Chuyển nhượng. 

### 2.1. Sơ đồ Đăng ký gói tập mới (Package Registration)

```mermaid
flowchart TD
    Start((Bắt đầu))
    End((Kết thúc))

    subgraph Member [Actor: Member]
        M_Reg[Register Package]
        M_Choose{"Choose <br/>Payment Method"}
        M_Cash[Make Cash Payment]
        M_VNPay["Complete Payment <br/>on VNPay Interface"]
    end

    subgraph Staff [Actor: Staff]
        S_Record[Record Cash Payment]
    end

    subgraph System [System: GCMS]
        Sys_Check{"Check Existing <br/>Pending Invoices & <br/>Package History"}
        Sys_Calc[Calculate Package Fee]
        Sys_Create["Create Package Registration <br/>& Pending Invoice"]
        
        Sys_VnpayUrl[Generate VNPay Payment URL]
        Sys_Verify[Verify VNPay Return Checksum]
        
        Sys_GenInv["Update Invoice to Paid <br/>& Generate Receipt"]
        Sys_Update["Update Package Information <br/>& Activate"]
    end

    subgraph VNPay [External Actor: VNPay Gateway]
        VNP_Display[Display Payment Gateway]
        VNP_Process[Process Transaction]
        VNP_Return["Return Payment Result <br/>via Callback URL"]
    end

    subgraph Admin [Actor: Admin]
        A_History[View Payment History]
        A_Rev[View Revenue Report]
    end

    Start --> M_Reg
    M_Reg --> Sys_Check
    Sys_Check -->|No Pending| Sys_Calc
    Sys_Check -->|Has Pending/History| End
    
    Sys_Calc --> Sys_Create
    Sys_Create --> S_Choose

    %% Nhánh thanh toán Tiền mặt (Cash)
    S_Choose -->|Cash| S_Cash
    S_Cash --> S_Record
    S_Record --> Sys_GenInv

    %% Nhánh thanh toán VNPay
    S_Choose -->|VNPay| Sys_VnpayUrl
    Sys_VnpayUrl --> VNP_Display
    VNP_Display --> M_VNPay
    M_VNPay --> VNP_Process
    VNP_Process --> VNP_Return
    VNP_Return --> Sys_Verify
    
    Sys_Verify -->|Valid Signature & Success| Sys_GenInv
    Sys_Verify -->|Invalid/Failed/Canceled| S_Choose

    Sys_GenInv --> Sys_Update
    Sys_Update --> A_History
    A_History --> A_Rev
    A_Rev --> End
```

### 2.2. Sơ đồ Gia hạn gói tập (Package Renewal)

```mermaid
flowchart TD
    Start((Bắt đầu))
    End((Kết thúc))

    subgraph Member [Actor: Member]
        M_Renew[Renew Package]
        M_Choose{"Choose <br/>Payment Method"}
        M_Cash[Make Cash Payment]
        M_VNPay["Complete Payment <br/>on VNPay Interface"]
    end

    subgraph Staff [Actor: Staff]
        S_Record[Record Cash Payment]
    end

    subgraph System [System: GCMS]
        Sys_Check{"Check Existing <br/>Pending Invoices & <br/>Remaining time <= 1 month"}
        Sys_Calc[Calculate Package Fee]
        Sys_Create["Create Pending Invoice"]
        
        Sys_VnpayUrl[Generate VNPay Payment URL]
        Sys_Verify[Verify VNPay Return Checksum]
        
        Sys_GenInv["Update Invoice to Paid <br/>& Generate Receipt"]
        Sys_Update["Update Package Information <br/>& Activate"]
    end

    subgraph VNPay [External Actor: VNPay Gateway]
        VNP_Display[Display Payment Gateway]
        VNP_Process[Process Transaction]
        VNP_Return["Return Payment Result <br/>via Callback URL"]
    end

    subgraph Admin [Actor: Admin]
        A_History[View Payment History]
        A_Rev[View Revenue Report]
    end

    Start --> M_Renew
    M_Renew --> Sys_Check
    Sys_Check -->|No Pending| Sys_Calc
    Sys_Check -->|Has Pending| End
    
    Sys_Calc --> Sys_Create
    Sys_Create --> S_Choose

    %% Nhánh thanh toán Tiền mặt (Cash)
    S_Choose -->|Cash| S_Cash
    S_Cash --> S_Record
    S_Record --> Sys_GenInv

    %% Nhánh thanh toán VNPay
    S_Choose -->|VNPay| Sys_VnpayUrl
    Sys_VnpayUrl --> VNP_Display
    VNP_Display --> M_VNPay
    M_VNPay --> VNP_Process
    VNP_Process --> VNP_Return
    VNP_Return --> Sys_Verify
    
    Sys_Verify -->|Valid Signature & Success| Sys_GenInv
    Sys_Verify -->|Invalid/Failed/Canceled| S_Choose

    Sys_GenInv --> Sys_Update
    Sys_Update --> A_History
    A_History --> A_Rev
    A_Rev --> End
```

### 2.3. Sơ đồ Chuyển nhượng gói tập (Package Transfer)

```mermaid
flowchart TD
    Start((Bắt đầu))
    End((Kết thúc))

    subgraph Member [Actor: Member]
        M_VNPay["Complete Payment <br/>on VNPay Interface"]
    end

    subgraph Staff [Actor: Staff]
        S_Trans["Transfer Package <br/>(Select Receiver)"]
        S_Choose{"Choose <br/>Payment Method"}
        S_Cash[Make Cash Payment]
        S_Record[Record Cash Payment]
    end

    subgraph System [System: GCMS]
        Sys_Check{"Check Existing <br/>Pending Invoices"}
        Sys_Create["Calc Fee (Remaining Days * 5000) <br/>& Create Pending Invoice"]
        
        Sys_VnpayUrl[Generate VNPay Payment URL]
        Sys_Verify[Verify VNPay Return Checksum]
        
        Sys_GenInv["Update Invoice to Paid <br/>& Generate Receipt"]
        Sys_Update["Update Package Information <br/>& Activate"]
    end

    subgraph VNPay [External Actor: VNPay Gateway]
        VNP_Display[Display Payment Gateway]
        VNP_Process[Process Transaction]
        VNP_Return["Return Payment Result <br/>via Callback URL"]
    end

    subgraph Admin [Actor: Admin]
        A_History[View Payment History]
        A_Rev[View Revenue Report]
    end

    Start --> S_Trans
    S_Trans --> Sys_Check
    Sys_Check -->|No Pending| Sys_Create
    Sys_Check -->|Has Pending| End
    
    Sys_Create --> S_Choose

    %% Nhánh thanh toán Tiền mặt (Cash)
    S_Choose -->|Cash| S_Cash
    S_Cash --> S_Record
    S_Record --> Sys_GenInv

    %% Nhánh thanh toán VNPay
    S_Choose -->|VNPay| Sys_VnpayUrl
    Sys_VnpayUrl --> VNP_Display
    VNP_Display --> M_VNPay
    M_VNPay --> VNP_Process
    VNP_Process --> VNP_Return
    VNP_Return --> Sys_Verify
    
    Sys_Verify -->|Valid Signature & Success| Sys_GenInv
    Sys_Verify -->|Invalid/Failed/Canceled| S_Choose

    Sys_GenInv --> Sys_Update
    Sys_Update --> A_History
    A_History --> A_Rev
    A_Rev --> End
```

### 2.4. Sơ đồ Quản lý danh mục gói tập (Package Management)

```mermaid
flowchart TD
    Start((Bắt đầu))
    End((Kết thúc))

    subgraph Admin [Actor: Admin]
        A_Create[Create New Package]
        A_Update[Update Package Info]
        A_Toggle[Activate/Deactivate Package]
    end

    subgraph System [System: GCMS]
        Sys_Validate[Validate Data]
        Sys_Save[Save Package Information]
        Sys_UpdateStatus[Apply Status Change]
    end

    Start --> A_Create
    Start --> A_Update
    Start --> A_Toggle

    A_Create --> Sys_Validate
    A_Update --> Sys_Validate
    
    Sys_Validate -->|Valid| Sys_Save
    Sys_Validate -->|Invalid| End

    Sys_Save --> End
    
    A_Toggle --> Sys_UpdateStatus
    Sys_UpdateStatus --> End
```

---

### 📝 Giải thích các thay đổi so với quy trình cũ:
1. **Sửa đổi logic (Dựa trên rule mới)**: Luồng nghiệp vụ thực tế chỉ tập trung vào việc Đăng ký gói tập (Register Package) và thanh toán cho khách hàng (Đã bỏ qua các bước liên quan đến Đăng ký/Kích hoạt Membership do hệ thống không còn quản lý khái niệm này như một bước trung gian).
2. **Tách luồng xử lý riêng biệt**: Thay vì gộp chung một sơ đồ gây ra lỗi song song sai chuẩn UML (từ node Start tỏa ra 3 nhánh), luồng nghiệp vụ được phân tách thành 3 Activity Diagram cụ thể: Đăng ký mới, Gia hạn và Chuyển nhượng. Việc này giúp Developer và QA dễ dàng hình dung và kiểm thử từng Use Case cụ thể.
3. **Thêm Swimlane VNPay Gateway**: Đại diện cho hệ thống bên ngoài.
4. **Nút thắt `Choose Payment Method`**: Sau khi hệ thống tính toán phí và tạo hóa đơn chờ (Pending Invoice), khách hàng có thể chọn trả Tiền mặt hoặc VNPay.
5. **Quy trình VNPay**: 
   - Hệ thống tạo URL mã hóa an toàn (với Checksum) và redirect người dùng.
   - VNPay tiếp quản việc lấy thông tin thẻ và trừ tiền ngân hàng.
   - Hệ thống (GCMS) bắt buộc phải có bước **Verify VNPay Return Checksum** để chống giả mạo giao dịch trước khi thực sự Cập nhật Hóa đơn (Generate Receipt/Invoice).

---

### Mô tả các luồng nghiệp vụ (Vietnamese)

**1. Luồng Đăng ký mới (Registration)**
**Step 1:** Nhân viên tiến hành Đăng ký gói tập (Register Package) cho khách hàng.
**Step 2:** Hệ thống kiểm tra giao dịch chờ và lịch sử gói tập. Nếu khách hàng đang có giao dịch chờ hoặc đã từng có lịch sử gói tập, hệ thống sẽ chặn thao tác (yêu cầu chuyển sang Gia hạn). Nếu hợp lệ, hệ thống tính toán phí (Calculate Package Fee) và tạo Hóa đơn chờ (Create Pending Invoice).
**Step 3:** Khách hàng chọn Phương thức thanh toán (Choose Payment Method).
- **Nhánh Tiền mặt (Cash):** Khách hàng thanh toán -> Nhân viên xác nhận Record Cash Payment -> Hệ thống cập nhật hóa đơn.
- **Nhánh VNPay (Online):** Hệ thống tạo URL -> VNPay hiển thị -> Khách hàng thanh toán -> VNPay xử lý & trả về kết quả -> Hệ thống xác thực chữ ký. Nếu hợp lệ, hệ thống cập nhật trạng thái hóa đơn thành Paid và lưu phương thức là Banking.
**Step 4:** Hệ thống cập nhật thông tin gói tập và kích hoạt (Update Package Information & Activate).
**Step 5:** Quản trị viên (Admin) xem lịch sử thanh toán và báo cáo doanh thu.

**2. Luồng Gia hạn (Renewal)**
**Step 1:** Nhân viên thực hiện Gia hạn gói tập (Renew Package) trên hệ thống.
**Step 2:** Hệ thống kiểm tra trùng lặp (Check Pending Invoices - tương tự luồng Đăng ký mới) và kiểm tra điều kiện gia hạn (gói tập đang hoạt động hoặc vừa hết hạn không quá 3 ngày). Nếu hợp lệ, hệ thống tính toán phí và tạo Hóa đơn chờ.
**Step 3:** Thanh toán (giống luồng Đăng ký mới).
**Step 4:** Kích hoạt & Cập nhật.
**Step 5:** Ghi nhận lịch sử & Doanh thu.

**3. Luồng Chuyển nhượng (Transfer)**
**Step 1:** Nhân viên thực hiện Chuyển nhượng gói tập (Transfer Package), chọn ngày bắt đầu (StartDate) và số tháng chuyển nhượng (6-12 tháng).
**Step 2:** Hệ thống kiểm tra giao dịch chờ và tính toán phí chuyển nhượng cố định (5,000 VNĐ/ngày còn lại). Nếu người nhận đang có giao dịch chờ thanh toán, hệ thống chặn thao tác. Nếu hợp lệ, tạo Hóa đơn chờ thanh toán cho người nhận.
**Step 3:** Staff chọn Phương thức thanh toán (Tiền mặt hoặc VNPay) và tiến hành thanh toán (Luồng thanh toán tương tự Đăng ký mới).
**Step 4:** Sau khi thanh toán thành công, hệ thống trực tiếp cập nhật thông tin gói tập sang chủ mới và kích hoạt (Update Package Information & Activate).
**Step 5:** Quản trị viên ghi nhận thay đổi thông qua lịch sử hoặc báo cáo.

**4. Luồng Quản lý danh mục gói tập (Package Management)**
**Step 1:** Quản trị viên (Admin) trực tiếp chọn thao tác quản lý gói tập trên giao diện (Tạo mới, Cập nhật, hoặc Đổi trạng thái).
**Step 2:** 
- **Tạo mới / Cập nhật:** Admin nhập thông tin chi tiết gói tập (tên, giá, số ngày...). Hệ thống kiểm tra tính hợp lệ của dữ liệu (Validate Data). Nếu hợp lệ, hệ thống tiến hành lưu thông tin gói tập (Save Package Information). Nếu dữ liệu không hợp lệ, hệ thống báo lỗi.
- **Đổi trạng thái (Activate/Deactivate):** Admin thao tác bật/tắt một gói tập (ví dụ: ẩn đi gói tập cũ không còn kinh doanh). Hệ thống lập tức áp dụng trạng thái mới (Apply Status Change).
**Step 3:** Kết thúc quy trình, danh mục gói tập mới nhất sẽ được áp dụng ngay lập tức trên hệ thống để Nhân viên sử dụng khi Đăng ký/Gia hạn/Chuyển nhượng cho Hội viên.
