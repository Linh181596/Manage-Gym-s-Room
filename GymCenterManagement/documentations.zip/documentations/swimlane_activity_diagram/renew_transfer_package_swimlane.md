# Sơ đồ Swimlane Activity Diagram - Gia Hạn & Chuyển Nhượng Gói Tập (Renew & Transfer Package - UC-18)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Gia hạn (Renew)** và **Chuyển nhượng (Transfer)** gói tập thành viên.

---

## 1. Sơ đồ 1: Luồng Gia Hạn Gói Tập (Renew Package Flow)

```plantuml
@startuml
|Member|
start
:Click Renew Package on portal.jsp;
|System|
:Load package options;
:Forward with attributes;
:Display package-renew.jsp;
|Member|
:Choose Package and Payment Method;
|System|
if (Member exists?) then (yes)
  if (Gym Package active or expired and remaining time <= 1 month?) then (yes)
    :Calculate EndDate;
    :Calculate amount;
    :Insert pending Invoice;
    if (User has no pending transaction?) then (yes)
      :Create invoice for package (Pending);
      :Insert invoice record;
      if (Payment Method = VNPay?) then (yes)
        :Redirect to VNPay Gateway;
        |Member|
        :Process VNPay Payment;
      else (no)
        |System|
        :Redirect to Renew page with success message;
        |Member|
        :Confirm Cash or VNPay at counter;
      endif
    else (no)
|System|
      :Forward with error message;
      |Member|
      :Display Error;
    endif
  else (no)
|System|
    :Forward with error message;
    |Member|
    :Display Error;
  endif
else (no)
|System|
  :Forward with error message;
  |Member|
  :Display Error;
endif
stop
@enduml
```

---

## 2. Sơ đồ 2: Luồng Chuyển Nhượng Gói Tập (Transfer Package Flow)

```plantuml
@startuml
|Staff|
start
:Click Transfer Package on members.jsp;
|System|
:Load sender package;
:Query sender package by ID;
:Return record;
:Return Object;
:Return MemberPackage;
:Forward with attributes;
:Display package-transfer.jsp;
|Staff|
:Search and Select Receiver Member;
|System|
:Fetch receivers via AJAX API;
:Execute AJAX Query;
:Return JSON results;
:Display results;
|Staff|
|Staff|
:Click Confirm;
|System|
if (Sender package Active & valid?) then (yes)
  if (Receiver has no pending transaction and Sender no duplicate pending transfer?) then (yes)
    :Calculate remainingDays;
    :Insert receiver MemberPackage (Pending);
    :Insert receiver package record;
    :Execute INSERT INTO MemberPackages;
    :Create transfer fee invoice (Pending, 5000 * remainingDays);
    :Insert invoice record;
    :Execute INSERT INTO Invoices;
    :Redirect to /staff/record-payment;
    |Staff|
    :Process Payment;
  else (no)
|System|
    :Forward with error message;
    |Staff|
    :Display Error;
  endif
else (no)
|System|
  :Forward with error message;
  |Staff|
  :Display Error;
endif
stop
@enduml
```

