# Tài liệu Thiết kế Chi tiết: Swimlane Activity Diagram - Đăng ký Gói Tập (Register Package - UC-16)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Đăng ký Gói Tập (Register Package)** dành cho **Hội viên (Member)** tự thao tác.

---

## 1. Thành phần tham gia (Swimlanes/Lanes)

Sơ đồ được phân chia thành 3 làn chính đại diện cho các Actor tương tác:
1. **Member**: Người dùng thực hiện thao tác trên giao diện.
2. **System**: Hệ thống phần mềm tiếp nhận, xử lý logic và lưu trữ dữ liệu.
3. **Staff/VNPay Gateway**: Làn đại diện cho việc xử lý thanh toán (Staff xác nhận tiền mặt hoặc Cổng VNPay xử lý trực tuyến).

---

## 2. Sơ đồ Swimlane Activity Diagram (Mermaid)

```plantuml
@startuml
|Member|
start
:Click Register Package on Portal;
|System|
:Get active Gym Packages;
:Display Register Form;
:Render Gym Packages;
|Member|
:Select Gym Package & Payment Method;
|System|
:JS calculates duration & estimated cost;
|Member|
:Click Register Package button;
|System|
if (Validate input?) then (Valid)
  if (Does Member have package history?) then (Yes)
    :Redirect with error (Use Renew);
    |Member|
    :View error;
    stop
  else (No history)
    |System|
    :StartDate = Today;
  :Record MemberPackage & Invoice (Pending);
  if (INSERT successful?) then (Yes)
    if (Payment Method = VNPay?) then (Yes)
      :Redirect to VNPay Create;
      |Staff/VNPay Gateway|
      :Process VNPay Payment;
    else (No, Cash)
      |System|
      :Redirect to Success Info (Wait Staff);
      |Staff/VNPay Gateway|
      :Staff clicks Confirm Cash Payment;
    endif
  else (No / System error)
|System|
    :Display error;
    |Member|
    :View error;
  endif
  endif
else (Invalid)
|System|
  :Display error;
  |Member|
  :View error;
endif
stop
@enduml
```

---

## 3. Mô tả chi tiết luồng xử lý (Step-by-Step Execution)

### 3.1. Luồng tải dữ liệu đăng ký (GET Request)
1.  **Member** click chọn chức năng "Đăng ký gói tập" từ Menu điều hướng.
2.  Trang Menu gửi yêu cầu `GET /member/register-package` đến Controller.
3.  **Controller** gọi tầng Dịch vụ `gymPackageService.getActivePackages()`.
4.  **GymPackageDAOImpl.getActivePackages()** truy vấn các gói tập có trạng thái hoạt động (`Status = 'Active'`).
5.  **Controller** gán danh sách này vào request attribute `packages`, sau đó forward sang trang giao diện.
6.  Trang giao diện hiển thị form cho phép chọn gói tập và phương thức thanh toán.

### 3.2. Luồng thực hiện Đăng ký & Tạo giao dịch (POST Request)
1.  **Member** chọn thông tin và phương thức thanh toán trên Form đăng ký.
2.  Hệ thống JavaScript phía Client hiển thị ngày bắt đầu dự kiến là ngày hôm nay, tính toán tổng chi phí.
3.  **Member** nhấp nút "Đăng ký".
4.  Giao diện gửi yêu cầu `POST /member/register-package`.
5.  **Controller** trích xuất tham số, kiểm tra tính hợp lệ và gọi `registerMemberPackage(...)` trong **MemberPackageServiceImpl**.
6.  **MemberPackageServiceImpl** thực thi nghiệp vụ bên trong một giao dịch cơ sở dữ liệu (**Database Transaction**):
    *   **Lấy chi tiết Gói tập**: Truy vấn thông tin gói tập bằng `GymPackageDAO.findById()`.
    *   **Rẽ nhánh quyết định (Hội viên đã từng có gói tập?)**: Kiểm tra lịch sử gói tập của hội viên.
        *   *Nếu đã có lịch sử*: Ném ngoại lệ, `rollback` giao dịch và trả về lỗi chặn đăng ký.
    *   **Tạo Gói tập Hội viên tạm thời (`MemberPackage`)**: Thực hiện chèn thông tin đăng ký vào bảng `MemberPackages` với trạng thái `Status = 'Pending'`, `CreatedBy` là "Member Self-Registration".
    *   **Tạo Hóa đơn tạm thời (`Invoice`)**: Chèn thông tin hóa đơn vào bảng `Invoices` với trạng thái `Status = 'Pending'`, `PaymentMethod` được chỉ định. `ProcessBy` là Null.
    *   **Rẽ nhánh quyết định (INSERT thành công?)**:
        *   *Nếu thành công*: Gọi `conn.commit()`. Sau đó, Controller điều hướng:
            - **Member (VNPay)**: Redirect sang URL xử lý thanh toán VNPay `/member/vnpay-create`.
            - **Member (Cash)**: Redirect thông báo cho Member biết đơn đã được ghi nhận.
        *   *Nếu thất bại*: Gọi `conn.rollback()` để hoàn trả trạng thái và ném ngoại lệ báo lỗi.

---

## 4. Sơ đồ Chuyển Trạng Thái Thực Thể (State Transition Diagram)

Bản ghi đăng ký gói tập và hóa đơn tạo ra từ luồng này sẽ kiểm soát trạng thái thông qua các thuộc tính của thực thể:

### 4.1. Chuyển trạng thái thực thể Đăng ký gói tập (`MemberPackage`)
Mỗi nút đại diện cho một trạng thái được biểu diễn bằng **Tính từ (Adjective)**:

```mermaid
stateDiagram-v2
    [*] --> Pending : Create new registration (pending payment)
    Pending --> Active : Record payment invoice successfully (Paid)
    Pending --> SoftDeleted : Cancel invoice (set IsDeleted = 1)
    Active --> Expired : Expiration date passed (EndDate < Current date)
    SoftDeleted --> [*]
    Expired --> [*]
```

### 4.2. Chuyển trạng thái thực thể Hóa đơn (`Invoice`)
```mermaid
stateDiagram-v2
    [*] --> Pending : Initialize invoice (pending payment)
    Pending --> Paid : Confirm payment successfully (Cash or VNPay)
    Pending --> Cancelled : Confirm invoice cancellation
    Paid --> [*]
    Cancelled --> [*]
```

