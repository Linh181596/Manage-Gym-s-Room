# Tài liệu Thiết kế Chi tiết: Swimlane Activity Diagram - Ghi Nhận Thanh Toán (Record Payment - UC-17)

Tài liệu này mô tả chi tiết luồng hoạt động dưới dạng sơ đồ Swimlane Activity Diagram của chức năng **Ghi Nhận Thanh Toán (Record Payment)** dành cho nhân viên lễ tân (**Staff**). Thiết kế tập trung vào việc mô tả cơ chế đồng bộ hóa trạng thái giữa hóa đơn và đăng ký gói tập thông qua giao dịch cơ sở dữ liệu (Transaction) và hỗ trợ in hóa đơn. Thiết kế loại bỏ hoàn toàn các nút Bắt đầu/Kết thúc dư thừa và bổ sung các nút rẽ nhánh quyết định (Quyết định) khi xác thực hóa đơn hợp lệ hoặc kết quả giao dịch.

---

## 1. Thành phần tham gia (Swimlanes/Lanes)

Sơ đồ được phân chia thành 2 làn chính đại diện cho các Actor tương tác:
1. **Actor**: Nhân viên, Quản trị viên hoặc Hội viên thực hiện thao tác.
2. **System**: Hệ thống phần mềm tiếp nhận, xử lý logic và lưu trữ dữ liệu.

---

## 2. Sơ đồ Swimlane Activity Diagram (Mermaid)

```plantuml
@startuml
|Staff|
start
:Access Invoices List;
|System|
:Request list;
:Get all invoices;
:Query all invoices;
:Return invoice list;
:Forward to payment-list.jsp;
:Display list table;
|Staff|
:Click Pay button on an invoice;
|System|
:Request details;
:Get invoice by ID;
:Query invoice by ID;
:Return record;
:Return Entity;
:Return object;
:Forward to payment-record-detail.jsp;
:Display receipt card;
|Staff|
if (Action?) then (Confirm: Cash payment)
|System|
  :Submit POST action=pay;
  :Receive POST action=pay;
  if (Invoice status Pending?) then (Yes)
    :Update invoice Paid & package Active;
    :Confirm update success;
    :Return success;
    if (Update successful?) then (Yes)
      :Redirect to payment detail;
      :Reload Paid invoice details;
      |Staff|
      :Request thermal invoice print;
|System|
      :Print clean receipt;
    else (No)
      :Set error message;
      :Display error;
    endif
  else (No)
    :Set error message;
    :Display error;
  endif
else (Confirm: Cancel invoice)
  :Submit POST action=cancel;
  :Receive POST action=cancel;
  if (Invoice status Pending?) then (Yes)
    :Update invoice Cancelled & soft delete package;
    :Confirm update success;
    :Return success;
    if (Update successful?) then (Yes)
      :Redirect to payment detail;
      :Reload Cancelled invoice details;
    else (No)
      :Set error message;
      :Display error;
    endif
  else (No)
    :Set error message;
    :Display error;
  endif
endif
stop
@enduml
```

---

## 3. Mô tả chi tiết luồng xử lý (Step-by-Step Execution)

### 3.1. Luồng tra cứu hóa đơn (GET Request)
1.  **Staff** truy cập màn hình Danh sách hóa đơn. Trình duyệt gửi yêu cầu `GET /staff/record-payment` đến **RecordPaymentController**.
2.  Controller gọi `invoiceService.getAllInvoices()`. DAO thực thi câu lệnh SQL SELECT để lấy toàn bộ các hóa đơn trong hệ thống:
    ```sql
    SELECT * FROM Invoices ORDER BY CreatedDate DESC
    ```
3.  Controller forward danh sách hóa đơn về **payment-list.jsp**. Trang JSP sử dụng JSTL để duyệt danh sách và hiển thị các badge trạng thái có màu sắc trực quan (Xanh: *Paid*, Vàng: *Pending*, Đỏ: *Cancelled*).
4.  **Staff** click chọn "Thanh toán" ở một dòng hóa đơn để xem chi tiết. Trình duyệt gửi yêu cầu `GET` chứa tham số `invoiceId` lên Controller.
5.  Controller truy vấn chi tiết hóa đơn và forward sang trang phiếu thu **payment-record-detail.jsp** để nhân viên thực hiện thao tác tiếp theo.

### 3.2. Luồng xác nhận thanh toán tiền mặt (POST /staff/record-payment - Action = 'pay')
1.  **Staff** nhận đủ tiền mặt của khách và nhấp nút "Xác nhận thanh toán" trên trang chi tiết hóa đơn.
2.  Trình duyệt gửi yêu cầu `POST /staff/record-payment` kèm tham số `invoiceId` và `action=pay` lên **RecordPaymentController**.
3.  Controller lấy thông tin nhân viên đang đăng nhập từ HTTP Session để làm người xử lý giao dịch (`ProcessedBy`), sau đó gọi phương thức `invoiceService.recordCashPayment(invoiceId, staffUserId)`.
4.  **InvoiceServiceImpl** thực thi nghiệp vụ bên trong một giao dịch cơ sở dữ liệu (**Database Transaction**):
    *   **Mở Giao dịch**: Lấy đối tượng kết nối `conn = DBContext.getConnection()` và thiết lập `conn.setAutoCommit(false)` để kiểm soát giao dịch thủ công.
    *   **Rẽ nhánh quyết định (Hóa đơn trạng thái Pending?)**: Truy vấn hóa đơn từ database và xác thực trạng thái phải là `Pending`. 
        *   *Nếu trạng thái khác Pending*: Chuyển hướng đến **S_Rollback** (Hủy bỏ và ném ngoại lệ về Controller).
        *   *Nếu là Pending*: Thực hiện cập nhật trạng thái Hóa đơn sang 'Paid'.
    *   **Cập nhật trạng thái Hóa đơn**: Thiết lập trạng thái `Status = 'Paid'`, ngày thanh toán `PaymentDate = LocalDateTime.now()`, người thực hiện `ProcessedBy = staffUserId` và lưu cập nhật xuống bảng `Invoices` thông qua `InvoiceDAO.update()`.
    *   **Kích hoạt Gói tập hội viên**: Truy vấn đối tượng `MemberPackage` liên kết với hóa đơn này. Chuyển đổi trạng thái từ `Pending` sang `Active`. Thực hiện lưu cập nhật xuống bảng `MemberPackages` thông qua `MemberPackageDAO.update()`.
    *   **Rẽ nhánh quyết định (Cập nhật thành công?)**:
        *   *Nếu thành công (không có lỗi SQL)*: Gọi `conn.commit()` để lưu thay đổi vĩnh viễn và trả kết quả thành công cho Controller thực hiện Redirect.
        *   *Nếu thất bại (xảy ra lỗi SQL hoặc ngoại lệ)*: Gọi `conn.rollback()` để hoàn trả trạng thái ban đầu của Database nhằm tránh lỗi không nhất quán.
        *   Đóng kết nối `conn.close()`.
5.  Controller nhận kết quả thành công, thực hiện chuyển hướng (`Redirect`) về lại trang chi tiết hóa đơn.
6.  Trang hiển thị hóa đơn đã thanh toán với các nút in. Khi bấm "In hóa đơn", trình duyệt kích hoạt các bộ lọc CSS `@media print` giúp ẩn các thanh điều hướng, banner và các nút bấm để in ra hóa đơn nhiệt hoặc giấy A5 sạch sẽ.

### 3.3. Luồng hủy hóa đơn (POST /staff/record-payment - Action = 'cancel')
1.  Nếu hội viên không muốn đăng ký gói tập nữa hoặc có sai sót thông tin, **Staff** nhấp nút "Hủy hóa đơn" trên trang chi tiết.
2.  Trình duyệt gửi yêu cầu `POST /staff/record-payment` kèm tham số `invoiceId` và `action=cancel` lên **RecordPaymentController**.
3.  Controller gọi phương thức `invoiceService.cancelInvoice(invoiceId, staffUserId)`.
4.  **InvoiceServiceImpl** thực thi nghiệp vụ bên trong một giao dịch cơ sở dữ liệu (**Database Transaction**):
    *   **Mở Giao dịch**: Lấy đối tượng kết nối `conn = DBContext.getConnection()` và thiết lập `conn.setAutoCommit(false)`.
    *   **Rẽ nhánh quyết định (Hóa đơn trạng thái Pending?)**: Truy vấn hóa đơn và đảm bảo trạng thái hiện tại là `Pending`.
        *   *Nếu không phải Pending*: Rollback và hủy bỏ.
        *   *Nếu là Pending*: Cập nhật trạng thái Hóa đơn sang 'Cancelled'.
    *   **Cập nhật trạng thái Hóa đơn**: Thiết lập `Status = 'Cancelled'` (Đã hủy), cập nhật người thực hiện hủy, ghi nhận người cập nhật và lưu thay đổi xuống bảng `Invoices` thông qua `InvoiceDAO.update()`.
    *   **Hủy Gói tập hội viên**: Do cơ sở dữ liệu chỉ chấp nhận trạng thái `Status` là `Pending`, `Active`, `Expired` nên không thể sửa trạng thái gói tập thành *Cancelled*. Thay vào đó, hệ thống thực hiện **Xóa mềm (Soft Delete)** bằng cách gọi `MemberPackageDAO.delete()` để cập nhật trường `IsDeleted = 1` của gói tập hội viên đi kèm.
    *   **Rẽ nhánh quyết định (Cập nhật thành công?)**:
        *   *Nếu thành công*: Gọi `conn.commit()`.
        *   *Nếu có lỗi xảy ra*: Gọi `conn.rollback()`.
        *   Đóng kết nối `conn.close()`.
5.  Controller nhận kết quả thành công, thực hiện chuyển hướng (`Redirect`) về lại trang chi tiết hóa đơn. Hệ thống sẽ vô hiệu hóa tất cả các nút thanh toán hoặc hủy của hóa đơn đó.

---

## 4. Sơ đồ Chuyển Trạng Thái Thực Thể

Quy trình thanh toán ảnh hưởng trực tiếp đến trạng thái của hai thực thể chính:

### 4.1. Chuyển trạng thái thực thể Hóa đơn (`Invoice`)
Các nút biểu diễn bằng **Tính từ (Adjective)**:

```mermaid
stateDiagram-v2
    [*] --> Pending : Temporary invoice created (pending payment)
    Pending --> Paid : Confirm cash payment successfully (Paid)
    Pending --> Cancelled : Confirm invoice cancellation (Cancelled)
    Paid --> [*]
    Cancelled --> [*]
```

### 4.2. Chuyển trạng thái thực thể Đăng ký gói tập (`MemberPackage`)
Các nút biểu diễn bằng **Tính từ (Adjective)**:

```mermaid
stateDiagram-v2
    [*] --> Pending : Temporary member package created (pending activation)
    Pending --> Active : Associated invoice paid successfully (Active)
    Pending --> SoftDeleted : Associated invoice cancelled (Set IsDeleted = 1 - Soft Deleted)
    Active --> Expired : EndDate passed (EndDate < Current date - Expired)
    SoftDeleted --> [*]
    Expired --> [*]
```

