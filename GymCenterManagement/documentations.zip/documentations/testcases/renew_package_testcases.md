# Test Case Document - Renew Package

**Test Requirement:** Verify the system's logic for renewing expired/active packages, ensuring correct duration extensions, fee calculations, and validation rules.

**Description:** Verify package renewal operations: proper extension of package duration, invoice generation, and preventing invalid renewals.

**Pre-condition:** Authenticated accounts (Member) are available. Members with active/expired packages exist.

| Test Case ID | Test Case Description | Test Case Procedure | Expected Results | Pre-conditions | Round 1 | Test date | Tester | Round 2 | Test date | Tester | Round 3 | Test date | Tester | Note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| TC-REN-001 | Display Member Portal | 1. Access member portal (Member).<br>2. View the package validity section. | Displays current package start date, end date. "Gia hạn" (Renew) button displays next to active packages. | Member has an active or expired package. | Pending | | | Pending | | | Pending | | | |
| TC-REN-002 | Renew package successfully | 1. Member clicks "Gia hạn" (Renew).<br>2. Selects a package and VNPay/Cash.<br>3. Click "Gia hạn & Thanh toán". | System generates renewal invoice. Upon payment (VNPay) or staff confirmation (Cash), the `EndDate` is updated directly on the existing package.<br>*DB Verification:*<br>`SELECT * FROM Invoices WHERE Status = 'Pending'`.<br>`MemberPackages` table DOES NOT create a new pending record. | Package is Active or expired and remaining time is <= 1 month. | Pending | | | Pending | | | Pending | | | |
| TC-REN-003 | Block renewing package if remaining time > 1 month | 1. Member views Portal (package expires in 2 months).<br>2. Click "Gia hạn". | System blocks request, redirects to portal and displays error message "Bạn chỉ có thể gia hạn khi gói tập hiện tại còn thời hạn dưới 1 tháng." | Member's most recent package expires in > 1 month. | Pending | | | Pending | | | Pending | | | |
