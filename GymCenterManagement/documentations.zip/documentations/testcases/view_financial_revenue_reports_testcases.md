# Test Case Document - View Financial Revenue Reports

**Test Requirement:** Verify the Admin's ability to view accurate financial reports and charts, ensuring correct aggregation of revenue by time period, package type, and PT services, handling of empty data gracefully.

**Description:** Verify financial and revenue reporting dashboard: accurate revenue calculations, chart rendering, data grouping (daily/monthly/yearly), and role-based access restrictions.

**Pre-condition:** An authenticated Admin is available. Test data covers memberships, invoices, Gym/PT revenue, and completed payments across relevant dates.

| Test Case ID | Test Case Description | Test Case Procedure | Expected Results | Pre-conditions | Round 1 | Test date | Tester | Round 2 | Test date | Tester | Round 3 | Test date | Tester | Note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| TC-REP-001 | Display default Revenue Dashboard (Admin) | 1. Log in with Admin privileges.<br>2. Access `/admin/revenue-reports`. | Displays Dashboard interface. Overview metrics (Total revenue this month, total orders) display accurately. <br>*DB Verification:* Total revenue matches `SUM(Amount)` of `Invoices` table for current month (Status='Paid'). | System has successful payment data in the month. | Pending | | | Pending | | | Pending | | | |
| TC-REP-002 | Filter reports by Month/Year | 1. At filter, select Month 06, Year 2026.<br>2. Click "Filter" or "Apply". | Table and chart update according to June 2026 data. <br>*DB Verification:* `SELECT SUM(Amount) FROM Invoices WHERE Status='Paid' AND MONTH(CreatedDate)=6 AND YEAR(CreatedDate)=2026` matches the total number. | Data exists in June 2026. | Pending | | | Pending | | | Pending | | | |
| TC-REP-003 | Check consistency between Chart and Table | 1. Choose to display 1 year report.<br>2. Compare figures of each column (month) on chart with corresponding figures in the detailed table below. | Figures on Chart (Chart.js / ApexCharts) match 100% with data displayed in the Grid Table below. | Currently on report screen. | Pending | | | Pending | | | Pending | | | |
| TC-REP-004 | Handle empty data (Empty State) | 1. Filter reports into a future date (e.g., Year 2099). | System does not report crash error. User-friendly interface displayed: "No data in this time period". Empty chart. | Currently on report screen. | Pending | | | Pending | | | Pending | | | |
| TC-REP-005 | Test role-based access control | 1. Log in with Staff or Member account.<br>2. Intentionally access URL `/admin/revenue-reports`. | System blocks access, reports `403 Forbidden` error. User cannot view any sensitive data. | Valid Staff/Member account. | Pending | | | Pending | | | Pending | | | |
| TC-REP-006 | Export reports to Excel/PDF file (If any) | 1. Click "Export to Excel" (Or PDF) button.<br>2. Open downloaded file to compare. | Downloaded file is not corrupted. Internal data perfectly matches data displayed on web. Correct format. | Export feature is enabled. | Pending | | | Pending | | | Pending | | | |
| TC-REP-007 | Handle Injection on date filter parameters | 1. Change param on URL to: `?year=2026; DROP TABLE Invoices--` | System catches format error (Validation). Destructive statement is not executed, returns 400 Bad Request error code. | Currently on report page. | Pending | | | Pending | | | Pending | | | |
