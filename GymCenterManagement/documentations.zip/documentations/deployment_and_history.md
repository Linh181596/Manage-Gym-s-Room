# 📋 LỊCH SỬ PHÁT TRIỂN & HƯỚNG DẪN TRIỂN KHAI DỰ ÁN (GCMS)

Tài liệu này cung cấp chi tiết về lịch sử phát triển code, phân chia các tính năng theo module trong hệ thống **Gym Center Management System (GCMS)**, cùng với hướng dẫn từng bước để triển khai (deploy) dự án trên môi trường local cho lập trình viên mới (New User).

---

## Part 1: Lịch Sử Commit & Merge Code (Commit & Merge History)

Dưới đây là bảng ghi nhận lịch sử commit và merge code trên hệ thống quản lý mã nguồn Git, được phân tích trực tiếp từ dữ liệu repository:

### 1. Nhật ký Git Commit & Merge

| Mã Commit (SHA) | Người Thực Hiện (Author) | Ngày Commit (Date) | Nội dung Commit & Merge |
| :--- | :--- | :--- | :--- |
| `7b29861` | VPGreenLight | 2026-07-17 | feature: Add financial revenue report feature (Báo cáo doanh thu tài chính) |
| `f703cfe` | VPGreenLight | 2026-06-26 | feat(package-payment): implement renew & transfer package, view payment history, and sync docs |
| `75f512f` | VPGreenLight | 2026-06-03 | feat(payment): trien khai ghi nhan thanh toan va in hoa don (UC-17) |
| `ce97525` | VPGreenLight | 2026-06-03 | feat(package): trien khai chuc nang dang ky goi tap cho hoi vien (UC-16) |
| `b97fff8` | VPGreenLight | 2026-06-03 | feat(package): trien khai chuc nang CRUD quan ly goi tap (UC-15) |
| `733286b` | VPGreenLight | 2026-05-28 | Update README.md (Cập nhật tài liệu cấu trúc và quy tắc) |
| `300ed4b` | VPGreenLight | 2026-05-28 | Update .gitignore (Tối ưu hóa các file bỏ qua khi push code) |
| `d5a6e19` | VPGreenLight | 2026-05-21 | refactor: Initial gym center management app skeleton (Tạo bộ khung cấu trúc dự án MVC 3 lớp Jakarta EE 10) |
| `27badc7` | VPGreenLight | 2026-05-21 | refactor: Exclude static templates and documentations as requested |
| `36e385f` | VPGreenLight | 2026-05-21 | refactor: Add .gitignore with common IDE and build ignores |
| `6f9cd13` | Nguyen Tri Linh (K18 Hl) | 2026-05-12 | Initial commit (Khởi tạo repo và cấu hình ban đầu) |

---

### 2. Danh Sách Tính Năng Theo Module (Module Features)

Mã nguồn dự án GCMS được tổ chức theo cấu trúc MVC 3 lớp kết hợp phân quyền RBAC (Role-Based Access Control) cho 4 nhóm đối tượng chính. Chi tiết các tính năng của từng module như sau:

#### 🔐 Module Hệ Thống & Xác Thực (System & Authentication)
- **Đăng nhập (`/login`)**: Cho phép người dùng nhập Email và Mật khẩu để truy cập hệ thống.
  - *Demo Bypass*: Có sẵn tài khoản dùng thử không qua cơ sở dữ liệu để test nhanh giao diện (Admin, Staff, Member).
- **Đăng xuất (`/logout`)**: Hủy session hiện tại và chuyển hướng về trang đăng nhập.
- **Bộ lọc mã hóa (`EncodingFilter`)**: Tự động cấu hình request/response về bảng mã UTF-8.
- **Bộ lọc bảo mật & phân quyền (`AuthenticationFilter`)**: Ngăn chặn truy cập trái phép và kiểm tra quyền truy cập (RBAC) đối với các thư mục `/admin/*`, `/staff/*`, `/member/*`, `/pt/*`.

#### 👑 Module Quản Trị Viên (Admin Module - `/admin/*`)
- **Dashboard quản trị (`/admin/dashboard`)**:
  - Hiển thị các chỉ số KPI: Tổng số hội viên (Total Members), Huấn luyện viên đang hoạt động (Active PTs), Lịch học hôm nay (Today Classes), Doanh thu tháng này (Monthly Revenue).
  - Biểu đồ thống kê lượng đăng ký hội viên theo tháng.
  - Biểu đồ phân tích doanh thu (so sánh giữa Hội phí và phí PT).
  - Danh sách người dùng mới đăng ký gần đây.
  - Lịch hoạt động của trung tâm (Gym Calendar).
  - Danh sách việc cần làm của Admin (Admin Tasks List).
- **Quản lý người dùng (Manage Users)**: Xem danh sách, thêm mới, sửa thông tin, xóa (soft-delete) và thay đổi trạng thái tài khoản.
- **Quản lý thiết bị (Gym Equipment)**: Quản lý danh mục thiết bị, số lượng, tình trạng sử dụng và lịch bảo trì.
- **Quản lý lớp học & lịch trình (Classes & Schedule)**: Tạo, cập nhật và sắp xếp lịch các lớp học nhóm.
- **Báo cáo doanh thu (Reports)**: Xuất báo cáo tài chính, biểu đồ tăng trưởng.

#### 👥 Module Nhân Viên (Staff Module - `/staff/*`)
- **Dashboard nhân viên (`/staff/dashboard`)**: Quản lý nhanh các hoạt động Check-in và đăng ký trong ngày.
- **Điểm danh khách hàng (Check-in)**: Check-in cho hội viên bằng mã thẻ/ID khi đến phòng tập.
- **Đăng ký hội viên mới (Registrations)**: Đăng ký tài khoản, phát hành thẻ hội viên mới.
- **Quản lý đặt lịch (Bookings)**: Hỗ trợ hội viên đặt lịch lớp học hoặc lịch tập cá nhân tại quầy.

#### 💪 Module Huấn Luyện Viên Cá Nhân (PT Module - `/pt/*`)
- **Dashboard huấn luyện viên (`/pt/dashboard`)**: Xem danh sách buổi tập trong ngày và lịch hẹn tiếp theo.
- **Quản lý học viên (My Clients)**: Theo dõi danh sách học viên đang phụ trách, chỉ số sức khỏe (BMI, cân nặng, tỷ lệ mỡ).
- **Lịch huấn luyện (Sessions)**: Sắp xếp các khung giờ trống và ghi nhận buổi dạy đã hoàn thành.
- **Thiết lập giáo án (Workout Plans)**: Thiết lập chế độ tập luyện và dinh dưỡng cá nhân hóa cho từng hội viên.

#### 🎯 Module Hội Viên (Member Module - `/member/*`)
- **Dashboard hội viên (`/member/dashboard`)**: Xem trạng thái gói tập, lịch tập cá nhân và thông tin PT đang hướng dẫn.
- **Đặt lịch lớp học (Book Class)**: Đăng ký tham gia các lớp học nhóm (Yoga, Zumba, Cardio...).
- **Đăng ký tập với PT (Book PT)**: Xem danh sách PT, đánh giá, khung giờ trống và gửi yêu cầu đặt lịch tập cá nhân.
- **Quản lý gói tập (Membership)**: Đăng ký mới, gia hạn hoặc nâng cấp gói tập.

---

## Part 2: Hướng Dẫn Deploy Dự Án Cho Lập Trình Viên Mới (Deployment Tutorial)

Quy trình hướng dẫn lập trình viên mới cấu hình môi trường và chạy dự án GCMS trên máy local:

### 1. Tải Source Code từ Git về máy
Sử dụng Git Client để clone mã nguồn của dự án từ repository chính thức:
```bash
git clone https://gitlab.com/linhnthe181596/manage-gym.git
```
*Lưu ý:* Sau khi clone, hãy chuyển sang nhánh phát triển được giao (thường là `dev` hoặc nhánh `feature/` cá nhân). Không làm việc trực tiếp trên nhánh `main`.

---

### 2. Chuẩn bị Môi trường cài đặt (Prerequisites)
Bạn cần cài đặt các công cụ sau trước khi tiến hành deploy:

| Công cụ / Thư viện | Phiên bản yêu cầu | Vai trò |
| :--- | :--- | :--- |
| **Java Development Kit (JDK)** | JDK 11 hoặc mới hơn (Khuyến nghị sử dụng JDK 11 hoặc JDK 21) | Trình biên dịch mã nguồn Java |
| **Apache Maven** | 3.6.0+ | Quản lý dependency và đóng gói build file `.war` |
| **Cơ sở dữ liệu** | Microsoft SQL Server (2016 trở lên) | Hệ quản trị cơ sở dữ liệu lưu trữ thông tin hệ thống |
| **Web Server** | Apache Tomcat 10+ (tương thích Jakarta EE 10) | Servlet Container để host ứng dụng |
| **IDE khuyến nghị** | NetBeans 17+, IntelliJ IDEA, hoặc Eclipse | Môi trường lập trình tích hợp |

---

### 3. Cấu hình Cơ sở dữ liệu (Database Setup)
1. Mở **SQL Server Management Studio (SSMS)**.
2. Tạo một cơ sở dữ liệu mới có tên: `GymCenterManagement`.
3. Chạy script SQL khởi tạo cơ sở dữ liệu (bao gồm các bảng `users`, `equipment`, `classes`...) và chèn dữ liệu mẫu nếu có.
4. Kiểm tra cấu hình tường lửa và cổng kết nối của SQL Server (mặc định là cổng `1433`). Đảm bảo tùy chọn **SQL Server and Windows Authentication mode** đã được kích hoạt.

---

### 4. Cấu hình Kết nối API & Database trong Code
Dự án sử dụng file cấu hình properties để thiết lập kết nối cơ sở dữ liệu.

1. Tìm file cấu hình tại đường dẫn: 
   `GymCenterManagement/src/main/resources/db.properties`
2. Cập nhật các thông số phù hợp với cấu hình SQL Server trên máy cá nhân của bạn:
   ```properties
   # Microsoft SQL Server Database Configuration
   db.driver=com.microsoft.sqlserver.jdbc.SQLServerDriver
   db.url=jdbc:sqlserver://localhost:1433;databaseName=GymCenterManagement;encrypt=true;trustServerCertificate=true;
   db.username=sa
   db.password=your_secure_password_here
   ```
   *Giải thích cấu hình:*
   - `encrypt=true;trustServerCertificate=true;` là cấu hình bắt buộc khi kết nối với Microsoft SQL Server sử dụng driver JDBC mới để bỏ qua xác thực SSL tự ký từ local server.
   - Thay đổi `db.username` và `db.password` khớp với tài khoản SQL Server của bạn.

---

### 5. Thư viện và API trực tuyến (Online API & CDN Configurations)
Hệ thống sử dụng một số thư viện và tài nguyên CDN trực tuyến để tối ưu hiệu năng tải trang và hiển thị giao diện:

- **Google Web Fonts**: Sử dụng font chữ **Heebo** và **Outfit** tải trực tiếp qua CDN:
  - `https://fonts.googleapis.com`
  - `https://fonts.gstatic.com`
- **Icon Libraries**:
  - Font Awesome 5: `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css`
  - Bootstrap Icons: `https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css`
- **Frontend Framework / UI**:
  - Bootstrap 5.0.0 (CSS/JS bundle): `https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js`
  - jQuery 3.4.1: `https://code.jquery.com/jquery-3.4.1.min.js`
  
*Lưu ý khi deploy:* Máy chủ chạy ứng dụng hoặc máy của lập trình viên cần có kết nối Internet để tải các tài nguyên CDN này khi giao diện hiển thị.

---

### 6. Build và Run ứng dụng trên môi trường Local
Các bước thực hiện trên IDE (ví dụ NetBeans hoặc IntelliJ):

1. **Import dự án**:
   - Chọn **Open Project** trong IDE và trỏ đến thư mục `GymCenterManagement` (nơi chứa file `pom.xml`).
   - IDE sẽ tự động nhận diện đây là dự án Maven và tiến hành tải các dependencies khai báo trong `pom.xml`.

2. **Build dự án**:
   - Mở Terminal tại thư mục `GymCenterManagement` và chạy lệnh:
     ```bash
     mvn clean install
     ```
   - Lệnh này sẽ biên dịch mã nguồn Java, kiểm tra cấu trúc và đóng gói ứng dụng thành file `GymCenterManagement-1.0-SNAPSHOT.war` đặt trong thư mục `target/`.

3. **Cấu hình Web Server (Apache Tomcat)**:
   - Trong IDE, thêm cấu hình **Apache Tomcat Server** (Trỏ đến thư mục cài đặt Tomcat 10+ của bạn).
   - Thiết lập **Context Path** của ứng dụng là `/GymCenterManagement` (hoặc `/`).

4. **Deploy & Chạy ứng dụng**:
   - Nhấp chuột phải vào dự án chọn **Run** hoặc **Debug**. IDE sẽ tự động deploy file WAR lên Tomcat và khởi chạy máy chủ.
   - Mở trình duyệt và truy cập vào đường dẫn:
     ```text
     http://localhost:8080/GymCenterManagement/
     ```

5. **Đăng nhập dùng thử (Demo Accounts)**:
   Bạn có thể đăng nhập thử nghiệm bằng các tài khoản bypass cứng sau đây mà không cần cài đặt đầy đủ DB trước:
   - **Tài khoản Admin**: 
     - Email: `admin@gym.com`
     - Mật khẩu: `admin123`
   - **Tài khoản Nhân viên (Staff)**: 
     - Email: `staff@gym.com`
     - Mật khẩu: `staff123`
   - **Tài khoản Hội viên (Member)**: 
     - Email: `member@gym.com`
     - Mật khẩu: `member123`
