# 📋 DỰ ÁN GCMS - NHẬT KÝ THEO DÕI GIT COMMIT & LỊCH SỬ MERGE CODE

Tài liệu này ghi nhận toàn bộ lịch sử các commit, các phiên làm việc nhóm (Merge Pull Request), và dấu mốc phát triển các tính năng trong hệ thống **Gym Center Management System (GCMS)**.

---

## 🔍 Tổng Quan Môi Trường Mã Nguồn
- **Nhánh Hiện Tại (Current Branch)**: `thangnh` (nhánh đang phát triển chính)
- **Tổng số Commit phân tích**: 60 commits gần nhất
- **Thời gian phân tích cuối**: 2026-06-12 09:47:00 (Local Time)

---

## 📈 Sơ Đồ Nhánh & Lịch Sử Merge Code (Merge History)

Dưới đây là danh sách các hoạt động Merge Pull Request nổi bật từ nhánh phát triển nhánh con vào nhánh `develop`, `main` và `thangnh`:

* **Merge Pull Request #13** (`34898e1`): Hợp nhất nhánh `thangnh` vào `develop`.
* **Merge Pull Request #12** (`05089c9`): Đồng bộ hóa các thay đổi mới nhất của nhánh `thangnh` để sửa đổi trạng thái gói tập và tính năng gia hạn.
* **Merge Pull Request #11** (`d4886fd`): Hợp nhất sửa lỗi Equipment Report, cache tối ưu hóa Database Metadata, điều hướng phân hệ.
* **Merge Pull Request #10** (`344e47a`): Hợp nhất toàn bộ các tính năng Iteration 1 của Huấn luyện viên cá nhân (`phund/iter1-personal-trainer`).
* **Merge Pull Request #9** (`af1b193`): Hợp nhất PT Iteration 1 vào nhánh chính `main`.
* **Merge Pull Request #8** (`1d53b82`): Đồng bộ hóa luồng PT Iteration 1.
* **Merge Pull Request #7** (`43a19f1`): Tích hợp hoàn tất phân hệ Xác thực (`duongnd`) vào hệ thống chính.
* **Merge Pull Request #6** (`f5377ae`): Đồng bộ layout hiển thị, gỡ bỏ footer, URL-encode redirect query parameter để sửa lỗi trang trắng.
* **Merge Pull Request #5** (`c2019d4`): Gộp nhánh PT của Phú vào nhánh chung của Thắng.
* **Merge Pull Request #4** (`5f6c391`) & **#3** (`5ac7f2b`): Hoàn tất revert và merge nhánh quản lý thiết bị của Đỗ Minh Hoàng (`hoangdmhe`).

---

## 📝 Nhật Ký Chi Tiết Git Commit Tracking (Commit Log)

Dưới đây là chi tiết các commit được theo dõi theo trình tự thời gian (từ mới nhất đến cũ nhất):

| Mã Commit | Người Thực Hiện (Author) | Thời Gian (Date & Time) | Nội Dung Commit |
| :---: | :--- | :---: | :--- |
| `3801fdb` | Nguyễn Hoàng Thắng | 2026-06-12 09:46:45 | fix: remove UTF-8 BOM from Java and JSP source files to resolve compilation errors |
| `d5cc8e5` | Nguyễn Hoàng Thắng | 2026-06-12 09:23:47 | fix(portal): remove Edit Personal Info button from Member Portal page |
| `d4aa726` | Nguyễn Hoàng Thắng | 2026-06-12 09:13:45 | docs: rename author duongnd to Nguyễn Đại Dương in file comments |
| `d60c6c5` | Nguyễn Hoàng Thắng | 2026-06-12 09:12:27 | docs: rename author Đào Minh Hoàng to Đỗ Minh Hoàng in file comments |
| `3f9f27e` | Nguyễn Hoàng Thắng | 2026-06-12 09:11:18 | docs: rename author Nguyễn Thành Linh to Nguyễn Trí Linh in file comments |
| `6fe2333` | Nguyễn Hoàng Thắng | 2026-06-12 09:06:40 | feat(auth): add Locked status check to block login |
| `9eaaac1` | Nguyễn Hoàng Thắng | 2026-06-11 22:59:45 | feat(finance,auth): add cancel pending invoice feature and refactor portal-profile navigation |
| `b84b457` | Nguyễn Hoàng Thắng | 2026-06-11 21:43:42 | refactor: fix authentication |
| `0471b05` | Nguyễn Hoàng Thắng | 2026-06-11 12:18:55 | feat(auth): di trú và tích hợp phân hệ Xác thực & Hồ sơ cá nhân từ nhánh duongnd |
| `05089c9` | Nguyễn Hoàng Thắng | 2026-06-11 12:17:40 | Merge pull request #12 from Nguyễn Trí Linh/thangnh |
| `5ef2e00` | Nguyễn Hoàng Thắng | 2026-06-11 11:38:22 | feat: fix package expiration, duplication, and dynamic status badges |
| `74eb262` | Nguyễn Hoàng Thắng | 2026-06-09 11:47:56 | refactor: remove unused private method findPackageId from GymDAO |
| `3bf1638` | Nguyễn Hoàng Thắng | 2026-06-09 11:45:58 | fix: redirect available equipment reports to details page and keep admin report navigation context |
| `176243d` | Nguyễn Hoàng Thắng | 2026-06-09 11:31:42 | fix: enforce mustChangePassword redirection flow on login and authentication filter |
| `d4886fd` | Nguyễn Hoàng Thắng | 2026-06-09 11:29:05 | Merge pull request #11 from Nguyễn Trí Linh/thangnh |
| `05637dc` | Nguyễn Hoàng Thắng | 2026-06-09 11:28:06 | fix: adjust admin equipment report detail links, clean up console charts error, optimize DB metadata check caching, and align navigation flows |
| `344e47a` | Nguyễn Hoàng Thắng | 2026-06-09 11:26:56 | Merge pull request #10 from Nguyễn Trí Linh/phund/iter1-personal-trainer |
| `69596c2` | Nguyễn Đình Phú | 2026-06-09 11:18:31 | chore: redirect root path to login page |
| `40aae9a` | Nguyễn Hoàng Thắng | 2026-06-09 10:28:30 | Merge remote-tracking branch 'origin/duongnd' into thangnh |
| `ad5148d` | Nguyễn Đại Dương | 2026-06-09 07:09:01 | save current work |
| `49ae5ae` | Nguyễn Đình Phú | 2026-06-08 20:37:04 | Merge remote-tracking branch 'origin/develop' into phund/iter1-personal-trainer |
| `0cde6b3` | Nguyễn Hoàng Thắng | 2026-06-08 11:45:10 | refactor(mail): tach cau truc SMTP credentials ra mail.properties |
| `4cc8e76` | Nguyễn Đình Phú | 2026-06-08 09:02:36 | feat(pt): Fix author comment |
| `1d53b82` | Nguyễn Hoàng Thắng | 2026-06-07 23:41:27 | Merge pull request #8 from Nguyễn Trí Linh/phund/iter1-personal-trainer |
| `4343682` | Nguyễn Đình Phú | 2026-06-07 23:30:22 | feat(pt): complete PT iteration 1 flows |
| `28fc633` | Nguyễn Đình Phú | 2026-06-07 19:01:25 | Merge remote-tracking branch 'origin/develop' into phund/iter1-personal-trainer |
| `06a0d1c` | Nguyễn Đình Phú | 2026-06-07 18:54:43 | Merge branch 'phund/iter1-personal-trainer' of https://github.com/Nguyễn Trí Linh/Manage-Gym-s-Room into phund/iter1-personal-trainer |
| `c20f8cf` | Nguyễn Đình Phú | 2026-06-07 18:54:41 | db: update database schema for gym center management |
| `55babb7` | Nguyễn Hoàng Thắng | 2026-06-06 23:37:58 | feat(auth): tai cau truc va tich hop phan he xac thuc vao GymCenterManagement |
| `43a19f1` | Nguyễn Đại Dương | 2026-06-06 21:13:34 | Merge pull request #7 from Nguyễn Trí Linh/duongnd |
| `69f866b` | Nguyễn Đại Dương | 2026-06-06 19:07:23 | iter1 |
| `f5377ae` | Nguyễn Hoàng Thắng | 2026-06-05 21:06:04 | Merge pull request #6 from Nguyễn Trí Linh/thangnh |
| `0ee5c04` | Nguyễn Hoàng Thắng | 2026-06-05 20:59:03 | style(layout): remove footer section |
| `c69fb98` | Nguyễn Hoàng Thắng | 2026-06-05 20:49:05 | fix(payment): URL-encode redirect query parameter to resolve white page error |
| `e458be2` | Nguyễn Hoàng Thắng | 2026-06-05 09:07:09 | fix: resolve equipment issue EL syntax error, fix sidebar highlighting, and fix PT registration database schema mismatch |
| `c36862f` | Nguyễn Hoàng Thắng | 2026-06-05 00:11:34 | style(header): add file ownership headers to java and jsp files for group members |
| `c98ffda` | Nguyễn Hoàng Thắng | 2026-06-05 00:03:43 | style(sidebar): widen sidebar to 280px to prevent text wrapping in long menus |
| `a128a47` | Nguyễn Hoàng Thắng | 2026-06-04 23:52:39 | fix(jsp): resolve syntax error in equipment select dropdown |
| `42e2bf1` | Nguyễn Hoàng Thắng | 2026-06-04 23:05:07 | feat: Clean workspace and integrate PT, Equipment, and Member portal modules into GymCenterManagement Maven project |
| `c2019d4` | Nguyễn Hoàng Thắng | 2026-06-04 22:55:02 | Merge pull request #5 from Nguyễn Trí Linh/phund/iter1-personal-trainer |
| `5782f51` | Nguyễn Hoàng Thắng | 2026-06-04 22:54:49 | Merge branch 'develop' into phund/iter1-personal-trainer |
| `7721cd7` | Nguyễn Hoàng Thắng | 2026-06-04 22:17:10 | Reapply "Inter 1 - " |
| `e3e8381` | Nguyễn Đình Phú | 2026-06-04 22:02:13 | feat(pt): add PT JSP screens for iteration 1 |
| `c5c7fcb` | Nguyễn Đình Phú | 2026-06-04 22:01:41 | feat(pt): add PT servlets for iteration 1 flows |
| `c99e971` | Nguyễn Đình Phú | 2026-06-04 22:01:15 | feat(pt): add DAO support for PT account and service registration |
| `f99ce08` | Nguyễn Đình Phú | 2026-06-04 22:00:46 | feat(pt): update PT models and password utility |
| `39b7ca9` | Nguyễn Đình Phú | 2026-06-04 21:59:17 | chore(pt): remove obsolete online PT application flow |
| `6f99678` | Nguyễn Đình Phú | 2026-06-04 21:57:07 | chore(db): update PT database schema |
| `73f3eb2` | Nguyễn Hoàng Thắng | 2026-06-04 21:55:19 | Revert "Merge pull request #1 from Nguyễn Trí Linh/LinhNT/inter1" |
| `5ac7f2b` | Nguyễn Hoàng Thắng | 2026-06-04 21:49:05 | Merge pull request #3 from Nguyễn Trí Linh/hoangdmhe |
| `5f6c391` | Nguyễn Hoàng Thắng | 2026-06-04 21:47:28 | Merge pull request #4 from Nguyễn Trí Linh/revert-1-LinhNT/inter1 |
| `16a3042` | Nguyễn Hoàng Thắng | 2026-06-04 21:47:09 | Revert "Inter 1 - " |
| `33e98ad` | Nguyễn Hoàng Thắng | 2026-06-04 21:46:38 | Merge pull request #1 from Nguyễn Trí Linh/LinhNT/inter1 |
| `6c7cd11` | Nguyễn Hoàng Thắng | 2026-06-04 21:42:19 | Merge branch 'thangnh' into develop |
| `0d6ba3f` | Đỗ Minh Hoàng | 2026-06-04 20:38:40 | Merge branch 'hoangdmhe' of https://github.com/Nguyễn Trí Linh/Manage-Gym-s-Room into hoangdmhe |
| `59b7a72` | Đỗ Minh Hoàng | 2026-06-04 20:29:22 | Manage Equipment Manage Equipment Issues View Equipment Reports ver1.0 |
| `5f162a3` | Nguyễn Trí Linh | 2026-06-04 19:48:21 | Merge branch 'LinhNT/inter1' of https://github.com/Nguyễn Trí Linh/Manage-Gym-s-Room into LinhNT/inter1 |
| `cc0cea7` | Nguyễn Trí Linh | 2026-06-04 19:44:51 | Inter 1 |
| `b6d405a` | Nguyễn Hoàng Thắng | 2026-06-04 17:10:04 | Merge branch 'thangnh' of https://github.com/Nguyễn Trí Linh/Manage-Gym-s-Room into thangnh |
| `4436449` | Nguyễn Đình Phú | 2026-06-03 21:11:44 | feat(database): update PT management schema |
| `e19437a` | Nguyễn Hoàng Thắng | 2026-06-03 16:01:52 | feat(localization): dịch toàn bộ giao diện sang tiếng Việt và sửa lỗi giao diện |

---
*Bản ghi tự động trích xuất bằng Git CLI.*
