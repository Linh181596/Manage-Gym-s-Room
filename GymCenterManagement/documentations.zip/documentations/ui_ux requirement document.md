# **TÀI LIỆU ĐẶC TẢ THIẾT KẾ UI/UX (UI/UX DESIGN SPECIFICATION)**

## **DỰ ÁN: GYM CENTER MANAGEMENT SYSTEM (GCMS)**

Tài liệu này cung cấp các đặc tả chi tiết về mặt giao diện (UI), trải nghiệm người dùng (UX), hệ thống phong cách (Style Guide) và logic nghiệp vụ tương tác trên giao diện của dự án **Gym Center Management System (GCMS)**. Tài liệu đóng vai trò cầu nối kỹ thuật giúp đội ngũ Phát triển (Developer) và Kiểm thử (QA/QC) triển khai và đối chiếu giao diện chuẩn xác nhất.

## **1\. TỔNG QUAN DỰ ÁN (PROJECT OVERVIEW)**

* ---

  **Mục tiêu hệ thống:** GCMS là hệ thống Web-based quản lý vận hành phòng Gym, tối ưu hóa các quy trình từ quản lý thành viên, huấn luyện viên cá nhân (PT), lịch học, thiết bị phòng tập đến theo dõi doanh thu và báo cáo tổng quan.  
* **Đối tượng sử dụng (User Personas):**  
  * **Admin:** Quản trị viên tối cao của trung tâm gym, có toàn quyền cấu hình hệ thống, quản lý người dùng và xem báo cáo doanh thu.  
  * **Staff:** Nhân viên quầy lễ tân/chăm sóc khách hàng, hỗ trợ đăng ký thẻ, xếp lịch tập.  
  * **PT (Personal Trainer):** Huấn luyện viên cá nhân, quản lý khách hàng của mình, đăng ký lịch trống.  
  * **Member:** Hội viên phòng tập, xem lịch học, đặt lịch tập với PT và theo dõi lịch sử thẻ.  
* **Phạm vi thiết kế:** Ứng dụng chạy trên nền tảng Web (Web-based Application), giao diện Responsive tối ưu hóa tốt nhất trên màn hình Desktop (1920x1080) và hỗ trợ co giãn tốt trên máy tính bảng (Tablet) & điện thoại di động (Mobile).

## **2\. HƯỚNG DẪN PHONG CÁCH THIẾT KẾ (DESIGN SYSTEM / STYLE GUIDE)**

---

Đảm bảo tính nhất quán (Consistency) của toàn bộ hệ thống bằng việc tuân thủ các quy tắc màu sắc, kiểu chữ và lưới khoảng cách dưới đây:

### **2.1. Bảng màu (Color Palette)**

Hệ thống sử dụng bảng màu hiện đại, tối giản nhưng đậm chất thể thao, kết hợp tông nền xám sáng thanh lịch và các điểm nhấn xanh dương năng động:

| Loại Màu | Tên Màu | Mã HEX | Vai Trò & Vị Trí Áp Dụng   |
| :---- | :---- | :---- | :---- |
| **Primary** | Electric Blue | \#009cff | Màu chủ đạo: Nút bấm hành động chính (CTA), link liên kết, trạng thái đang kích hoạt (Active/Selected) của Sidebar Menu. |
| **Secondary** | Dark Slate | \#1e293b | Tông màu chữ chính (Primary Text), tiêu đề lớn, màu của Sidebar Background và Logo. |
| **Background** | Light Gray | \#f3f6f9 | Màu nền chung cho toàn màn hình dashboard giúp làm nổi bật các thẻ (Cards) màu trắng bên trên. |
| **Card / Surface** | Pure White | \#ffffff | Màu nền của các Form đăng nhập, các khối nội dung (Cards), biểu đồ và bảng dữ liệu. |
| **Text Muted** | Slate Gray | \#6c757d | Dùng cho chữ phụ, phụ đề, ghi chú, placeholder và icon trạng thái chưa active. |
| **Success** | Forest Green | \#198754 | Trạng thái "Active" của tài khoản, thông báo thành công. |
| **Danger / Error** | Crimson Red | \#dc3545 | Các cảnh báo lỗi hệ thống, form nhập liệu sai, trạng thái "Inactive". |

### **2.2. Kiểu chữ (Typography)**

Hệ thống sử dụng font chữ Google Font **Heebo** (hoặc Sans-serif hệ thống) mang phong cách trẻ trung, hiện đại và rất dễ đọc trên mọi độ phân giải.

* **Font Family:** 'Heebo', sans-serif  
* **Tiêu đề trang (H1 / Page Title):** Size 24px | Font-weight: 700 (Bold) | Color: \#1e293b  
* **Tiêu đề mục (H2 / Card Title):** Size 18px | Font-weight: 600 (Semi-Bold) | Color: \#1e293b  
* **Chữ nội dung chính (Body Text):** Size 14px | Font-weight: 400 (Regular) | Color: \#1e293b  
* **Chữ phụ & Ghi chú (Muted Text):** Size 13px | Font-weight: 400 (Regular) | Color: \#6c757d

### **2.3. Iconography (Hệ thống biểu tượng)**

* Sử dụng thư viện icon **FontAwesome (v5+)** hoặc **Bootstrap Icons** để đồng bộ dạng Vector SVG.  
* Kích thước tiêu chuẩn cho icon trong Dashboard Cards: 28px \- 32px, màu xanh dương (\#009cff) trên nền tròn xanh nhạt để tạo chiều sâu thị giác.

### **2.4. Hệ thống lưới và khoảng cách (Grid & Spacing)**

* Sử dụng hệ thống lưới Flexbox & Grid chuẩn CSS.  
* **Spacing Unit:** Quy định hệ số khoảng cách dựa trên bội số của 8 (8px, 16px, 24px, 32px).  
  * **Padding trong thẻ (Card Padding):** Tiêu chuẩn là 24px (tất cả 4 hướng).  
  * **Gap giữa các Card:** 24px.  
  * **Border Radius (Bo góc):** Các thẻ nội dung và nút bấm lớn được bo nhẹ góc với bán kính 6px hoặc 8px để tạo sự mềm mại, hiện đại.

## **3\. ĐẶC TẢ CHI TIẾT TỪNG MÀN HÌNH (SCREEN SPECIFICATIONS)**

### ---

**3.1. MÀN HÌNH ĐĂNG NHẬP (SIGN IN SCREEN)**

Màn hình đầu tiên người dùng tiếp cận khi truy cập hệ thống GCMS.

#### **A. Layout & Giao diện trực quan**

* **Bố cục:** Thiết kế dạng Card đơn giản nằm căn giữa tuyệt đối trên toàn màn hình (Center-aligned layout). Nền màn hình chính màu \#f3f6f9.  
* **Các thành phần bên trong Card:**  
  * **Logo & Brand:** Logo hình tạ đôi màu xanh dương kế bên chữ **GCMS** màu đậm \#1e293b.  
  * **Tiêu đề:** Chữ **Sign In** lớn nằm ở góc phải ngang hàng với logo.  
  * **Form trường nhập liệu:**  
    1. *Email Address:* Ô input văn bản có nhãn mờ (Placeholder).  
    2. *Password:* Ô input ẩn ký tự dạng chấm tròn.  
  * **Tùy chọn phụ:** Checkbox "Remember me" (Nhớ mật khẩu) màu xanh dương; Link "Forgot Password" (Quên mật khẩu) màu xanh dương căn phải.  
  * **Nút hành động (Sign In Button):** Nút bo góc lớn, trải dài 100% chiều rộng card, nền màu xanh \#009cff, chữ trắng viết hoa chữ đầu.  
  * **Khối thông tin Demo Accounts:** Nằm ở chân trang card, chữ màu xám nhạt, liệt kê 3 tài khoản demo phục vụ test nhanh.

#### **B. Trạng thái phần tử (UI Component States)**

* **Input Field (Email/Password):**  
  * *Default (Bình thường):* Viền màu xám rất nhạt (\#dee2e6), nền trắng.  
  * *Hover (Di chuột qua):* Viền đổi sang màu xám sậm hơn một chút.  
  * *Focus (Đang trỏ chuột nhập liệu):* Viền chuyển sang màu xanh dương chủ đạo (\#009cff), có hiệu ứng glow bóng mờ màu xanh xung quanh ô nhập.  
  * *Error (Lỗi nhập sai/để trống):* Viền chuyển sang màu đỏ (\#dc3545), kèm thông báo lỗi màu đỏ ngay phía trên form.  
* **Sign In Button:**  
  * *Default:* Nền \#009cff, màu chữ trắng.  
  * *Hover:* Nền đổi sang màu xanh đậm hơn (\#0086db), con trỏ chuột chuyển sang dạng bàn tay (pointer).  
  * *Active (Khi click vào):* Nền đổi sang xanh sậm tối, tạo cảm giác nút bị lún xuống.  
  * *Disabled (Khi đang loading hoặc thiếu thông tin):* Nút mờ đi (opacity 0.65), con trỏ chuột chuyển dạng cấm (not-allowed).

#### **C. Logic hiển thị và Ràng buộc dữ liệu (Validation & Logic)**

* **Trường bắt buộc (Required Fields):** Cả Email và Password đều là bắt buộc. Nếu bấm "Sign In" khi một trong hai trường để trống, hiển thị thông báo lỗi: *"Email and Password are required."*  
* **Định dạng Email:** Phải tuân theo định dạng chuẩn RFC 5322 (ví dụ: có ký tự @ và tên miền phía sau). Nếu sai định dạng, hiển thị thông báo lỗi viền đỏ.

#### **D. Trạng thái đặc biệt (Edge Cases)**

* **Trạng thái đăng nhập sai (Error State):** Khi thông tin tài khoản không tồn tại trong database hoặc tài khoản bị khóa, hệ thống trả về trang Login kèm banner thông báo lỗi màu đỏ nhạt nền hồng ở ngay đầu form: *"Invalid email/password, or account is not active."*

### **3.2. MÀN HÌNH BẢN ĐỒ DỰ ÁN \- ADMIN DASHBOARD**

Trang quản trị trung tâm dành cho tài khoản Admin sau khi đăng nhập thành công.

#### **A. Layout & Giao diện trực quan**

Giao diện Dashboard sử dụng mô hình **Sidebar Navigation Layout** chia làm hai khu vực chính:

1. **Sidebar (Thanh điều hướng trái):** Nền màu xám cực nhạt/trắng. Gồm logo thương hiệu **GCMS** ở trên cùng. Khối thông tin tài khoản đang đăng nhập (Avatar tròn của Admin, Tên hiển thị "Demo Admin", Role "Admin"). Danh sách Menu liên kết biểu tượng kèm chữ: *Dashboard, Manage Users, Gym Equipment, Classes & Schedule, Reports*.  
2. **Khu vực nội dung chính (Main Content Area):**  
   * **Header (Thanh đầu trang):** Nút Menu (Toggle Sidebar) ba sọc để thu gọn/mở rộng Sidebar. Ô tìm kiếm (Search Bar) bo góc tròn. Cụm icon góc phải: Hộp thư đến (Message), Thông báo chuông (Notification) kèm bong bóng số đếm, Avatar profile có mũi tên dropdown.  
   * **Hàng chỉ số KPI (KPI Cards Row):** Gồm 4 thẻ số liệu thống kê nhanh dạng lưới nằm ngang:  
     * *Total Members:* Icon 3 người màu xanh | Chỉ số: 1,248  
     * *Active PTs:* Icon người độc lập màu xanh | Chỉ số: 34  
     * *Today Classes:* Icon cuốn lịch màu xanh | Chỉ số: 12 Classes  
     * *Monthly Revenue:* Icon ký hiệu đô la ($) màu xanh | Chỉ số: $12,450  
   * **Hàng biểu đồ trực quan (Charts Row):** Chia đôi chiều rộng màn hình thành 2 biểu đồ phân tích trực quan:  
     * *Biểu đồ cột (Bar Chart \- bên trái):* "Monthly Membership Registrations" hiển thị so sánh đa quốc gia (USA, UK, AU).  
     * *Biểu đồ vùng (Area Chart \- bên phải):* "Revenue Analytics (Membership vs PT)" hiển thị phân tích doanh thu qua các năm giữa dịch vụ Thẻ hội viên và Thuê PT cá nhân.  
   * **Bảng dữ liệu đăng ký gần đây (Recent User Registrations Table):** Nằm ở hàng dưới cùng, chiếm 100% chiều rộng khu vực nội dung. Tiêu đề bảng: *"Recent User Registrations"* kèm nút link ở góc phải *"View All Users"*. Bảng gồm các cột: User ID, Full Name, Email, Role, Status, Action. Trạng thái tài khoản (Status) được bọc trong badge bo góc màu xanh lá cây (Active) hoặc đỏ (Inactive). Cột hành động (Action) chứa nút "Edit" nhỏ màu xanh dương.

#### **B. Trạng thái phần tử (UI Component States)**

* **Sidebar Links:**  
  * *Default:* Chữ và icon màu xám đậm (\#1e293b), nền trong suốt.  
  * *Hover:* Nền đổi sang màu xám nhạt (\#f3f6f9), chữ giữ nguyên màu đậm.  
  * *Active (Màn hình hiện tại):* Nền đổi sang màu trắng tinh khiết, chữ và icon chuyển sang màu xanh dương chủ đạo (\#009cff), có thanh viền màu xanh mỏng chạy dọc ở mép trái liên kết để báo hiệu.  
* **KPI Cards:**  
  * *Default:* Nền trắng tinh, bóng đổ cực nhẹ (soft shadow).  
  * *Hover:* Thẻ hơi dịch chuyển nhẹ lên trên (Y-axis translate \-3px) and bóng đổ đậm hơn để tạo cảm giác nổi 3D (Z-index elevation).

#### **C. Logic hiển thị và Ràng buộc dữ liệu (Validation & Logic)**

* **Định dạng số liệu (Data Formatting):** Các số đếm chỉ số phải có dấu phẩy phân tách phần nghìn (ví dụ: 1,248). Tiền tệ phải có ký hiệu đô la đầu tiên và dấu phẩy phân tách nghìn (ví dụ: $12,450).  
* **Trạng thái Badge Status:**  
  * Nếu user.status \== 'Active': Class CSS .badge-success (nền xanh lá cây nhạt, chữ trắng).  
  * Nếu user.status \== 'Inactive': Class CSS .badge-danger (nền đỏ nhạt, chữ trắng).

## **4\. HIỆU ỨNG VÀ CHUYỂN ĐỘNG (INTERACTION & ANIMATION)**

---

Nhằm nâng cao trải nghiệm sử dụng sống động, các chuyển động vi mô (Micro-interactions) sau cần được áp dụng nhất quán bằng CSS Transitions:

* **Thời gian chuyển động tiêu chuẩn (Timing/Duration):** Tất cả hiệu ứng Hover, thay đổi màu nền, co giãn nút đều diễn ra trong khoảng thời gian **250ms** với đường cong chuyển động **ease-in-out** để tạo độ mượt tự nhiên.  
* **Hiệu ứng thu gọn Sidebar (Sidebar Toggle):** Khi bấm nút Toggle ba sọc ở Header, Sidebar sẽ trượt thu gọn về bên trái (width giảm từ 250px xuống 70px), phần nội dung chính bên phải tự động giãn rộng ra chiếm không gian trống một cách trơn tru.  
* **Hiệu ứng Hover Chart Tooltip:** Khi di chuột qua các điểm dữ liệu trên biểu đồ cột hoặc biểu đồ vùng, xuất hiện hộp thông tin (Tooltip) mờ nhẹ hiển thị chi tiết số liệu tại điểm đó.

## **5\. TÀI NGUYÊN ĐÍNH KÈM VÀ THAM CHIẾU (ASSETS & REFERENCES)**

* ---

  **Font chữ chính thức:** Google Font Heebo  
* **Hệ thống Icon sử dụng:** Bootstrap Icons Library hoặc FontAwesome Icons  
* **Framework Giao diện mẫu tham khảo:** Dựa trên template Admin Bootstrap DashMin được tích hợp cấu trúc và tinh chỉnh riêng cho thương hiệu GCMS.