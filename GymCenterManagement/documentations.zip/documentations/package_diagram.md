# Tài liệu Package Diagram - Hệ thống Manage Gym's Room

## 1. Lý thuyết về Package Diagram (Biểu đồ gói)

### 1.1 Khái niệm
Package Diagram (Biểu đồ gói) là một biểu đồ cấu trúc trong UML, được sử dụng để thể hiện cách các thành phần (lớp, interface, component) trong hệ thống được nhóm lại với nhau thành các module (gói) logic. Nó cho thấy sự phụ thuộc (dependencies) giữa các gói này.

### 1.2 Mục đích
- Cung cấp cái nhìn tổng quan về kiến trúc phần mềm ở mức high-level (mức cao).
- Quản lý sự phức tạp của hệ thống bằng cách chia nhỏ thành các module logic.
- Xác định rõ ranh giới và sự giao tiếp (phụ thuộc) giữa các thành phần.
- Giúp tổ chức mã nguồn (source code) một cách khoa học.

### 1.3 Thành phần chính
- **Package (Gói):** Thường được biểu diễn bằng hình thư mục (folder) trong UML chuẩn. Dùng để chứa các phần tử khác (như class, interface, hoặc các package con).
- **Dependency (Sự phụ thuộc):** Được biểu diễn bằng mũi tên nét đứt `-.->`. Chỉ ra rằng sự thay đổi ở package đích có thể ảnh hưởng đến package nguồn (ví dụ: package A import và sử dụng package B).

---

## 2. Cách vẽ Package Diagram

1. **Xác định kiến trúc hệ thống:** Xác định mô hình kiến trúc đang sử dụng (ví dụ: MVC, 3-tier, Microservices). Với ứng dụng Java JSP (web thuần), mô hình phổ biến là **MVC (Model - View - Controller)** kết hợp **3-Layer (Controller - Service - DAO)**.
2. **Phân rã (Decomposition):** Chia hệ thống thành các module logic có tính gắn kết cao (High Cohesion) và ít phụ thuộc lẫn nhau (Low Coupling).
3. **Loại bỏ cấu trúc đường dẫn kỹ thuật (như cấu trúc Maven):** Thay vì dùng `src.main.java.com.gymcenter.controller`, chỉ cần gọi ngắn gọn là `controller`. Điều này giúp biểu đồ tập trung vào logic thay vì cấu trúc vật lý của thư mục project.
4. **Xác định sự phụ thuộc (Dependencies):** Xác định package nào gọi đến package nào. Nguyên tắc chung:
   - Tầng trên gọi tầng dưới (Controller -> Service -> DAO).
   - Tầng dưới KHÔNG được gọi ngược lên tầng trên để tránh vòng lặp phụ thuộc (Circular Dependency).
   - Các gói chung (Util, Model) có thể được gọi bởi nhiều gói khác.
5. **Vẽ biểu đồ:** Sử dụng công cụ để kết nối các package bằng mũi tên đứt nét chỉ chiều phụ thuộc.

---

## 3. Package Diagram cho Hệ thống Gym Center

Dựa trên mô hình Java Web MVC / 3-Tier cơ bản, chúng ta sẽ định nghĩa các package logic (đã loại bỏ cấu trúc Maven).

### 3.1 Biểu đồ cấu trúc (Mermaid)

Dưới đây là biểu đồ mô phỏng Package Diagram. Các mũi tên nét đứt (`-.->`) thể hiện **sự phụ thuộc** (`import` và sử dụng).

```mermaid
flowchart TD
    %% Định nghĩa các style mô phỏng package
    classDef packageStyle fill:#f9f9f9,stroke:#333,stroke-width:1px;
    classDef subPackageStyle fill:#ffffff,stroke:#666,stroke-width:1px,stroke-dasharray: 5 5;
    
    %% Khai báo các Package
    client["View Layer<br/>(JSP/HTML/JS)"]
    filter[filter]:::packageStyle
    listener[listener]:::packageStyle
    
    subgraph p_controller [controller]
        c_admin[admin]:::subPackageStyle
        c_auth[auth]:::subPackageStyle
        c_member[member]:::subPackageStyle
        c_pt[pt]:::subPackageStyle
        c_staff[staff]:::subPackageStyle
    end

    subgraph p_service [service]
        s_impl[impl]:::subPackageStyle
    end

    subgraph p_dao [dao]
        d_impl[impl]:::subPackageStyle
    end

    subgraph p_model [model]
        m_entity[entity]:::subPackageStyle
    end
    
    dto[dto]:::packageStyle
    utils[utils]:::packageStyle

    %% Định nghĩa quan hệ Request flow
    client -->|HTTP Request| filter
    client -->|HTTP Events| listener
    filter -.->|Forward/Redirect| p_controller
    
    %% Định nghĩa quan hệ Dependency (Sự phụ thuộc)
    p_controller -.->|import| p_service
    p_service -.->|import| p_dao
    
    %% Phụ thuộc vào DTO
    p_controller -.->|import| dto
    p_service -.->|import| dto
    
    %% Phụ thuộc vào Model
    p_controller -.->|import| p_model
    p_service -.->|import| p_model
    p_dao -.->|import| p_model
    dto -.->|import| p_model
    
    %% Phụ thuộc vào Utils
    filter -.->|import| utils
    p_controller -.->|import| utils
    p_service -.->|import| utils
    p_dao -.->|import| utils
```

### 3.2 Bảng mô tả các Package

Dưới đây là bảng giải thích và quy tắc đặt tên cho từng package trong hệ thống:

| No | Package | Naming Conventions | Description |
|----|-----------|--------------------|-------------|
| 01 | `controller` | Suffix `Controller` (e.g., `UserController`) | Contains Servlets acting as controllers. Handles HTTP Requests from users, invokes `service`, and forwards/redirects to View. Phân chia thành các sub-package (`admin`, `auth`, `member`, `pt`, `staff`) theo quyền hạn và nhóm chức năng. |
| 02 | `service` | Interface prefix `I`, Class suffix `Service` or `ServiceImpl` | Contains interfaces and classes that handle Business Logic. `service.impl` chứa các class triển khai (implementation) chi tiết. |
| 03 | `dao` | Suffix `DAO` or `Repository` (e.g., `UserDAO`) | Data Access Object. Giao tiếp trực tiếp với database. `dao.impl` chứa các class triển khai truy vấn SQL chi tiết. |
| 04 | `model` | PascalCase, singular nouns (e.g., `User`, `GymPackage`) | Chứa các đối tượng hệ thống. Sub-package `model.entity` chứa các class ánh xạ (mapping) trực tiếp với các bảng trong CSDL. |
| 05 | `dto` | Suffix `DTO` (e.g., `MemberProfileDTO`) | Data Transfer Object. Chứa các class dùng để đóng gói và luân chuyển dữ liệu giữa các layer, đặc biệt khi cấu trúc dữ liệu gửi/nhận phức tạp hơn 1 Entity đơn thuần. |
| 06 | `filter` | Suffix `Filter` (e.g., `AuthFilter`, `EncodingFilter`) | Contains Servlet Filters to intercept and process Requests before they reach the `controller` (e.g., Authentication, Authorization, UTF-8 Encoding). |
| 07 | `listener` | Suffix `Listener` | Chứa các Servlet Listener để lắng nghe và xử lý các sự kiện vòng đời của ứng dụng web (ví dụ: Session tạo/hủy, Application khởi động). |
| 08 | `utils` | Nouns describing functionality, suffix `Util` (e.g., `DBContext`, `PasswordUtil`) | Contains static utility classes shared across the entire system (e.g., Database connection, password hashing, string formatting). |
