﻿# **\[Gym Center Management System\]**

**Mã dự án:** SWP\_2026\_01  
**Nhóm thực hiện:** Group 1

## **Thành viên nhóm**

| STT | Mã sinh viên | Họ và tên | Vai trò dự kiến |
| ----- | ----- | ----- | ----- |
| 1 | HE187234 | Nguyễn Đại Dương | Trưởng nhóm |
| 2 | HE181596 | Nguyễn Trí Linh | Thành viên |
| 3 | HE181315 | Nguyễn Đình Phú | Thành viên |
| 4 | HE182118 | Đỗ Minh Hoàng | Thành viên |
| 5 | HE171276 | Nguyễn Hoàng Thắng | Thành viên |

---

# **1\. TÌNH HUỐNG & BỐI CẢNH (CONTEXT)**

### **Hiện trạng**

**Gym Center** là một phòng gym tư nhân quy mô vừa nằm tại gần đại học FPT. Phòng gym hiện đang quản lý khoảng 200–300 hội viên cùng nhiều gói tập theo tháng, quý và năm. Ngoài ra, phòng gym còn cung cấp dịch vụ huấn luyện viên cá nhân (PT – Personal Trainer) dành cho hội viên có nhu cầu tập luyện chuyên sâu.

Hiện nay, phần lớn hoạt động quản lý của phòng gym vẫn được thực hiện thủ công thông qua Excel, sổ ghi chép và trao đổi qua Zalo hoặc Facebook Messenger. Khi hội viên đăng ký hoặc gia hạn gói tập, nhân viên phải tự kiểm tra thông tin cá nhân, thời hạn gói tập và lịch sử thanh toán bằng tay. Điều này dễ gây nhầm lẫn hoặc sai sót khi số lượng hội viên tăng lên.

Lịch làm việc của Personal Trainer cũng được sắp xếp thủ công nên thường xảy ra tình trạng trùng lịch, khó kiểm tra thời gian rảnh hoặc thay đổi lịch tập vào phút cuối. Hội viên muốn thuê Personal Trainer thường phải nhắn tin hoặc gọi trực tiếp để hỏi lịch trống, gây mất thời gian cho cả hai bên.

Ngoài ra, phòng gym có nhiều thiết bị tập luyện như máy chạy bộ, máy ép ngực, xe đạp tập, tạ và máy kéo cáp nhưng chưa có hệ thống quản lý tình trạng sử dụng hoặc theo dõi bảo trì định kỳ. Một số thiết bị chỉ được sửa chữa khi đã hỏng hóc, ảnh hưởng đến trải nghiệm của hội viên.

Chủ phòng gym cũng gặp khó khăn trong việc theo dõi doanh thu, số lượng hội viên đang hoạt động, gói tập sắp hết hạn và hiệu suất làm việc của Personal Trainer. Các báo cáo hiện tại đều được tổng hợp thủ công nên tốn nhiều thời gian và thiếu tính chính xác.

Trong thực tế, đây là tình trạng phổ biến tại nhiều phòng gym tư nhân quy mô nhỏ và vừa hiện nay. Do hạn chế về ngân sách và nhân sự kỹ thuật, nhiều phòng gym vẫn quản lý bằng phương pháp thủ công hoặc sử dụng các công cụ rời rạc, dẫn đến khó mở rộng và dễ phát sinh sai sót trong vận hành.

**Vấn đề tồn đọng**

* Quản lý hội viên thủ công bằng Excel hoặc giấy tờ, dễ thất lạc và sai sót dữ liệu.   
* Khó theo dõi thời hạn gói tập và lịch sử thanh toán của hội viên.   
* Personal Trainer và nhân viên phải trao đổi lịch tập qua tin nhắn thủ công, dễ bị trùng lịch.   
* Không có hệ thống theo dõi thiết bị và lịch bảo trì định kỳ.   
* Chủ phòng gym khó thống kê doanh thu, số lượng hội viên hoạt động và hiệu quả vận hành.   
* Hội viên không có nơi để tự xem thông tin cá nhân, gói tập hay lịch sử thanh toán.   
* Khách vãng lai khó tiếp cận thông tin về gói tập, Personal Trainer và dịch vụ của phòng gym.   
* Nhiều phần mềm quản lý gym hiện nay quá phức tạp hoặc chi phí cao đối với phòng gym nhỏ. 

  **Mục tiêu giải pháp**

* Quản lý hội viên, gói tập và thanh toán tập trung.   
* Quản lý hồ sơ Personal Trainer, lịch làm việc của Personal Trainer và trạng thái các buổi tập   
* Quản lý thiết bị và lịch bảo trì cơ bản.   
* Hỗ trợ hội viên xem thông tin cá nhân, lịch sử thanh toán và trạng thái gói tập.   
* Hỗ trợ hội viên xem lịch rảnh/bận của Personal Trainer và đặt lịch trực tiếp vào các khung giờ còn trống  
* Personal Trainer có tài khoản riêng để xem lịch làm việc, xem thông tin hội viên đã đặt lịch và cập nhật trạng thái hoàn thành buổi tập.  
* Hỗ trợ chuyển giao gói tập giữa các hội viên thông qua nhân viên.   
* Hỗ trợ báo cáo doanh thu, hội viên hoạt động và các gói tập sắp hết hạn.   
* Giảm thao tác thủ công và tăng hiệu quả quản lý cho phòng gym. 

---

# **2\. PHẠM VI NGHIỆP VỤ (BUSINESS SCOPE)**

## **2.1 Giới thiệu phạm vi**

Hệ thống quản lý toàn bộ hoạt động của phòng gym bao gồm:

* Quản lý hội viên  
* Quản lý gói tập  
* Quản lý Personal Trainer  
* Quản lý thiết bị  
* Quản lý thanh toán  
* Báo cáo thống kê

Hệ thống chia thành 5 phân hệ chính.

---

# **2.2 Phân hệ 1: Quản lý hội viên (Member management subsystem)**

## **Mục đích**

Quản lý thông tin hội viên và trạng thái sử dụng dịch vụ.

## **Các chức năng chính**

### **2.2.1 Quản lý hội viên (Admin, Nhân viên)**

* Thêm hội viên mới  
* Cập nhật thông tin hội viên  
* Tìm kiếm hội viên  
* Xóa hội viên  
* Xem trạng thái gói tập  
* Xem ngày bắt đầu/ngày hết hạn

### **2.2.2 Quản lý hồ sơ cá nhân (Hội viên)**

* Xem thông tin cá nhân  
* Cập nhật thông tin cơ bản  
* Xem lịch sử thanh toán  
* Xem thông báo từ phòng gym

---

# **2.3 Phân hệ 2: Quản lý gói tập & Personal Trainer (Package & Personal Trainer subsystem)**

## **Mục đích**

Quản lý các gói tập và dịch vụ huấn luyện viên cá nhân.

## **Các chức năng chính**

### **2.3.1 Quản lý gói tập (Admin)**

* Tạo gói tập tháng/năm  
* Cập nhật giá gói tập  
* Thiết lập thời hạn sử dụng  
* Quản lý mô tả dịch vụ

### **2.3.2 Đăng ký & Gia hạn gói tập (Nhân viên)**

* Đăng ký gói tập cho hội viên  
* Gia hạn gói tập  
* Kiểm tra trạng thái gói tập

### **2.3.3 Quản lý Personal Trainer (Admin, Nhân viên)**

* Admin duyệt hoặc từ chối hồ sơ đăng ký Personal Trainer.  
* Admin/Nhân viên cập nhật thông tin hồ sơ Personal Trainer chính thức.  
* Quản lý chuyên môn, kinh nghiệm và mô tả.  
* Quản lý trạng thái hoạt động của Personal Trainer.  
* Khóa hoặc mở lại tài khoản Personal Trainer khi cần. 

### **2.3.4 Đăng ký dịch vụ Personal Trainer (Hội viên)** 

* Xem danh sách Personal Trainer đang hoạt động.  
* Xem thông tin Personal Trainer như chuyên môn, kinh nghiệm, mô tả và giá dịch vụ.  
* Chọn Personal Trainer mong muốn.  
* Chọn gói dịch vụ Personal Trainer theo thời hạn như 1 tháng, 3 tháng hoặc 1 năm.  
* Sau khi đăng ký, hệ thống tạo bản ghi đăng ký dịch vụ Personal Trainer để nhân viên ghi nhận thanh toán và sắp lịch tập cụ thể. 

**2.3.5 Chuyển giao gói tập (Nhân  viên)**

* Kiểm tra trạng thái gói tập hiện tại  
* Chuyển thời hạn sử dụng sang tài khoản khác

---

# **2.4 Phân hệ 3: Quản lý lịch tập & thiết bị (Schedule & Equipment subsystem)**

## **Mục đích**

Quản lý lịch làm việc và thiết bị phòng gym.

## **Các chức năng chính**

### **2.4.1 Quản lý lịch Personal Trainer**

* Staff/Admin tạo và cập nhật lịch tập cho hội viên đã đăng ký dịch vụ Personal Trainer.  
* Staff/Admin xử lý đổi hoặc hủy lịch khi cần.  
* Staff/Admin đánh dấu buổi tập là Completed sau khi buổi tập kết thúc để theo dõi công dạy của Personal Trainer.  
* Personal Trainer đăng nhập để xem lịch làm việc và thông tin cơ bản của hội viên được xếp lịch. 

### **2.4.2 Quản lý thiết bị**

* Thêm thiết bị mới  
* Cập nhật thông tin thiết bị  
* Theo dõi tình trạng sử dụng  
* Quản lý ngày mua và bảo hành  
* Theo dõi lịch bảo trì

---

# **2.5 Phân hệ 4: Thanh toán (Payment subsystem)**

## **Mục đích**

Quản lý thanh toán các dịch vụ phòng gym.

## **Các chức năng chính**

### **2.5.1 Quản lý thanh toán**

* Ghi nhận thanh toán gói tập  
* Ghi nhận thanh toán thuê Personal Trainer  
* Xem lịch sử thanh toán  
* In hóa đơn

### **2.5.2 Quản lý gia hạn**

* Kiểm tra gói tập sắp hết hạn  
* Gia hạn tự động/thủ công  
* Thông báo cho hội viên

---

# **2.6 Phân hệ 5: Báo cáo & thống kê (Reporting subsystem)**

## **Mục đích**

Cung cấp báo cáo hỗ trợ quản lý phòng gym.

## **Các chức năng chính**

### **2.6.1 Báo cáo hội viên**

* Tổng số hội viên  
* Hội viên đang hoạt động  
* Gói tập sắp hết hạn

### **2.6.2 Báo cáo doanh thu**

* Doanh thu theo tháng  
* Doanh thu theo gói tập  
* Doanh thu từ Personal Trainer

### **2.6.3 Báo cáo thiết bị**

* Thiết bị cần bảo trì  
* Thiết bị hỏng hóc

### **2.6.4 Dashboard**

* Số lượng hội viên hôm nay  
* Doanh thu hôm nay  
* Personal Trainer đang hoạt động  
* Cảnh báo gói tập sắp hết hạn

---

# **2.7 Ranh giới phạm vi**

| Chức năng | Có ✓ | Không × | Lý do |
| ----- | ----- | ----- | ----- |
| Quản lý hội viên | ✓ |  | Chức năng chính |
| Quản lý Personal Trainer | ✓ |  | Cần thiết |
| Quản lý thanh toán | ✓ |  | Bắt buộc |
| Báo cáo doanh thu | ✓ |  | Hỗ trợ quản lý |
| Quản lý thiết bị | ✓ |  | Theo dõi bảo trì |
| Mobile app |  | × | Giới hạn thời gian |
| Chat realtime |  | × | Quá phức tạp |
| AI đề xuất bài tập |  | × | Ngoài phạm vi |
| Tích hợp smartwatch |  | × | Không cần thiết |
| Quản lý dinh dưỡng chuyên sâu |  | × | Ngoài phạm vi |

---

# **3\. MÔ HÌNH HÓA HỆ THỐNG (SYSTEM MODELLING)**

# **3.1 Danh sách Actor**

### **Admin**

Quản lý toàn bộ hệ thống, bao gồm hội viên, nhân viên, Personal Trainer, gói tập, thiết bị, thanh toán và báo cáo. Admin có quyền duyệt hoặc từ chối hồ sơ đăng ký ứng tuyển Personal Trainer. 

### **Nhân viên**

Hỗ trợ các nghiệp vụ vận hành hằng ngày như đăng ký/gia hạn gói tập, ghi nhận thanh toán, quản lý hội viên, hỗ trợ quản lý lịch Personal Trainer và thiết bị. 

### **Hội viên**

Người sử dụng dịch vụ phòng gym. Hội viên có thể xem thông tin cá nhân, trạng thái gói tập, lịch sử thanh toán, xem danh sách Personal Trainer và đặt lịch tập với Personal Trainer vào các khung giờ còn trống. 

### **Huấn luyện viên (Personal Trainer)**

Người cung cấp dịch vụ huấn luyện cá nhân. Personal Trainer có tài khoản riêng để đăng nhập, xem lịch làm việc, xem thông tin cơ bản của hội viên được xếp lịch và cập nhật hồ sơ cá nhân. 

**Khách vãng lai**

Người chưa đăng nhập hệ thống. Có thể xem thông tin giới thiệu phòng gym, xem gói tập, xem danh sách Personal Trainer đang hoạt động và đăng ký tài khoản với tư cách hội viên hoặc đăng ký ứng tuyển làm Personal Trainer. 

---

# **3.2 Danh sách Use Case**

| UC ID | Use Case | Mô Tả | Actor |
| :--- | :--- | :--- | :--- |
| **UC-01** | Login User | Authenticates credentials, checks account status, and redirects to role dashboards. | Admin, Staff, Member, Personal Trainer |
| **UC-01** | Logout User | Invalidates the current session and redirects the user to the login screen. | Admin, Staff, Member, Personal Trainer |
| **UC-04** | Change Password | Allows authenticated users to securely update their passwords. | Admin, Staff, Member, Personal Trainer |
| **UC-03** | Manage User Profile | Enables authenticated users to view and update their personal profiles and upload avatars. | Admin, Staff, Member, Personal Trainer |
| **UC-05** | Manage Accounts | Enables administrators to perform CRUD operations on user accounts and update roles/statuses. | Admin |
| **UC-06** | View Dashboard | Displays real-time daily operational metrics, revenue tracking, and system alerts. | Admin |
| **UC-02** | Register Membership | Allows guests to sign up and automatically creates an active member account. | Guest |
| **UC-09** | View Member List | Enables search and list retrieval of gym member records by name, ID, or phone number. | Admin, Staff |
| **UC-09** | Manage Members | Allows staff/admin to manage member details, statuses, and registration cycles. | Admin, Staff |
| **UC-10** | Access Member Portal | Provides a dedicated portal for members to check package validity and billing history. | Member |
| **UC-15** | Manage Package | Allows administrators to create, update, price, and catalog gym membership plans. | Admin |
| **UC-16** | Register Package | Facilitates the assignment and enrollment of a member into a specific gym plan. | Staff, Admin |
| **UC-18** | Renew Package | Handles membership duration extensions for existing members. | Staff, Admin |
| **UC-18** | Transfer Package | Transfers remaining package duration from one member to another. | Staff, Admin |
| **UC-12** | Member Check-ins | Logs, tracks, and processes daily attendance and member facility check-ins at the front desk. | Staff, Admin |
| **UC-13** | View Attendance History | Renders chronological logs of facility check-ins and check-outs for audit. | Member, Staff, Admin |
| **UC-21** | Apply for Personal Trainer | Enables external trainer candidates to submit job applications for Admin review. | Guest |
| **UC-21** | Review PT Application | Allows Admin to review PT applications and approve/reject candidates. | Admin |
| **UC-24** | Manage Personal Trainer | Enables Admin to manage official trainer profiles, status, service price, and account activation. | Admin |
| **UC-22** | View Personal Trainer List | Allows guests and members to view approved and active Personal Trainer profiles. | Guest, Member |
| **UC-25** | Manage PT Schedule | Allows Staff/Admin to create, update, and cancel Personal Trainer schedules. | Staff, Admin |
| **UC-23** | Book PT / Register PT Service | Allows members to select a PT and register for a service plan (1 month, 3 months, 1 year). | Member |
| **UC-26** | View PT Schedule | Allows Personal Trainers to view assigned training sessions and basic member info. | Personal Trainer |
| **UC-26** | Mark Session Completed | Allows Personal Trainers or Staff to mark training sessions as Completed for work tracking. | Personal Trainer, Staff |
| **UC-25** | Adjust/Cancel PT Schedule | Allows Staff/Admin to adjust, reschedule, or cancel training sessions under special circumstances. | Staff, Admin |
| **UC-27** | View Equipment List | Enables searching and viewing the general gym equipment inventory list. | Admin, Staff |
| **UC-27** | Add Equipment | Allows Admin to register newly acquired gym machinery in the system. | Admin |
| **UC-27** | Update Equipment | Allows staff and admins to update equipment specifications or operational locations. | Admin, Staff |
| **UC-28** | Report Equipment Issue | Allows staff to quickly report damaged, malfunctioning, or broken equipment needing repair. | Staff, Admin |
| **UC-30** | Manage Maintenance Schedules | Allows administrators to schedule and track periodic maintenance activities. | Admin, Staff |
| **UC-31** | Manage Blog & Policies | Allows Admin and Staff to publish and manage gym policies, rules, and announcements. | Admin, Staff |
| **UC-11** | View Notifications & Policies | Displays global policies, rules, and announcements to users. | Member, Staff, Personal Trainer |
| **UC-14** | Send Renewal Reminders | Automatically detects expiring plans and dispatches system notifications to targets. | System / Admin |
| **UC-17** | Record Payment | Processes cash payments for packages and PT services, logs payments, and prints invoices. | Staff, Admin |
| **UC-19** | View Personal Payment History | Allows members to view their past payment invoices and transaction history. | Member |
| **UC-19** | View System Payment History | Provides a searchable archive of all past transactions for cash flow audit. | Staff, Admin |
| **UC-07** | View Member Growth Reports | Generates detailed statistical and analytical reports on member growth over time. | Admin |
| **UC-20** | View Financial & Revenue Reports | Displays financial statistics, monthly revenue trends, and service sales reports. | Admin |
| **UC-29** | View Equipment Status Reports | Renders reports on gym machinery health, maintenance frequency, and issues. | Admin |


# **3.3 Lớp miền nghiệp vụ (Domain Classes)**

## **3.3.1 Users (Tài khoản người dùng)**

* UserID: int (Primary Key, Identity)  
* Email: string  
* PasswordHash: string  
* DisplayName: string  
* Phone: string  
* Status: string (Active, Inactive)  
* MustChangePassword: boolean  
* [Audit Log Columns]

## **3.3.2 Roles (Vai trò hệ thống)**

* RoleID: int (Primary Key, Identity)  
* RoleName: string (Admin, Staff, Member, PT)  
* RoleLevel: int  
* [Audit Log Columns]

## **3.3.3 UserRoles (Bảng trung gian phân quyền)**

* UserID: int (Composite Primary Key, FK → Users)  
* RoleID: int (Composite Primary Key, FK → Roles)  

## **3.3.4 Staffs (Nhân viên phòng tập)**

* StaffID: int (Primary Key, Identity)  
* UserID: int (FK → Users)  
* Position: string  
* Status: string  
* [Audit Log Columns]

## **3.3.5 Members (Hội viên)**

* MemberID: int (Primary Key, Identity)  
* UserID: int (FK → Users)  
* Status: string  
* [Audit Log Columns]

## **3.3.6 GymPackages (Gói tập)**

* PackageID: int (Primary Key, Identity)  
* PackageName: string  
* DurationMonths: int  
* Price: decimal  
* Description: string  
* Status: string (Active, Inactive)  
* [Audit Log Columns]

## **3.3.7 MemberPackages (Gói tập của hội viên)**

* MemberPackageID: int (Primary Key, Identity)  
* MemberID: int (FK → Members)  
* PackageID: int (FK → GymPackages)  
* StartDate: date  
* EndDate: date  
* Status: string (Active, Expired)  
* [Audit Log Columns]

## **3.3.8 PTApplications (Đơn ứng tuyển PT)**

* ApplicationID: int (Primary Key, Identity)  
* UserID: int (FK → Users)  
* Specialty: string  
* ExperienceYears: int  
* Phone: string  
* Description: string  
* CVPath: string  
* Status: string (Pending, Approved, Rejected)  
* SubmittedDate: datetime  
* ReviewedDate: datetime  
* ReviewedBy: int (FK → Users)  
* [Audit Log Columns]

## **3.3.9 PersonalTrainers (Huấn luyện viên cá nhân)**

* PTID: int (Primary Key, Identity)  
* UserID: int (FK → Users)  
* Specialty: string  
* ExperienceYears: int  
* Phone: string  
* Description: string  
* Status: string (Active, Inactive)  
* [Audit Log Columns]

## **3.3.10 PTPackageTypes (Gói dịch vụ PT)**

* PackageTypeID: int (Primary Key, Identity)  
* PackageTypeName: string (e.g. 1 Month, 3 Months, 1 Year)  
* DurationMonths: int  
* [Audit Log Columns]

## **3.3.11 PTServicePrices (Bảng giá dịch vụ PT)**

* PriceID: int (Primary Key, Identity)  
* PTID: int (FK → PersonalTrainers)  
* PackageTypeID: int (FK → PTPackageTypes)  
* Price: decimal  
* [Audit Log Columns]

## **3.3.12 PTRegistrations (Đăng ký thuê PT)**

* PTRegistrationID: int (Primary Key, Identity)  
* MemberID: int (FK → Members)  
* PTID: int (FK → PersonalTrainers)  
* PackageTypeID: int (FK → PTPackageTypes)  
* StartDate: date  
* EndDate: date  
* Price: decimal  
* Status: string (Active, Expired, Cancelled)  
* [Audit Log Columns]

## **3.3.13 PTSchedules (Lịch tập với PT)**

* PTScheduleID: int (Primary Key, Identity)  
* PTID: int (FK → PersonalTrainers)  
* MemberID: int (FK → Members, Nullable)  
* SessionDate: date  
* SlotIndex: int  
* SessionStatus: string (Available, Booked, Completed, Cancelled)  
* [Audit Log Columns]

## **3.3.14 Equipments (Thiết bị phòng tập)**

* EquipmentID: int (Primary Key, Identity)  
* EquipmentCode: string  
* EquipmentName: string  
* PurchaseDate: date  
* WarrantyDate: date  
* Location: string  
* ImageURL: string  
* Status: string (Available, Maintenance, Broken)  
* [Audit Log Columns]

## **3.3.15 EquipmentIssues (Báo cáo sự cố thiết bị)**

* IssueID: int (Primary Key, Identity)  
* EquipmentID: int (FK → Equipments)  
* ReportedBy: int (FK → Users)  
* Description: string  
* ReportedDate: datetime  
* Status: string (Pending, Resolved)  
* [Audit Log Columns]

## **3.3.16 Invoices (Hóa đơn thanh toán)**

* InvoiceID: int (Primary Key, Identity)  
* MemberID: int (FK → Members)  
* ProcessBy: int (FK → Users)  
* MemberPackageID: int (FK → MemberPackages, Nullable)  
* PTRegistrationID: int (FK → PTRegistrations, Nullable)  
* Amount: decimal  
* PaymentMethod: string (Cash)  
* PaymentDate: datetime  
* Status: string (Paid, Pending, Cancelled)  
* [Audit Log Columns]

## **3.3.17 Notifications (Thông báo & Bảng tin)**

* NotificationID: int (Primary Key, Identity)  
* Title: string  
* Content: string  
* TargetAudience: string (All, Member, PT, Staff)  
* IsGlobal: boolean  
* AuthorID: int (FK → Users)  
* Status: string (Draft, Published)  
* [Audit Log Columns]

---

# **4\. YÊU CẦU PHI CHỨC NĂNG (NON-FUNCTIONAL REQUIREMENTS)**

| Nhóm chất lượng | Mô tả yêu cầu | Tiêu chí chấp nhận (KPI) |
| ----- | ----- | ----- |
| Hiệu năng (Performance) | Hệ thống phải xử lý thao tác nhanh chóng | Thời gian phản hồi dưới 3 giây với 300 người dùng đồng thời |
| Bảo mật (Security) | Bảo vệ thông tin tài khoản và thanh toán | Mật khẩu mã hóa và phân quyền theo vai trò |
| Khả dụng (Availability) | Hệ thống hoạt động ổn định | Uptime tối thiểu 99% |
| Khả năng mở rộng | Có thể mở rộng thêm tính năng | Dễ thêm module mới |
| Tính dễ sử dụng | Giao diện thân thiện | Người dùng mới thao tác cơ bản dưới 10 phút |
| Khả năng bảo trì | Dễ sửa lỗi và nâng cấp | Áp dụng mô hình MVC rõ ràng |

**Q1: Sản phẩm đầu ra dự kiến của bạn khác gì so với các sản phẩm tương tự trên thị trường?**   
**A:** Khác với các sản phẩm tương tự trên thị trường là dự án này sẽ tập trung vào sự đơn giản, dễ sử dụng để phù hợp với các phòng gym vừa và nhỏ.

Các phần mềm hiện nay hầu như sẽ quản lý cho các cơ sở to kiểu nhiều chi nhánh, thanh toán tự động, quét thẻ, marketing,... Và những có đó thì ở những phòng gym nhỏ và vừa là không cần thiết.

Sản phẩm core sẽ là quản lý hội viên, Personal Trainer, nhân viên, gói tập và thanh toán cơ bản(cash). Cái khác so với còn lại là sẽ có tính năng đặt lịch tập với Personal Trainer, hội viên có thể xem lịch rảnh/bận của Personal Trainer để đăng ký.

Ngoài ra thì hệ thống không tập trung vào các tính năng quá cao mà chỉ tập trung vào lõi để ưu tiên dễ triển khai, sử dụng và phù hợp với phạm vi của dự án.


