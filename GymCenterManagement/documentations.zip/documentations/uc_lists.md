﻿# **Danh mục các Trường hợp sử dụng (Use Case List Specification) — GCMS**

Tài liệu này tổng hợp, chuẩn hóa mã định danh (UC ID) và mô tả chi tiết toàn bộ các trường hợp sử dụng (Use Cases) của hệ thống **Gym Center Management System (GCMS)**. Danh mục được phân loại khoa học theo từng phân hệ nghiệp vụ chính của hệ thống.

---

## **1. Phân hệ 1: Xác thực & Hồ sơ (Authentication & Profile)**

Phân hệ kiểm soát an ninh dòng vào, định danh tài khoản và phân quyền dựa trên vai trò (RBAC) thông qua cơ chế HttpSession và Servlet Filter.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-01** | Đăng nhập hệ thống (Login User) | Admin, Staff, Member, PT | Xác thực thông tin đăng nhập (Email/Password), kiểm tra trạng thái hoạt động của tài khoản và điều hướng về trang Dashboard tương ứng. |
| **UC-01** | Đăng xuất hệ thống (Logout User) | Admin, Staff, Member, PT | Hủy bỏ session hiện hành của người dùng trên máy chủ và chuyển hướng về trang đăng nhập công cộng. |
| **UC-04** | Thay đổi mật khẩu (Change Password) | Admin, Staff, Member, PT | Cho phép người dùng tự cập nhật mật khẩu mới sau khi xác thực mật khẩu hiện tại để bảo mật tài khoản. |
| **UC-03** | Xem & Cập nhật Hồ sơ cá nhân (Manage User Profile) | Admin, Staff, Member, PT | Cho phép người dùng tự xem thông tin cá nhân, cập nhật số điện thoại, địa chỉ và ảnh đại diện (avatar). |

---

## **2. Phân hệ 2: Quản lý Tài khoản & Phân quyền (Account Administration)**

Phân hệ dành riêng cho Ban quản trị để thiết lập vận hành toàn hệ thống.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-05** | Quản lý tài khoản hệ thống (Manage Accounts) | Admin | Cho phép Admin thực hiện các thao tác CRUD trên các tài khoản hệ thống (nhân viên, hội viên, PT) và khóa/mở khóa tài khoản. |
| **UC-06** | Xem Dashboard tổng quan (View Dashboard) | Admin | Hiển thị các chỉ số KPI vận hành hàng ngày (số hội viên mới, doanh thu thực tế, PT đang làm việc) và biểu đồ trực quan. |

---

## **3. Phân hệ 3: Quản lý Hội viên & Gói tập (Membership & Package Domain)**

Trọng tâm xử lý các nghiệp vụ liên quan đến vòng đời hội viên, cấu hình sản phẩm gói tập và luồng giao dịch đăng ký/gia hạn dịch vụ tại quầy.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-02** | Đăng ký tài khoản Hội viên (Register Membership) | Khách vãng lai (Guest) | Khách vãng lai điền thông tin đăng ký để khởi tạo tài khoản Member mới ở trạng thái hoạt động (Active). |
| **UC-09** | Tra cứu danh sách Hội viên (View Member List) | Admin, Staff | Hỗ trợ nhân viên tìm kiếm nhanh danh sách hội viên theo Tên, Mã, hoặc Số điện thoại. |
| **UC-09** | Quản lý thông tin Hội viên (Manage Members) | Admin, Staff | Cho phép thêm mới, chỉnh sửa thông tin chi tiết và cập nhật trạng thái hồ sơ của hội viên. |
| **UC-10** | Tra cứu trạng thái gói tập cá nhân (Access Member Portal) | Hội viên (Member) | Hội viên đăng nhập Portal để tự kiểm tra gói tập đang hoạt động, ngày bắt đầu và ngày hết hạn. |
| **UC-15** | Quản lý danh mục Gói tập (Manage Package) | Admin | Thiết lập cấu hình sản phẩm gói tập (tháng, quý, năm), định giá bán, thời hạn và trạng thái đóng/mở gói. |
| **UC-16** | Đăng ký gói tập mới (Register Package) | Nhân viên (Staff), Admin | Đăng ký gói tập gym cho hội viên tại quầy, hệ thống tự động tính toán thời hạn dựa trên thời gian thực. |
| **UC-18** | Gia hạn gói tập (Renew Package) | Nhân viên (Staff), Admin | Gia hạn gói tập cũ của hội viên, hệ thống sẽ cộng dồn thời gian nối tiếp vào thời hạn cũ của gói tập. |
| **UC-18** | Chuyển nhượng gói tập (Transfer Package) | Nhân viên (Staff), Admin | Chuyển nhượng thời gian sử dụng còn lại của gói tập từ hội viên này sang tài khoản của hội viên khác. |

---

## **4. Phân hệ 4: Điểm danh & Lịch tập PT (Attendance & PT Scheduling)**

Đồng bộ thông tin điểm danh cửa và quản lý giáo án huấn luyện cá nhân 1-kèm-1, áp dụng cơ chế chống trùng lịch tuyệt đối.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-12** | Điểm danh Hội viên (Member Check-ins) | Nhân viên (Staff), Admin | Ghi nhận thời gian đến tập (Check-in/Check-out) của hội viên tại quầy bằng cách đối soát nhanh mã thẻ và trạng thái gói tập. |
| **UC-13** | Xem lịch sử điểm danh Hội viên (View Attendance History) | Hội viên, Nhân viên, Admin | Hiển thị danh sách nhật ký ra vào phòng tập theo thời gian thực để đối soát. |
| **UC-21** | Nộp hồ sơ ứng tuyển PT (Apply for Personal Trainer) | Khách vãng lai (Guest) | Khách ứng cử điền thông tin chuyên môn, số năm kinh nghiệm và tải lên chứng chỉ nghề để xin làm PT. |
| **UC-21** | Duyệt/Từ chối hồ sơ ứng tuyển (Review PT Application) | Admin | Admin rà soát đơn tuyển dụng, bấm duyệt (hệ thống tự tạo tài khoản vai trò PT) hoặc từ chối đơn ứng tuyển. |
| **UC-24** | Quản lý hồ sơ và trạng thái PT (Manage Personal Trainer) | Admin | Cập nhật hồ sơ, điều chỉnh giá sàn dịch vụ và trạng thái hoạt động của các Huấn luyện viên. |
| **UC-22** | Xem danh sách PT công khai (View Personal Trainer List) | Khách vãng lai, Hội viên | Hiển thị danh sách PT đang hoạt động kèm theo chuyên môn và giá dịch vụ để tham khảo hoặc lựa chọn thuê. |
| **UC-25** | Thiết lập lịch làm việc của PT (Manage PT Schedule) | Nhân viên (Staff), Admin | Khởi tạo và sắp xếp các slot thời gian trống (Available) của từng PT theo ngày/tuần để làm cơ sở cho khách đặt lịch. |
| **UC-23** | Đăng ký dịch vụ PT & Đặt lịch (Book PT / Register PT Service) | Hội viên (Member) | Hội viên mua gói tập với PT, chọn khung giờ trống của PT đó và bấm đặt lịch (Trạng thái chuyển sang Booked). |
| **UC-26** | Xem lịch dạy cá nhân (View PT Schedule) | Huấn luyện viên (PT) | PT đăng nhập để theo dõi lịch dạy chi tiết theo ngày/tuần và xem thông tin hội viên mình sẽ hỗ trợ. |
| **UC-25** | Xác nhận hoàn thành buổi tập (Mark Session Completed) | Huấn luyện viên (PT), Nhân viên | Cập nhật trạng thái buổi tập sang Completed sau khi kết thúc buổi dạy để làm cơ sở tính lương/hoa hồng dạy. |
| **UC-25** | Điều chỉnh / Hủy lịch đặt PT (Adjust/Cancel PT Schedule) | Nhân viên (Staff), Admin | Hỗ trợ can thiệp sửa đổi hoặc hủy lịch tập khi có sự cố khẩn cấp phát sinh từ phía hội viên hoặc PT. |

---

## **5. Phân hệ 5: Cơ sở vật chất & Truyền thông (Equipment & Operations)**

Kiểm soát vòng đời tài sản vật lý của phòng gym và truyền thông thông tin nội bộ tới người dùng.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-27** | Xem danh sách & Tình trạng thiết bị (View Equipment List) | Admin, Nhân viên (Staff) | Hiển thị danh mục máy móc, tạ, dụng cụ kèm mã thiết bị, ngày mua, hạn bảo hành và vị trí lắp đặt. |
| **UC-27** | Thêm mới thiết bị (Add Equipment) | Admin | Đăng ký thông tin máy móc mới mua (tên máy, ngày mua, hạn bảo hành) và thiết lập trạng thái ban đầu là sẵn sàng hoạt động. |
| **UC-27** | Cập nhật thông tin thiết bị (Update Equipment) | Admin, Nhân viên (Staff) | Chỉnh sửa các thông số kỹ thuật, ghi chú sử dụng hoặc vị trí đặt của thiết bị trong quá trình vận hành. |
| **UC-28** | Báo cáo sự cố thiết bị (Report Equipment Issue) | Nhân viên (Staff), Admin | Tạo form báo cáo hỏng hóc thiết bị, hệ thống tự động đổi trạng thái máy sang Broken hoặc Under Maintenance. |
| **UC-30** | Quản lý lịch bảo trì thiết bị (Manage Maintenance Schedules) | Admin, Nhân viên (Staff) | Thiết lập lịch bảo dưỡng định kỳ cho thiết bị và cập nhật lại trạng thái khả dụng sau khi bảo trì hoàn tất. |
| **UC-31** | Quản lý bài viết thông báo & Chính sách (Manage Blog & Policies) | Admin, Nhân viên (Staff) | Biên soạn và xuất bản các thông báo, chính sách, quy định mới của phòng gym lên bảng tin hệ thống. |
| **UC-11** | Xem danh sách thông báo & Chính sách (View Notifications & Policies) | Hội viên, Nhân viên, PT | Đọc tin tức chính thức và chính sách vận hành của phòng gym trên giao diện bảng tin sau khi đăng nhập. |
| **UC-14** | Tự động gửi cảnh báo gia hạn (Send Renewal Reminders) | Hệ thống (System) / Admin | Job chạy ngầm tự động rà soát hàng ngày, gửi thông báo nhắc nhở tới các hội viên có gói tập sắp hết hạn dưới 5 ngày. |

---

## **6. Phân hệ 6: Tài chính & Báo cáo kết toán (Financials & Reports)**

Ghi nhận dòng doanh thu tập trung và tổng hợp số liệu thống kê kết toán.

| Mã UC | Tên Use Case | Tác nhân chính (Actors) | Mô tả tóm tắt nghiệp vụ |
| :--- | :--- | :--- | :--- |
| **UC-17** | Ghi nhận thanh toán & In hóa đơn (Record Payment) | Nhân viên (Staff), Admin | Xác nhận tiền mặt nhận từ khách tại quầy, đổi trạng thái hóa đơn sang Paid và kích hoạt dịch vụ, hỗ trợ xuất file/in hóa đơn. |
| **UC-19** | Xem lịch sử thanh toán cá nhân (View Personal Payment History) | Hội viên (Member) | Cho phép hội viên chủ động tra cứu lịch sử các hóa đơn tiền mặt mình đã đóng cho phòng gym để đối soát dòng tiền. |
| **UC-19** | Xem toàn bộ lịch sử giao dịch (View System Payment History) | Nhân viên (Staff), Admin | Hỗ trợ tìm kiếm, lọc danh sách hóa đơn theo thời gian hoặc theo hội viên để kết toán quỹ tiền mặt cuối ngày. |
| **UC-07** | Xem báo cáo tăng trưởng hội viên (View Member Growth Reports) | Admin | Kết xuất báo cáo thống kê số lượng hội viên mới, tỷ lệ gia hạn và tỷ lệ hủy gói tập theo biểu đồ thời gian. |
| **UC-20** | Xem báo cáo tài chính & doanh thu (View Financial & Revenue Reports) | Admin | Tổng hợp doanh thu chi tiết từ bán gói tập và dịch vụ PT, vẽ biểu đồ xu hướng doanh thu hàng tháng. |
| **UC-29** | Xem báo cáo tình trạng thiết bị (View Equipment Status Reports) | Admin | Thống kê số lượng máy móc hư hại, tần suất sửa chữa và chi phí bảo trì thiết bị trong phòng tập. |

