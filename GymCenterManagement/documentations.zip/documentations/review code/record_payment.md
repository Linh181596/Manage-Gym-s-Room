# Phân Tích & Review Chi Tiết Luồng Hoạt Động Chức Năng Ghi Nhận Thanh Toán (Record Payment - UC-17)

Tài liệu này trình bày chi tiết về kiến trúc luồng điều phối, xử lý nghiệp vụ giao dịch tiền mặt và in ấn hóa đơn của chức năng **Ghi Nhận Thanh Toán (Record Payment)** dành cho nhân viên lễ tân (**Staff**) trong hệ thống **Gym Center Management System (GCMS)**.

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Kiến trúc luồng xử lý từ lúc liệt kê hóa đơn chờ thanh toán cho tới lúc hoàn tất thanh toán bằng tiền mặt và kích hoạt gói tập của hội viên:

```mermaid
graph TD
    A[Staff Browser] -- GET /staff/record-payment --> B(RecordPaymentController)
    B -- Fetch Invoices list --> C(InvoiceServiceImpl)
    C -- InvoiceDAO.findAll --> D[(Database)]
    D -- Return Invoices --> C
    C -- List to request attribute --> B
    B -- Forward Request --> E[payment-list.jsp]
    
    A -- GET invoiceId detail --> B
    B -- Fetch Single Invoice --> C
    C -- InvoiceDAO.findById --> D
    B -- Forward Request --> F[payment-record-detail.jsp]
    
    A -- POST pay action --> B
    B -- Call recordCashPayment --> C
    C -- Start SQL Transaction --> D
    D -- 1. Query & Lock Invoice --> D
    D -- 2. Update Invoice to Paid --> D
    D -- 3. Update MemberPackage to Active --> D
    D -- Commit Transaction --> D
    C -- Return Success --> B
    B -- Redirect to invoice detail --> A
```

---

## 2. Chi tiết tiến trình xử lý nghiệp vụ (Execution & Transaction Boundaries)

### 2.1. Tra cứu & Hiển thị Hóa đơn (GET Request)
*   **Danh sách hóa đơn**:
    *   **Endpoint**: `GET /staff/record-payment`.
    *   **Tiến trình xử lý (Backend Code Execution Flow)**:
        1.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Nhận request lấy danh sách hóa đơn từ trình duyệt.
        2.  **[InvoiceServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/InvoiceServiceImpl.java)** (`getAllInvoices()`): Controller gọi hàm này để thực thi nghiệp vụ lấy danh sách.
        3.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`findAll()`): Truy xuất toàn bộ hóa đơn từ bảng `Invoices` trong cơ sở dữ liệu.
        4.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Đẩy danh sách nhận được vào request attribute `invoices` và chuyển tiếp đến `payment-list.jsp` để render giao diện (phân tách màu sắc trạng thái Paid/Pending/Cancelled).
*   **Chi tiết hóa đơn đơn lẻ**:
    *   **Endpoint**: `GET /staff/record-payment?invoiceId={id}`.
    *   **Tiến trình xử lý (Backend Code Execution Flow)**:
        1.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Đón nhận tham số `invoiceId` từ request.
        2.  **[InvoiceServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/InvoiceServiceImpl.java)** (`getInvoiceById()`): Controller gọi hàm này để lấy chi tiết hóa đơn.
        3.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`findById()`): Truy vấn thông tin chi tiết một hóa đơn cụ thể theo ID.
        4.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Đẩy vào attribute `invoice` và chuyển tiếp đến `payment-record-detail.jsp` hiển thị giao diện phiếu thanh toán (Receipt Card).

### 2.2. Xác nhận Thanh toán Tiền mặt (POST Request - Luồng Giao Dịch)
*   **Endpoint**: `POST /staff/record-payment` (Tham số: `invoiceId`, `action = "pay"`).
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doPost()`): Trích xuất tham số và đọc thông tin ID nhân viên đang đăng nhập từ Session, sau đó gọi xử lý thanh toán.
    2.  **[InvoiceServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/InvoiceServiceImpl.java)** (`recordCashPayment()`): Bắt đầu kiểm soát giao dịch dữ liệu (**Transaction Isolation**) bằng cách gọi `conn.setAutoCommit(false)`.
    3.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`findById()`): Đọc thông tin hóa đơn và kiểm tra. Nếu hóa đơn không phải là `Pending` (chờ xử lý), ném ra ngoại lệ ngăn chặn thao tác thanh toán trùng lặp.
    4.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`update()`): Thực thi UPDATE hóa đơn sang trạng thái `Paid`, ghi nhận thời gian `PaymentDate` và người thực hiện giao dịch.
    5.  **[MemberPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberPackageDAOImpl.java)** (`findById()` & `update()`): Nếu hóa đơn có liên kết đăng ký gói tập, tải gói tập đó lên và cập nhật trạng thái từ `Pending` sang `Active`.
    6.  **[InvoiceServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/InvoiceServiceImpl.java)** (`recordCashPayment()`): Gọi `conn.commit()` để chốt giao dịch nếu mọi thao tác thành công. Nếu xảy ra lỗi hoặc ngoại lệ ở bước nào, gọi `conn.rollback()` để hoàn tác toàn bộ cập nhật.
    7.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doPost()`): Nhận kết quả thành công, Redirect về lại màn hình `payment-record-detail.jsp` hiển thị hóa đơn đã thanh toán.

---

## 3. Đánh giá chất lượng mã nguồn & các điểm cải tiến (Code Review)

1.  **Tính an toàn dữ liệu (Concurrency & Data Consistency)**:
    *   Việc gom nhóm cập nhật trạng thái hóa đơn (`Invoices`) và trạng thái gói tập (`MemberPackages`) vào cùng một SQL Transaction giúp ngăn ngừa tối đa lỗi không nhất quán dữ liệu ở mức ứng dụng.
2.  **In hóa đơn vật lý chuyên nghiệp**:
    *   Trang chi tiết hóa đơn [payment-record-detail.jsp](file:///d:/Project/Java%20JSP/Manage-Gym-s-Room/GymCenterManagement/src/main/webapp/WEB-INF/views/staff/payment-record-detail.jsp) được tích hợp sẵn thẻ CSS `@media print` thông minh. Khi người dùng nhấn nút "Print Receipt", trình duyệt sẽ kích hoạt bộ lọc CSS này: tự động ẩn toàn bộ các thanh điều hướng (Sidebar, Navbar), các nút bấm hành động và banner hệ thống, chỉ giữ lại khung hóa đơn sạch sẽ để in ấn trực tiếp ra giấy nhiệt hoặc giấy A5.
3.  **Lập báo cáo tài chính trực quan**:
    *   Tại danh sách hóa đơn, hệ thống sử dụng thẻ JSTL tính toán động doanh thu tiền mặt thực tế dựa trên các hóa đơn có trạng thái `Paid` hiện có trên bảng hiển thị, giúp thủ quỹ hoặc lễ tân nhanh chóng đối soát doanh số trong ca trực của mình.

