# Phân Tích & Review Chi Tiết Luồng Hoạt Động Chức Năng Gia Hạn & Chuyển Nhượng Gói Tập (Renew & Transfer Package - UC-18)

Tài liệu này trình bày chi tiết về kiến trúc luồng, quy trình xử lý dữ liệu, cơ chế giao dịch (Transaction) và bảo mật của chức năng **Gia hạn (Renew)** và **Chuyển nhượng (Transfer)** gói tập thành viên dành cho nhân viên lễ tân (**Staff**) trong hệ thống **Gym Center Management System (GCMS)**.

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Luồng gia hạn và chuyển nhượng gói tập tuân thủ mô hình MVC và sử dụng cơ chế xử lý giao dịch cơ sở dữ liệu (Transaction boundary) tại lớp Service để đảm bảo tính nhất quán của dữ liệu.

### 1.1. Luồng Gia hạn (Renew Package)

```mermaid
graph TD
    A[Staff Browser] -- GET /staff/package/renew?memberPackageId=... --> B(RenewPackageController)
    B -- Fetch Active Package Info --> C(MemberPackageServiceImpl)
    C -- Query DB --> D[(Database)]
    B -- Forward Request --> E[package-renew.jsp]
    A -- POST form data --> B
    B -- Call Service renewMemberPackage --> C
    C -- Update Existing MemberPackage (Add Duration) --> D
    C -- Create New Invoice (Pending) --> D
    B -- Redirect to invoice payment details --> F[payment-record-detail.jsp]
```

### 1.2. Luồng Chuyển nhượng (Transfer Package)

```mermaid
graph TD
    A[Staff Browser] -- GET /staff/package/transfer?senderPkgId=... --> B(TransferPackageController)
    B -- Forward Request --> C[package-transfer.jsp]
    A -- POST senderPkgId & receiverMemberId --> B
    B -- Call Service transferMemberPackage --> D(MemberPackageServiceImpl)
    D -- Validate transferred months (6-12) & StartDate --> D
    D -- Create Receiver Pkg (Pending) --> E[(Database)]
    D -- Create Transfer Fee Invoice (5,000/day) --> E
    B -- Redirect to invoice payment details --> F[payment-record-detail.jsp]
```

---

## 2. Chi Tiết Tiến Trình Xử Lý Nghiệp Vụ

### 2.1. Tiến trình Gia hạn (Renew Package)
* **GET `/staff/package/renew`**:
  * **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[RenewPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RenewPackageController.java)** (`doGet()`): Nhận ID của gói tập cũ hoặc ID hội viên (`memberId`).
    2.  **[MemberDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberDAOImpl.java)**: Tầng DAO tìm kiếm Member theo `userId`.
    3.  **[MemberPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MemberPackageServiceImpl.java)** (`getLatestPackageByMemberId()`): Tầng Service tìm gói tập mới nhất của hội viên để hiển thị và giới hạn gói tập được phép gia hạn.
    4.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`getActivePackages()`): (Không còn được dùng để load danh sách gói gia hạn vì logic mới yêu cầu hội viên chỉ được gia hạn đúng gói đang sở hữu).

* **Xử lý (Controller & JSP)**:
  * **[RenewPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RenewPackageController.java)**:
    *   Trong phương thức `doGet()`, controller lấy dữ liệu hội viên và gói tập hiện tại. Hệ thống giới hạn hội viên chỉ được phép gia hạn đúng loại gói tập mà họ đang có. Nếu chưa có gói, HOẶC gói đã hết hạn quá 3 ngày, controller sẽ báo lỗi và chuyển hướng về danh sách hội viên. Dữ liệu được đẩy sang View.
    *   Trong phương thức `doPost()`, controller nhận `packageId` và kiểm tra xác thực (security check) xem ID có khớp với gói đang có không, đồng thời check lại điều kiện gói chưa hết hạn quá 3 ngày. Sau đó gọi hàm `renewMemberPackage` từ tầng Service. Nếu thành công (có Pending Invoice), chuyển hướng sang trang thanh toán.
  * **[package-renew.jsp](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/webapp/WEB-INF/views/staff/package-renew.jsp)**: Hiển thị form cho Staff. Giao diện hiển thị trực quan thông tin gói đang active (nếu có), đồng thời cố định gói được phép gia hạn và tính toán live ngày bắt đầu, ngày hết hạn mới. Điểm nổi bật là dùng Javascript thuần `Date()` kết hợp `c:if` để tính toán chính xác số tháng cộng dồn vào thời gian hết hạn hiện tại của user, cho trải nghiệm rất mượt mà.

* **POST `/staff/package/renew`**:
  * **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[RenewPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RenewPackageController.java)** (`doPost()`): Thu thập thông tin form: `memberId`, `packageId` (gói mới muốn gia hạn). Kiểm tra sự tồn tại của hội viên, sau đó gọi xử lý nghiệp vụ ở tầng Service.
    2.  **[MemberPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MemberPackageServiceImpl.java)** (`renewMemberPackage()`): Bắt đầu kiểm soát luồng giao dịch cơ sở dữ liệu (`conn.setAutoCommit(false)`).
    3.  **[GymPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/GymPackageDAOImpl.java)** (`findById()`): Kiểm tra sự tồn tại và trạng thái của gói Gym mà hội viên định gia hạn. Nếu gói Gym không hoạt động (`Status != 'Active'`), ném `SQLException` kích hoạt `rollback transaction`.
    4.  **[MemberPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberPackageDAOImpl.java)** (`getLatestActivePackageEndDate()`): Kiểm tra không có hóa đơn Pending nào trùng lặp, sau đó xác định ngày bắt đầu của gói mới (Nối tiếp gói cũ hoặc bắt đầu từ hôm nay).
    5.  **[MemberPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberPackageDAOImpl.java)** (`updateEndDate()`): Cập nhật trực tiếp thời hạn (EndDate) của gói tập hiện tại bằng cách cộng dồn thêm thời lượng của gói mới thay vì tạo bản ghi mới (record mới). Gói sẽ nằm ở trạng thái chờ thanh toán để cập nhật (hệ thống có thể lưu tạm thông tin gia hạn vào một bảng phụ hoặc sử dụng cờ).
    6.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`insertPending()`): Tạo hóa đơn thanh toán `Pending` tương ứng, liên kết với gói tập vừa tạo.
    7.  **[MemberPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MemberPackageServiceImpl.java)** (`renewMemberPackage()`): Gọi lệnh `conn.commit()` và trả về ID hóa đơn để đi tiếp.
    8.  **[RenewPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RenewPackageController.java)** (`doPost()`): Chuyển hướng Staff tới trang chi tiết hóa đơn mới tạo để ghi nhận thanh toán.

### 2.2. Tiến trình Chuyển nhượng (Transfer Package)
* **GET `/staff/package/transfer`**:
  * **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[TransferPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/TransferPackageController.java)** (`doGet()`): Nhận `senderPkgId` (ID gói tập của người gửi) và chuyển tiếp tới giao diện `package-transfer.jsp`. (Trang này cung cấp API tìm kiếm người nhận qua AJAX).
* **POST `/staff/package/transfer`**:
  * **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[TransferPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/TransferPackageController.java)** (`doPost()`): Thu thập thông tin: `senderPkgId`, `receiverMemberId` (ID hội viên nhận), `transferStartDate` (Ngày bắt đầu chuyển nhượng) và `transferredMonths` (Số tháng chuyển nhượng). Chuyển tiếp yêu cầu xử lý chuyển nhượng xuống tầng Service.
    2.  **[MemberPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MemberPackageServiceImpl.java)** (`transferMemberPackage()`): Bắt đầu giao dịch cơ sở dữ liệu (`conn.setAutoCommit(false)`). Kiểm tra tính hợp lệ của người nhận (tránh chuyển nhượng cho chính mình).
    3.  **[MemberPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberPackageDAOImpl.java)** (`findById()`): Kiểm tra gói gốc đang `Active`. Tính toán số ngày còn lại của gói để chuyển nhượng toàn bộ. Xác thực `transferStartDate` phải hợp lệ sao cho khoảng thời gian từ đó đến `EndDate` của người gửi khớp với số tháng chuyển nhượng.
    4.  **[MemberPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MemberPackageDAOImpl.java)** (`insertPending()`): Lưu gói tập mới cho người nhận với trạng thái `Pending`, bắt đầu từ `transferStartDate` với thời hạn là số tháng chuyển nhượng.
    5.  **[InvoiceDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/InvoiceDAOImpl.java)** (`insertPending()`): Tạo hóa đơn thanh toán phí dịch vụ chuyển nhượng với mức phí cố định là 5,000 VNĐ/ngày nhân với số ngày chuyển nhượng, trạng thái `Pending`.
    6.  **[MemberPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MemberPackageServiceImpl.java)** (`transferMemberPackage()`): Hoàn thành giao dịch (`conn.commit()`) và trả về ID hóa đơn dịch vụ.
    7.  **[TransferPackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/TransferPackageController.java)** (`doPost()`): Chuyển hướng tới trang chi tiết hóa đơn của phí chuyển nhượng để Staff thực hiện thu tiền mặt hoặc hướng dẫn khách quét mã VNPay.

---

## 3. Đánh Giá Bảo Mật & Điểm Nhấn Kiến Trúc (Code Review)

1. **Ranh giới giao dịch (Database Transaction boundaries)**:
   * Nghiệp vụ gia hạn và đặc biệt là chuyển nhượng có tính chất thay đổi nhiều bảng dữ liệu đồng thời (`MemberPackages` và `Invoices`).
   * Toàn bộ thao tác đều được gói gọn trong một Connection duy nhất với `conn.setAutoCommit(false)`, đảm bảo dữ liệu luôn toàn vẹn và thực hiện `rollback` ngay lập tức nếu bất kỳ bước nào trong tiến trình bị lỗi.
2. **Kích hoạt tự động khi thanh toán**:
   * Khi Staff click xác nhận nhận tiền mặt hoặc hoàn tất thanh toán VNPay tại `RecordPaymentController`:
     * Hóa đơn đổi sang `Paid`.
     * Gói tập của người nhận tự động chuyển sang `Active`.
     * Gói tập của người gửi tự động cập nhật ngày kết thúc (`EndDate`) thành `transferStartDate`. Người gửi vẫn có quyền sử dụng gói cho đến ngày đó.
   * Nếu Staff bấm hủy hóa đơn chuyển nhượng:
     * Hóa đơn đổi sang `Cancelled`.
     * Gói tập `Pending` mới tạo của người nhận sẽ tự động bị xóa vật lý khỏi hệ thống để tránh rác dữ liệu.
3. **Phòng chống các lỗ hổng bảo mật**:
   * **Ngăn chặn chuyển nhượng vô hạn**: Chỉ cho phép chuyển nhượng khi gói gốc ở trạng thái `Active`.
   * **Kiểm soát tạo đơn trùng lặp (Spam Prevention)**: Tầng Service truy vấn CSDL để chặn không cho tài khoản tạo thêm giao dịch gói tập nếu đang có bất kỳ một giao dịch nào ở trạng thái chờ (Pending) chưa giải quyết xong, tránh lỗi đè ngày và kích hoạt chồng chéo.
   * **Kiểm tra tính logic của dữ liệu**: Kiểm tra tính toán số tháng chuyển nhượng và `transferStartDate` phải chính xác (từ 6 đến 12 tháng) trước khi cho phép lập hóa đơn chuyển nhượng.
   * **Chống giả mạo tham số (IDOR / Parameter Tampering)**: Mọi thông tin như số tiền hóa đơn dịch vụ, số ngày chuyển giao đều được tính toán hoàn toàn ở phía Backend, Client không thể can thiệp sửa đổi.

