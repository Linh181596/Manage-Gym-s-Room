# Phân Tích & Review Chi Tiết Luồng Hoạt Động Chức Năng Xem Lịch Sử Thanh Toán (View Payment History - UC-19)

Tài liệu này trình bày chi tiết về kiến trúc luồng, kiểm soát truy cập vai trò (RBAC), cải tiến giao diện (JSP/UI) và cơ chế lọc ngày phía Client của chức năng **Xem lịch sử thanh toán (View Payment History)** dành cho nhân viên lễ tân (**Staff**) và quản trị viên (**Admin**) trong hệ thống **GCMS**.

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Chức năng sử dụng một Controller chung `RecordPaymentController` nhưng phân chia logic hiển thị và quyền hành động ở giao diện JSP dựa trên vai trò của người dùng trong Session:

```mermaid
graph TD
    A[User Browser] -- GET /staff/record-payment or /admin/payment-history --> B(AuthenticationFilter)
    B -- Check Permission --> C(RecordPaymentController)
    C -- Fetch All Invoices --> D(InvoiceServiceImpl)
    D -- Query DB --> E[(Database)]
    C -- Forward Request --> F[payment-list.jsp]
    F -- Render Dynamic Views according to Role --> A
```

---

## 2. Chi Tiết Tiến Trình Xử Lý Nghiệp Vụ

### 2.1. Tiếp nhận và Định tuyến (Controller Layer)
* **Endpoint**: 
  * Staff: `/staff/record-payment`
  * Admin: `/admin/payment-history`
* **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Nhận yêu cầu GET hiển thị danh sách hóa đơn từ trình duyệt.
    2.  **[InvoiceServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/InvoiceServiceImpl.java)** (`getAllInvoices()`): Controller gọi Service để tải toàn bộ danh sách hóa đơn từ Database.
    3.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doGet()`): Lưu danh sách vào request attribute `"invoices"` và Forward yêu cầu tới `payment-list.jsp`.
    4.  **[RecordPaymentController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/staff/RecordPaymentController.java)** (`doPost()`): Đối với các hành động POST (Thanh toán / Hủy), Controller lấy servlet path hiện tại (`request.getServletPath()`) để thực hiện lệnh chuyển hướng `response.sendRedirect(...)` động, giữ người dùng ở lại đúng context phù hợp (Admin hoặc Staff).

### 2.2. Kiểm soát hiển thị & Quyền hạn tại Giao diện (JSP/UI Layer)
* **Phân biệt vai trò**:
  * Sử dụng biến EL `${sessionScope.currentUser.role == 'Admin'}` để thiết lập cờ `isAdmin`.
  * Tiêu đề và mô tả trang hiển thị động tương thích với ngữ cảnh nghiệp vụ của từng vai trò.
* **Quyền thực hiện Cashier (Thu tiền mặt / Hủy)**:
  * Nút "Thu tiền" trên bảng danh sách chỉ hiển thị cho hóa đơn `Pending` khi người dùng **không phải là Admin** (tức là Staff).
  * Tại trang chi tiết hóa đơn [payment-record-detail.jsp](file:///c:/Projects/[Java]/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/webapp/WEB-INF/views/staff/payment-record-detail.jsp), hai hành động xác nhận thanh toán tiền mặt và hủy hóa đơn được ẩn hoàn toàn đối với Admin.

---

## 3. Cải Tiến Kỹ Thuật & Cơ Chế Lọc Phía Client (Client-Side Filter Review)

1. **Bộ lọc khoảng thời gian (Date Range Filter)**:
   * Thêm 2 thẻ input `type="date"` với ID `startDateFilter` và `endDateFilter`.
   * Mỗi thẻ tr `<tr>` hiển thị hóa đơn được bổ sung thuộc tính `data-date` lưu trữ ngày giao dịch thực tế dạng `YYYY-MM-DD`.
     * Ngày giao dịch được tính toán động: Nếu trạng thái hóa đơn là `Paid`, lấy ngày thanh toán (`paymentDate`), ngược lại lấy ngày tạo (`createdDate`).
2. **Thuật toán so sánh ngày bằng JS**:
   * Khi thay đổi bất kỳ bộ lọc nào (Tìm kiếm, Trạng thái, Từ ngày, Đến ngày), hàm `filterInvoices()` sẽ được kích hoạt.
   * Logic lọc ngày thực hiện so sánh chuỗi trực tiếp:
     * Định dạng `YYYY-MM-DD` cho phép so sánh lớn hơn/nhỏ hơn một cách chuẩn xác theo thứ tự bảng chữ cái (lexicographical order), tránh việc phải parse sang đối tượng `Date` của JS giúp tăng hiệu năng xử lý đáng kể.
     * Kiểm tra điều kiện: `rowDate >= startVal` và `rowDate <= endVal`.
3. **Ưu và nhược điểm của luồng xử lý và Lọc dữ liệu**:
   * *Ưu điểm*: Trải nghiệm người dùng mượt mà, phản hồi tức thì dưới 1ms khi lọc dữ liệu trên bảng, giảm tải hoàn toàn các truy vấn SELECT lặp đi lặp lại lên Database Server.
   * *Phân trang Server-side (Pagination)*: Hệ thống **đã triển khai** cơ chế phân trang ở phía Backend (thông qua `PaginationHelper` và `invoiceService.getInvoicesPaginated`). Điều này giải quyết bài toán hiệu năng khi số lượng hóa đơn lên tới hàng chục nghìn bản ghi, đảm bảo chỉ tải về đúng số lượng bản ghi cần thiết cho từng trang (`pageSize`) trong khi vẫn hỗ trợ lọc và tính toán động cho từng trang một cách hiệu quả.

