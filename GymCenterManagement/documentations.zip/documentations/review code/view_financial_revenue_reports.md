# Phân Tích & Review Code - Báo Cáo Tăng Trưởng Thành Viên (Membership Growth Report - UC-20)

Tài liệu này ghi nhận kết quả review code và phân tích luồng cho tính năng **Báo Cáo Tăng Trưởng Thành Viên (Membership Growth Report)**. Thay vì báo cáo doanh thu tài chính thông thường, mã nguồn hệ thống hiện đang triển khai tập trung vào việc đo lường và theo dõi sự gia tăng lượng thành viên thông qua controller `MembershipGrowthReportController`.

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Mô hình luồng trích xuất dữ liệu báo cáo từ lúc nhận yêu cầu lọc cho đến lúc trả về biểu đồ và danh sách phân trang:

```mermaid
graph TD
    A[Admin Browser] -- GET /admin/membership-growth-report --> B(MembershipGrowthReportController)
    B -- 1. Parse Filters (Year, Month, Status) --> B
    B -- 2. Fetch Summary & Chart Data --> C(MembershipGrowthReportServiceImpl)
    C -- SQL Aggregation --> D[(Database)]
    D -- Return Data --> C
    C -- Map to DTOs --> B
    B -- 3. Count Total & Apply Pagination --> B
    B -- 4. Fetch Paginated Member List --> C
    C -- SQL Pagination with OFFSET --> D
    D -- Return Rows --> C
    C -- Map to MembershipGrowthMember --> B
    B -- Render JSON for Chart & Set Attributes --> E[membership-growth-report.jsp]
    E -- Render View --> A
```

---

## 2. Chi Tiết Tiến Trình Xử Lý Nghiệp Vụ

### 2.1. Phân Tích Dữ Liệu Bộ Lọc (Filter Parsing)
*   **Endpoint**: `GET /admin/membership-growth-report`.
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[MembershipGrowthReportController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/MembershipGrowthReportController.java)** (`doGet()`): Hệ thống tiếp nhận các tham số lọc từ URL: `year` (năm), `month` (tháng), `status` (trạng thái: new, active, expired), và `searchKeyword`.
    2.  **[MembershipGrowthReportController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/MembershipGrowthReportController.java)** (`resolveYear()`): Controller tự động lấy danh sách năm khả dụng từ CSDL (`getAvailableYears()`) và xử lý giá trị mặc định về năm hiện tại nếu tham số truyền vào không hợp lệ.

### 2.2. Trích Xuất Dữ Liệu Tổng Quan & Biểu Đồ
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[MembershipGrowthReportServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MembershipGrowthReportServiceImpl.java)** (`getGrowthSummary()`, `getChartData()`): Controller gọi Service để trích xuất dữ liệu tổng quan và dữ liệu vẽ biểu đồ.
    2.  **[MembershipGrowthReportDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MembershipGrowthReportDAOImpl.java)**: Thực thi SQL kết hợp hàm `GROUP BY` để nhóm dữ liệu. Hỗ trợ 2 luồng: Báo cáo theo Tháng (nhóm theo tháng trong 1 năm) hoặc theo Ngày (nhóm theo ngày trong 1 tháng). Dữ liệu thô sau đó được ánh xạ thành các DTO `MembershipGrowthSummary` và `MembershipGrowthChartPoint`.

### 2.3. Trích Xuất Danh Sách Phân Trang (Paginated Table)
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[MembershipGrowthReportController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/MembershipGrowthReportController.java)** (`doGet()`): Sử dụng tiện ích `PaginationHelper` tính toán số trang (Total Pages), trang hiện tại (Current Page), và phần bù (`offset`) theo `pageSize`. Hỗ trợ giữ nguyên tham số lọc bằng `queryBase`.
    2.  **[MembershipGrowthReportServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/MembershipGrowthReportServiceImpl.java)** (`getMemberGrowthList()`): Controller gọi Service truyền tham số lọc kèm `offset` và `PAGE_SIZE`.
    3.  **[MembershipGrowthReportDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/MembershipGrowthReportDAOImpl.java)** (`getMemberGrowthList()`): Truy vấn danh sách bản ghi phân trang từ cơ sở dữ liệu (SQL `OFFSET...FETCH`).

### 2.4. Kết xuất Giao Diện (JSP & Chart Rendering)
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[MembershipGrowthReportController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/MembershipGrowthReportController.java)** (`buildChartLabelsJson()`, `buildChartValuesJson()`): Controller chuyển đổi dữ liệu biểu đồ thành mảng JSON `["Tháng 1","Tháng 2"]` đẩy qua request attribute để frontend render biểu đồ an toàn mà không cần call API qua AJAX.
    2.  **[MembershipGrowthReportController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/MembershipGrowthReportController.java)** (`doGet()`): Forward toàn bộ dữ liệu qua trang giao diện `membership-growth-report.jsp`.

---

## 3. Đánh giá chất lượng mã nguồn & Điểm cải tiến (Code Review)

1.  **Phân quyền chặt chẽ (Security)**: Controller sử dụng hàm `ensureAdmin(request, response)` ở ngay đầu hàm GET để chặn tất cả request nếu `currentUser` không phải là `Admin`. Response trả về `SC_FORBIDDEN` và chuyển hướng tới `error-403.jsp`.
2.  **Xử lý ngoại lệ thân thiện (Graceful Degradation)**: Trong khối `catch (SQLException ex)`, hệ thống không crash mà chủ động fallback về các tham số mặc định (fallbackYears, summary rỗng, mảng rỗng) đồng thời đẩy ra `errorMessage` nhắc nhở người dùng, tránh hiện tượng trắng trang (White-Screen of Death).
3.  **Tách biệt logic (Separation of Concerns)**: Hàm Controller khá dài (hơn 220 dòng) nhưng được module hóa tốt nhờ hàng loạt các `private helper methods` như `resolveMonth`, `normalizeStatus`, `getStatusLabel`, giúp code có tính Readability cao.
4.  **Tối ưu (Optimization)**: Đã áp dụng xử lý gom nhóm dữ liệu (Group By) và tính toán số lượng (`COUNT`) hoàn toàn bằng sức mạnh của SQL ở tầng Database thông qua `MembershipGrowthReportDAOImpl`, tối giản công việc của RAM máy chủ Web.
