# Phân Tích & Review Chi Tiết Luồng Hoạt Động Chức Năng Quản Lý Gói Tập (Manage Package - UC-15)

Tài liệu này trình bày chi tiết về kiến trúc luồng, cách thức xử lý dữ liệu và mã nguồn của chức năng **Quản lý Gói Tập (Manage Package)** dành cho vai trò quản trị viên (**Admin**) trong hệ thống **Gym Center Management System (GCMS)**.

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Luồng xử lý tuân thủ chuẩn mô hình kiến trúc **MVC (Model-View-Controller)** và thiết kế **3-Layer Architecture** (Presentation -> Service -> DAO -> Database):

```mermaid
graph TD
    A[Admin Browser] -- GET /admin/packages --> B(ManagePackageController)
    B -- Call Service --> C(GymPackageServiceImpl)
    C -- Call DAO --> D(GymPackageDAOImpl)
    D -- Query SELECT --> E[(Database: GymPackages)]
    E -- Result Sets --> D
    D -- Map Entity List --> C
    C -- Return GymPackages --> B
    B -- Forward Request Attributes --> F[package-list.jsp]
    F -- Render HTML Table --> A
```

---

## 2. Chi tiết các luồng xử lý nghiệp vụ (CRUD Operational Flows)

### 2.1. Luồng hiển thị danh sách gói tập (Read/List)
*   **Endpoint**: `GET /admin/packages?action=list` (hoặc action mặc định khi `action == null`).
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Đón nhận request từ trình duyệt, kiểm tra tham số `action`.
    2.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`getAllPackages()`): Controller gọi hàm này để lấy danh sách gói tập.
    3.  **[GymPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/GymPackageDAOImpl.java)** (`findAll()`): Tầng Service gọi hàm này để thực thi câu lệnh SQL:
        ```sql
        SELECT * FROM GymPackages WHERE IsDeleted = 0 ORDER BY PackageID DESC
        ```
    4.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Bản ghi trả về được ánh xạ thành danh sách đối tượng `List<GymPackage>`, đẩy vào Request Attribute dưới tên `packages` và forward sang `package-list.jsp` để render.

### 2.2. Luồng tạo mới gói tập (Create)
*   **Giao diện nhập liệu (GET)**:
    *   **Endpoint**: `GET /admin/packages?action=create`.
    *   **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Thiết lập `formTitle = "Create Gym Package"` và forward sang `package-form.jsp` hiển thị form trống.
*   **Lưu dữ liệu (POST)**:
    *   **Endpoint**: `POST /admin/packages` (tham số `packageId` rỗng hoặc bằng null).
    *   **Tiến trình xử lý (Backend Code Execution Flow)**:
        1.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doPost()`): Trích xuất dữ liệu form, kiểm tra tính hợp lệ (Validation) và lấy thông tin người tạo từ Session (Audit Logging). Nếu có lỗi validation cơ bản, trả về form kèm `errorMessage`.
        2.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`isPackageNameExists()`): Controller gọi hàm này để kiểm tra trùng lặp tên gói. Nếu tồn tại, trả về lỗi nhắc nhở người dùng.
        3.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`createPackage()`): Gọi hàm này để thực hiện tạo mới gói tập.
        4.  **[GymPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/GymPackageDAOImpl.java)** (`insert()`): DAO thực thi câu lệnh SQL INSERT đồng thời trả về ID khóa chính tự tăng:
            ```sql
            INSERT INTO GymPackages (PackageName, DurationMonths, Price, Description, Status, CreatedBy, CreatedDate, IsDeleted) 
            VALUES (?, ?, ?, ?, ?, ?, GETDATE(), 0)
            ```
        5.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doPost()`): Chuyển hướng (Redirect) về `/admin/packages?successMsg=...` để hoàn tất quy trình.

### 2.3. Luồng chỉnh sửa thông tin gói tập (Update)
*   **Giao diện hiển thị dữ liệu cũ (GET)**:
    *   **Endpoint**: `GET /admin/packages?action=edit&id={packageId}`.
    *   **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Tìm kiếm đối tượng bằng ID qua Service, gán vào request attribute `pkg` và forward sang `package-form.jsp` để đổ dữ liệu cũ vào các trường input.
*   **Cập nhật dữ liệu (POST)**:
    *   **Endpoint**: `POST /admin/packages` (có chứa tham số ẩn `packageId`).
    *   **Tiến trình xử lý (Backend Code Execution Flow)**:
        1.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doPost()`): Kiểm tra tính hợp lệ của dữ liệu nhập và ghi nhận tên Admin cập nhật vào thuộc tính `updatedBy`.
        2.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`isPackageNameExists()`): Kiểm tra tên gọi mới không bị trùng với các gói tập khác.
        3.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`updatePackage()`): Gọi hàm này để thực hiện cập nhật.
        4.  **[GymPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/GymPackageDAOImpl.java)** (`update()`): Thực thi câu lệnh SQL UPDATE:
            ```sql
            UPDATE GymPackages 
            SET PackageName = ?, DurationMonths = ?, Price = ?, Description = ?, Status = ?, UpdatedBy = ?, UpdatedDate = GETDATE() 
            WHERE PackageID = ? AND IsDeleted = 0
            ```
        5.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doPost()`): Chuyển hướng (Redirect) về danh sách kèm thông báo cập nhật thành công.

### 2.4. Luồng xóa gói tập (Soft Delete)
*   **Endpoint**: `GET /admin/packages?action=delete&id={packageId}`.
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Đón nhận request chứa `action=delete` và `id` sau khi Admin xác nhận hộp thoại trên giao diện.
    2.  **[GymPackageServiceImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/service/impl/GymPackageServiceImpl.java)** (`deletePackage()`): Controller chuyển tiếp lệnh xóa đến lớp dịch vụ.
    3.  **[GymPackageDAOImpl.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/dao/impl/GymPackageDAOImpl.java)** (`delete()`): DAO thực hiện **Soft Delete (Xóa mềm)** bằng cách cập nhật trạng thái cờ xóa thay vì xóa vật lý trong database:
        ```sql
        UPDATE GymPackages SET IsDeleted = 1 WHERE PackageID = ?
        ```
        *Lợi ích*: Đảm bảo toàn vẹn dữ liệu tham chiếu (Foreign Key Integrity). Các lịch sử giao dịch và gói tập hội viên đã đăng ký từ trước không bị hỏng liên kết khóa ngoại.
    4.  **[ManagePackageController.java](file:///c:/Projects/%5BJava%5D/Servlet/Manage-Gym-s-Room/GymCenterManagement/src/main/java/com/mycompany/gymcentermanagement/controller/admin/ManagePackageController.java)** (`doGet()`): Chuyển hướng về lại danh sách gói tập.

---

## 3. Đánh giá chất lượng mã nguồn & các điểm cải tiến (Code Review)

1.  **Tính bảo mật & Ràng buộc phân quyền**:
    *   Các luồng xử lý nghiệp vụ được thực thi thông qua Servlet được cấu hình URL là `/admin/packages`. Cần kết hợp sử dụng `Filter` để chặn các request trái phép nếu User đăng nhập không phải vai trò `Admin`.
2.  **Quản lý giao dịch dữ liệu (Transaction Management)**:
    *   Do các nghiệp vụ CRUD gói tập chỉ tác động đơn lẻ vào một bảng độc lập `GymPackages`, cấu hình tự động Auto-Commit mặc định của JDBC là hoàn toàn phù hợp và an toàn.
3.  **UI/UX và Trải nghiệm Người dùng**:
    *   Sử dụng cơ chế kiểm tra lỗi kép: Client-side validation (Bootstrap `needs-validation`) để kiểm tra nhanh và Server-side validation để bảo vệ tính toàn vẹn của dữ liệu ở backend.
    *   Hỗ trợ bộ lọc tìm kiếm nhanh trực tiếp trên Client bằng JavaScript giúp tối ưu tài nguyên máy chủ và tăng độ mượt mà cho trải nghiệm người dùng.

