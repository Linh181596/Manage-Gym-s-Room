# Phân Tích & Review Chi Tiết Luồng Hoạt Động Chức Năng Đăng Ký Gói Tập (Register Package - UC-16)

Tài liệu này trình bày chi tiết về kiến trúc luồng, cách thức xử lý dữ liệu và kiểm soát giao dịch (transaction) của chức năng **Đăng ký Gói Tập (Register Package)** dành cho **Hội viên (Member)** tự thao tác trên hệ thống (Member Self-Registration).

---

## 1. Sơ đồ điều hướng tổng quan (Workflow Architecture)

Kiến trúc luồng xử lý từ lúc hội viên chọn gói tập, chọn phương thức thanh toán cho đến lúc tạo hóa đơn và xử lý thanh toán:

```mermaid
graph TD
    A[Member Browser] -- GET /member/register-package --> B(Controller)
    B -- Fetch Active Packages --> C(MemberPackageServiceImpl)
    C -- GymPackageDAO --> D[(Database)]
    D -- Return List --> C
    C -- Set Attributes --> B
    B -- Forward Request --> E[package-register.jsp]
    
    A -- POST selected Package & PaymentMethod --> B
    B -- Call registerMemberPackage --> C
    C -- Start SQL Transaction --> D
    D -- 1. Query GymPackage --> D
    D -- 2. Check Member Package History --> D
    D -- 3. Insert MemberPackage (Pending) --> D
    D -- 4. Insert Invoice (Pending) --> D
    D -- Commit Transaction --> D
    C -- Return Pending Invoice --> B
    
    B -- If VNPay --> F[Redirect to /member/vnpay-create]
    F -- Process VNPay Gateway --> A
    B -- If Cash --> G[Redirect to Payment Alert Page]
    G -- Wait for Staff Confirmation --> A
```

---

## 2. Chi tiết các bước xử lý nghiệp vụ (Step-by-Step Execution)

### 2.1. Tải dữ liệu đăng ký (GET Request)
*   **Endpoint**: `GET /member/register-package`.
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **MemberRegisterPackageController.java** (`doGet()`): Đón nhận request tải trang đăng ký từ Member.
    2.  **GymPackageServiceImpl.java** (`getActivePackages()`): Lấy danh sách các gói tập đang mở bán.
    3.  **MemberRegisterPackageController.java** (`doGet()`): Lưu danh sách vào request attribute `packages`, sau đó forward sang trang giao diện `/WEB-INF/views/member/package-register.jsp`.

### 2.2. Đăng ký & Tạo hóa đơn tạm (POST Request - Luồng Giao Dịch)
*   **Endpoint**: `POST /member/register-package` (tham số gửi lên: `packageId`, `paymentMethod`).
*   **Tiến trình xử lý (Backend Code Execution Flow)**:
    1.  **MemberRegisterPackageController.java** (`doPost()`): Trích xuất `packageId`, `paymentMethod` ('VNPay' hoặc 'Cash') và lấy `memberId` từ Session. Gọi tầng Service.
    2.  **MemberPackageServiceImpl.java** (`registerMemberPackage()`): Khởi động Giao dịch SQL (**SQL Transaction**) bằng `conn.setAutoCommit(false)`.
    3.  **GymPackageDAOImpl.java** (`findById()`): Truy vấn thông tin gói tập theo `packageId` và kiểm tra trạng thái mở bán.
    4.  **MemberPackageDAOImpl.java** (`checkMemberPackageHistory()`): Truy vấn xem hội viên đã từng sở hữu gói tập nào chưa. Nếu có lịch sử, chặn đăng ký và yêu cầu dùng chức năng Gia hạn (Renew).
    5.  **MemberPackageDAOImpl.java** (`insertPending()`): Chèn bản ghi đăng ký gói tập với trạng thái `Pending` (`CreatedBy` = "Member Self-Registration").
    6.  **InvoiceDAOImpl.java** (`insert()`): Chèn hóa đơn (`Invoice`) trạng thái `Pending`, tham chiếu tới `MemberPackageID`. `ProcessBy` là Null.
    7.  **MemberPackageServiceImpl.java** (`registerMemberPackage()`): Gọi `conn.commit()` lưu thành công, hoặc `conn.rollback()` nếu xảy ra lỗi.
    8.  **Điều hướng**:
        *   Nếu là Member tự đăng ký (VNPay): Redirect sang `/member/vnpay-create?invoiceId=...` để khởi tạo cổng thanh toán trực tuyến (Sau khi thanh toán thành công, phương thức lưu về DB là 'Banking').
        *   Nếu là Member tự đăng ký (Cash): Redirect về trang thông báo chờ nhân viên thu ngân xác nhận.

---

## 3. Đánh giá chất lượng mã nguồn & Điểm nhấn kiến trúc (Code Review)

1.  **Chuyên Biệt Hóa Quy Trình (Self-Service)**: Việc giao toàn bộ việc đăng ký gói tập cho Hội viên giúp giảm tải công việc ở quầy lễ tân và số hóa hoàn toàn quá trình onboard.
2.  **Quản lý kết nối & Giao dịch chặt chẽ**: Transaction SQL đảm bảo tạo đồng thời đăng ký gói tập và hóa đơn, nếu lỗi xảy ra sẽ hủy toàn bộ để không phát sinh rác dữ liệu.
3.  **Khép kín quy trình thanh toán**: Việc tách biệt đường dẫn thanh toán `VNPay` (kích hoạt tự động qua callback) và `Cash` (Staff dùng màn hình `/staff/record-payment` để đổi status sang Paid) tạo luồng vận hành linh hoạt và thực tế.

