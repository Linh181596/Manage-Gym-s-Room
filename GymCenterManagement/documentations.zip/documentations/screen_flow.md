# Screen Flow - Gym Center Management System

Tài liệu này cung cấp sơ đồ Screen Flow mô tả luồng điều hướng giữa các màn hình chức năng chính trong hệ thống **GCMS (Gym Center Management System)**, dựa theo kiến trúc MVC hiện tại của dự án. 
Bạn có thể copy đoạn code Mermaid bên dưới và dán vào [Mermaid Live Editor](https://mermaid.live/) để xem và xuất ảnh.

## 1. Mermaid Graph (Screen Flow)

```mermaid
graph LR
    %% Public & Auth Flow
    PublicHome[Public Home / Content List] --> ContentDetail[Content Details]
    PublicHome --> Login[User Login]
    
    Login --> Register[User Register]
    Register --> VerifyEmail[Verify Email]
    Login --> ForgotPassword[Forgot Password]
    ForgotPassword --> ResetPassword[Reset Password]
    
    %% Role-based Routing from Login
    Login --> MemberDashboard[Member Portal / Dashboard]
    Login --> StaffDashboard[Staff Dashboard]
    Login --> AdminDashboard[Admin Dashboard]
    Login --> PTDashboard[PT Dashboard]
    
    %% Shared Profile Flow
    MemberDashboard --> Profile[User Profile]
    StaffDashboard --> Profile
    AdminDashboard --> Profile
    PTDashboard --> PTProfile[PT Edit Profile]
    Profile --> ChangePassword[Change Password]
    PTProfile --> ChangePassword

    %% Member Flow
    MemberDashboard --> Notifications[Notifications]
    MemberDashboard --> InvoiceDetail[Invoice / Payment Details]
    MemberDashboard --> MemberSchedule[Member Schedule Dashboard]
    MemberDashboard --> PTList[Public PT List]
    PTList --> PTDetail[PT Details]

    %% Staff Flow
    StaffDashboard --> MembersList[Members Management]
    MembersList --> PackageRegister[Register Gym Package]
    MembersList --> PackageRenew[Renew Gym Package]
    MembersList --> PackageTransfer[Transfer Gym Package]
    
    StaffDashboard --> PaymentList[Payment / Invoices List]
    PaymentList --> PaymentDetail[Payment Record Detail]
    
    StaffDashboard --> EquipmentList[Equipment Management]
    EquipmentList --> EquipmentForm[Equipment Details/Form]
    EquipmentList --> IssueList[Equipment Issues]
    IssueList --> IssueForm[Issue Details/Form]
    StaffDashboard --> MaintenanceList[Maintenance Schedules]

    %% Admin Flow
    AdminDashboard --> PackageList[Gym Packages List]
    PackageList --> PackageForm[Package Form]
    
    AdminDashboard --> PTPackageList[PT Packages List]
    PTPackageList --> PTPackageForm[PT Package Form]
    
    AdminDashboard --> Reports[Financial & Growth Reports]
    AdminDashboard --> NotificationMgmt[Notification List]
    NotificationMgmt --> NotificationForm[Notification Form]
    
    AdminDashboard --> ScheduleMgmt[Manage Schedule / Setup]
    AdminDashboard --> PTManagement[PT Accounts Management]
    PTManagement --> EditPT[Edit PT Info]

    %% PT Flow
    PTDashboard --> MyMembers[My Members]
    PTDashboard --> PTSchedule[PT Schedule Dashboard]
    PTDashboard --> PTServiceRegister[Register PT Service]
```

## 2. List of Non-UI Functions (Core Processing)

Theo yêu cầu từ biểu mẫu, đây là danh sách các **Non-UI functions (Chức năng xử lý ngầm/không có giao diện)** đã được implement trong hệ thống:
1. **Password Encryption & Verification (Bcrypt)**: Mã hóa mật khẩu khi đăng ký/đổi mật khẩu.
2. **Email Notification Service**: Gửi email OTP (Verify Email), Reset Password link, và các thông báo lịch học/hóa đơn.
3. **Automated Package Expiration Check**: Job chạy ngầm hoặc logic kiểm tra cập nhật trạng thái gói tập (`Active` -> `Expired`) khi hết hạn.
4. **Duration & Expiry Calculation**: Logic tính toán thời hạn khi mua mới, gia hạn, hoặc chuyển nhượng gói tập dựa vào `ChronoUnit.DAYS` và lịch sử giao dịch.
5. **Authorization / Filter Chains**: Bộ lọc (Filters) chặn truy cập trái phép, phân quyền cứng theo Role (`Member`, `Staff`, `Admin`, `PT`).
6. **Dashboard Data Aggregation**: Các hàm tổng hợp thống kê tài chính, báo cáo tăng trưởng (SQL Group By, Sum) trả về cho biểu đồ (Chart.js) mà không tạo ra giao diện riêng biệt.

---
*Lưu ý: Sơ đồ trên tập trung vào các luồng thao tác màn hình chính (JSP views) mà người dùng có thể điều hướng qua lại.*
