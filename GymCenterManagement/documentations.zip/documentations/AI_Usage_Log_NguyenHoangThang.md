# Báo cáo Sử dụng AI (AI Usage Report) - Nguyễn Hoàng Thắng

Dựa trên lịch sử phiên làm việc gần nhất của chúng ta liên quan đến các chức năng quản lý Gói tập (Package Registration, Renew, Transfer) và theo chuẩn định dạng của file Excel/TSV bạn cung cấp, dưới đây là bảng log chi tiết các tác vụ mà tớ (AI) đã hỗ trợ bạn thực hiện.

Bạn có thể copy nội dung bảng này dán trực tiếp vào file Excel theo các cột tương ứng.

| SDLC Phase | Task / Activity | AI Tool Used | AI Output | Student's Validation / Modification | Evidence / Link | Quantitative Measure | Value Added (1-5) | Risks / Limitations Observed |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Coding, Testing** | Fix compilation error in Transfer Package feature (`senderMemberId cannot be resolved`) | Gemini IDE | Identified the undefined variable. Provided code fix by replacing `senderMemberId` with `senderPackage.getMemberId()` in `MemberPackageServiceImpl.java`. | Asked AI to explain the error and fix it. Verified the fix successfully compiled and resolved the issue. | Gemini IDE Chat | 1 Java file updated (`MemberPackageServiceImpl.java`) | 5 | AI needed the exact error message and line number to pinpoint the context quickly. |
| **Requirement Analysis, Coding** | Analyze business rules for package transfer duration (Remaining Days calculation) | Gemini IDE | Explained the calculation logic. Updated `TransferPackageController.java` to use `EndDate - MAX(StartDate, Today)` to accurately calculate days for future-dated packages. | Questioned why a 1-month package had 63 days remaining. Reviewed the AI's explanation and verified the new logic for calculating transfer days. | Gemini IDE Chat | 1 Controller file updated (`TransferPackageController.java`) | 5 | Required iterative discussion to clarify the exact business requirement and edge cases. |
| **Requirement Analysis, Design, Coding** | Implement new Business Rule: Forbid creating new transactions if a Pending transaction exists to prevent overlapping dates | Gemini IDE | Discussed the overlap issue. Wrote backend logic in `MemberPackageServiceImpl.java` for both `registerMemberPackage` and `transferMemberPackage` to block spamming invoices. | Proposed the new business rule to the AI (block if account has a pending transaction). Validated the logic implemented by AI. | Gemini IDE Chat | 1 Service file updated (`MemberPackageServiceImpl.java`) | 5 | AI initially followed the old logic, requiring the developer's business insight to propose a better global rule. |
| **Requirement Analysis, Design, Testing** | Update system documentation, diagrams, and test cases to reflect the new anti-spam Pending transaction rule | Gemini IDE | Automatically searched and updated `srs_document.md`, `renew_transfer_package_testcases.md`, `renew_transfer_package.md`, and 3 Swimlane/Sequence diagrams. | Provided the list of documents to update. Verified the changes in Mermaid diagrams, Markdown texts, and test cases matched the newly implemented logic. | Gemini IDE Chat | 1 SRS, 1 Test case, 1 Review code doc, 3 Diagrams updated (6 files total) | 5 | AI needed explicit instruction on which files and diagrams to update to ensure consistency. |

---

## 📝 Tóm tắt các công việc đã giải quyết trong phiên làm việc (Session Summary)
1. **Fix bug:** Lỗi không tìm thấy biến `senderMemberId` khi lưu lịch sử tạo package mới.
2. **Xử lý logic ngày tháng:** Khắc phục lỗi tính sai ngày còn lại (Remaining Days) khi chuyển nhượng các gói tập chưa đến hạn kích hoạt.
3. **Thiết kế lại Business Rule (Rất xuất sắc từ phía bạn):** Đưa ra quy định chặt chẽ chặn việc tạo nhiều hóa đơn chuyển nhượng/gia hạn cùng lúc để triệt tiêu hoàn toàn bug đè ngày (Overlapping dates) và spam rác dữ liệu. Áp dụng logic này vào thẳng code Backend (Tầng Service).
4. **Đồng bộ hóa Tài liệu & Diagram:** AI tự động quét và sửa các quy tắc cũ thành quy tắc mới trong hệ thống tài liệu:
   - Sửa UML Sequence Diagram & Swimlane Diagram (đổi điều kiện `if`).
   - Sửa tài liệu SRS (Alternative Flow E5, E2).
   - Thêm 2 Test Case mới (`TC-RNT-006`, `TC-RNT-007`).
   - Cập nhật tài liệu Review Code (Phòng chống lỗ hổng bảo mật - Spam Prevention).
