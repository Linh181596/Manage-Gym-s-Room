**BẢN ĐĂNG KÝ ĐỀ TÀI DỰ ÁN PHẦN MỀM**

**1\. Thông tin thành viên nhóm**

| STT | Mã sinh viên | Họ và tên | Vai trò dự kiến |
| :---: | :---: | :---: | :---: |
| **1** | HE187234 | Nguyễn Đại Dương | Trưởng nhóm  |
| **2** | HE181596 | Nguyễn Trí Linh |  |
| **3** | HE181315 | Nguyễn Đình Phú |  |
| **4** | HE182118 | Đỗ Minh Hoàng |  |
| **5** | HE171276 | Nguyễn Hoàng Thắng |  |

**2\. Tên đề tài đăng ký: Gym Center Management System**

**3\. Mô tả tóm tắt đề tài**

**Danh sách các Actors (Tác nhân)**

* \<Admin/Chủ phòng gym\>: Quản lý toàn bộ hệ thống, tài khoản người dùng, hội viên, nhân viên, PT, gói tập, thiết bị, thông báo và báo cáo thống kê. 

* \<Nhân viên\>: Hỗ trợ hội viên đăng ký/gia hạn gói tập, ghi nhận thanh toán, quản lý thông tin hội viên, PT và thiết bị phòng gym.

* \<Hội viên\>: Đăng nhập để xem thông tin cá nhân, trạng thái gói tập, lịch sử thanh toán, thông báo và danh sách PT hiện có của phòng gym. 

* \<Huấn luyện viên/PT\>: Có thông tin hồ sơ được hiển thị cho hội viên, bao gồm chuyên môn, kinh nghiệm, số điện thoại, trạng thái làm việc và mô tả cá nhân. 

**Danh sách các tính năng chính**

* **Tính năng 1 (Xác thực & Phân quyền):** Đăng nhập, đăng xuất và phân quyền người dùng theo vai trò (Admin, Nhân viên, Hội viên, PT).
* **Tính năng 2 (Quản lý Hội viên):** Thêm mới, cập nhật thông tin, tìm kiếm, xem trạng thái gói tập, ngày bắt đầu và ngày hết hạn.
* **Tính năng 3 (Quản lý Gói tập):** Tạo gói tập tháng/năm, cập nhật giá, thời hạn và mô tả dịch vụ đi kèm.
* **Tính năng 4 (Đăng ký & Gia hạn):** Quản lý đăng ký gói tập và gia hạn thẻ cho hội viên.
* **Tính năng 5 (Đăng ký dịch vụ PT):** Quản lý thuê PT: Hội viên chọn PT, chọn gói dịch vụ PT (1 tháng, 3 tháng, 1 năm).
* **Tính năng 6 (Quản lý Lịch PT):** Quản lý lịch làm việc của PT và sắp xếp lịch tập với hội viên (chống trùng lịch).
* **Tính năng 7 (Quản lý Thiết bị):** Lưu trữ thông tin thiết bị, trạng thái sử dụng, ngày mua, thời hạn bảo hành và lịch bảo trì.
* **Tính năng 8 (Quản lý Bảng tin):** Đăng và quản lý thông báo, bài viết và chính sách của phòng gym.
* **Tính năng 9 (Quản lý Thanh toán):** Ghi nhận giao dịch tiền mặt, quản lý hóa đơn (in hóa đơn) và tra cứu lịch sử thanh toán.
* **Tính năng 10 (Báo cáo & Thống kê):** Thống kê tăng trưởng hội viên, doanh thu chi tiết (gói tập & PT) và tình trạng thiết bị. 

**4\. Đăng ký công nghệ**

| Danh mục | Chi tiết công nghệ / Dịch vụ | Ghi chú / Phiên bản cụ thể |
| :---- | :---- | :---- |
| **Công nghệ lập trình**  | **Front-end: HTML, CSS, Javascript, JSP Back-end: Java Servlet** | **HTML5, CSS3 Java Web** |
| **Hệ quản trị CSDL (DBMS)**  | **SQL Server** | **SQL Server Management Studio 2022** |
| **Quản lý mã nguồn (Git)**  | **Link GitLab/GitHub: \[[https://github.com/Linh181596/Manage-Gym-s-Room.git](https://github.com/Linh181596/Manage-Gym-s-Room.git)\]** | **Phải thiết lập quyền truy cập cho tất cả thành viên và Mentor (hanhnt84@fpt.edu.vn) .** |

