# Implementation Plan: Update Package Management Business Logic

## Goal
Update all software requirements (SRS), system design specifications (SDS), architectural documents, and test cases to reflect the newly established business rules for Gym Package Management (Register, Renew, Transfer):
1. **Transfer Constraint**: Transfer minimum 6 months (180 days), max 12 months (360 days). Must be a multiple of 30 days. Transfer applies from a calculated `Transfer Start Date` up to the `End Date`.
2. **Transfer Fee**: Fixed at 5,000 VNĐ per transferred day.
3. **Accumulative Duration**: Renew operations accumulate days onto the existing `End Date` rather than creating parallel package records.
4. **Registration Restriction**: "Register" is strictly for members without any package history. Members with active/expired packages must use "Renew".

---

## Proposed Changes

### 1. SRS Document (`srs_document.md`)
*   **Business Rules (Section 5.1)**:
    *   **Modify `BR-CONS-18`**: Clarify that transfer requires `remainDays >= 180` and must be transferred in blocks of 30 days (6-12 months) starting from a specific target date to the end date.
    *   **Add `BR-COMP-xx`**: Define the fixed transfer fee calculation (60k/month).
    *   **Add `BR-CONS-xx`**: Define the constraint that members with existing package records must use Renew, blocking them from the Register flow.
*   **Use Case List (Section 1.3.2)**:
    *   **UC-15 & UC-18**: Review and subtly update descriptions to emphasize "duration accumulation" and "1-person-1-package" concepts.
*   **Use Case Descriptions (Section 2.4.2 & 2.4.3)**:
    *   **Register Package**: Update Preconditions (`Member DOES NOT own any package`). Add alternative flow for blocking existing members.
    *   **Renew Package**: Update normal flow to describe updating the existing `EndDate`.
    *   **Transfer Package**: Update normal flow to include "select transfer months (6-12)", "calculate transfer start date", and "generate fixed fee invoice".

### 2. SDS Document (`sds_document.md`)
*   Update section descriptions (e.g., State Diagrams, Sequence Diagram summaries) to reflect the shift from `INSERT MemberPackage` to `UPDATE MemberPackage (EndDate)` for renewals and transfers.

### 3. Architecture & Review Documents
*   **`review code\register_package.md`**: Update the step-by-step logic to include the validation step that blocks users with an existing package history.
*   **`review code\renew_transfer_package.md`**: 
    *   *Renew*: Explain the transition to `UPDATE MemberPackages SET EndDate = ...`.
    *   *Transfer*: Detail the calculation `TransferStartDate = EndDate - (months * 30)` and the fixed fee invoice generation.

### 4. Sequence Diagrams
*   **`sequence_diagram\register_package_sequence.md`**: Add an `alt` block to reject the registration if the member already has a package.
*   **`sequence_diagram\renew_transfer_package_sequence.md`**: Update the DB interaction lifelines. Renew will show an `UPDATE` query. Transfer will show the `TransferStartDate` calculation and two `UPDATE` queries (or one update, one insert for the receiver).

### 5. Swimlane Activity Diagrams
*   **`swimlane_activity_diagram\register_package_swimlane.md`**: Add a decision diamond: `Has package history? -> Yes -> Show Error`.
*   **`swimlane_activity_diagram\renew_transfer_package_swimlane.md`**: Update the Transfer lane to include "Select N months", "Calculate Start Date", and "Generate Fixed Fee Invoice".

### 6. Test Cases
*   **`testcases\register_package_testcases.md`**: Add a test case verifying the system blocks a member who already has a package.
*   **`testcases\renew_transfer_package_testcases.md`**: 
    *   Add test cases for Renew (verifying `EndDate` addition).
    *   Add test cases for Transfer: Validation failure for < 6 months, success for valid months, verifying `TransferStartDate` cutoff, and verifying the exact fixed transfer fee amount.

---

## User Review Required
> [!IMPORTANT]
> The plan covers 11 files in total. Because the changes are extensive and interconnected, please review the proposed modifications above. If the plan correctly captures all your intended business logic changes, please click **Proceed** so I can begin updating the files sequentially.
