# Tài liệu Thiết kế Chi tiết: Sequence Diagram - Đăng ký Gói Tập (Register Package - UC-16)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho chức năng **Đăng ký Gói Tập (Register Package)** dành cho **Hội viên (Member)** tự thao tác.

---

## 1. Các đối tượng tham gia (Lifelines/Objects)

*   `Member (Actor)`: Người dùng thao tác trên trình duyệt.
*   `portal.jsp` / `package-register.jsp` (View): Các trang giao diện JSP hiển thị động.
*   `MemberRegisterPackageController` (Controller): Servlet tiếp nhận điều hướng HTTP request cho Member.
*   `MemberPackageServiceImpl` (Service): Lớp thực thi nghiệp vụ cốt lõi và kiểm soát giao dịch DB.
*   `GymPackageDAOImpl` (DAO): Lớp truy xuất bảng danh mục gói tập.
*   `MemberPackageDAOImpl` (DAO): Lớp truy xuất lịch sử gói tập đăng ký của hội viên.
*   `InvoiceDAOImpl` (DAO): Lớp truy xuất bảng hóa đơn tài chính.
*   `DBContext` (Utility): Quản lý và cung cấp kết nối từ HikariCP Pool.
*   `SQL Server` (Database): Hệ quản trị cơ sở dữ liệu vật lý.

---

## 2. Sơ đồ Sequence Diagram (Mermaid)

```mermaid
sequenceDiagram
    autonumber
    actor Member as User
    participant View_Menu as portal.jsp
    participant View_Form as package-register.jsp
    participant Controller as Controller
    participant Service as MemberPackageServiceImpl
    participant GymDAO as GymPackageDAOImpl
    participant MPDAO as MemberPackageDAOImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DBContext as DBContext
    participant DB as SQL Server

    %% ==================== LOAD REGISTER DATA (GET REQUEST) ====================
    Note over User, DB: FLOW 1: LOAD REGISTER PAGE (GET /member/register-package)
    
    User->>View_Menu: Click "Register Package"
    activate View_Menu
    View_Menu->>Controller: HTTP GET /member/register-package
    deactivate View_Menu
    activate Controller
    
    Controller->>Service: getActivePackages()
    activate Service
    Service->>GymDAO: getActivePackages()
    activate GymDAO
    GymDAO->>DBContext: getConnection()
    activate DBContext
    DBContext-->>GymDAO: Connection (conn)
    deactivate DBContext
    GymDAO->>DB: SQL SELECT (Get active gym packages)
    activate DB
    DB-->>GymDAO: ResultSet
    deactivate DB
    GymDAO-->>Service: List~GymPackage~
    deactivate GymDAO
    deactivate Service

    Controller-->>View_Form: setAttribute(packages) & Forward
    deactivate Controller
    activate View_Form
    View_Form-->>User: Render interface with Gym Packages and Payment Method selection
    deactivate View_Form

    %% ==================== REGISTER & CREATE PENDING TRANSACTION (POST REQUEST) ====================
    Note over User, DB: FLOW 2: REGISTER PACKAGE (POST)

    User->>View_Form: Select Package, Payment Method and click "Register"
    activate View_Form
    View_Form->>Controller: HTTP POST (packageId, paymentMethod)
    deactivate View_Form
    activate Controller

    Controller->>Service: registerMemberPackage(memberId, packageId, paymentMethod)
    activate Service
    
    Service->>DBContext: getConnection()
    activate DBContext
    DBContext-->>Service: Connection (conn)
    deactivate DBContext

    Service->>DB: conn.setAutoCommit(false) (Start SQL Transaction)
    
    Service->>GymDAO: findById(packageId, conn)
    activate GymDAO
    GymDAO->>DB: SQL SELECT (Get details of Gym Package)
    activate DB
    DB-->>GymDAO: ResultSet
    deactivate DB
    GymDAO-->>Service: GymPackage
    deactivate GymDAO

    Service->>MPDAO: checkMemberPackageHistory(memberId, conn)
    activate MPDAO
    MPDAO->>DB: SQL SELECT count(*)
    activate DB
    DB-->>MPDAO: ResultSet (count)
    deactivate DB
    MPDAO-->>Service: boolean (hasHistory)
    deactivate MPDAO

    alt hasHistory == true
        Service->>DB: conn.rollback()
        Service-->>Controller: throw Exception("Member already has a package history")
        Controller-->>User: Redirect to form with Error
    else hasHistory == false
        Service->>Service: Calculate new package validity (StartDate = Today)
        
        Service->>MPDAO: insertPending(memberPackage, conn)
        activate MPDAO
        MPDAO->>DB: SQL INSERT INTO MemberPackages (Status = 'Pending')
        activate DB
        DB-->>MPDAO: Return Generated MemberPackageID
        deactivate DB
        MPDAO-->>Service: int (memberPackageId)
        deactivate MPDAO

        Service->>InvoiceDAO: insert(invoice, conn)
        activate InvoiceDAO
        InvoiceDAO->>DB: SQL INSERT INTO Invoices (Status = 'Pending', PaymentMethod)
        activate DB
        DB-->>InvoiceDAO: Return Generated InvoiceID
        deactivate DB
        InvoiceDAO-->>Service: int (invoiceId)
        deactivate InvoiceDAO

        alt All INSERT steps succeed
            Service->>DB: conn.commit()
        else SQL error
            Service->>DB: conn.rollback()
        end
        
        Service->>DB: conn.close()
        Service-->>Controller: Invoice (Pending Invoice Object)
        
        alt paymentMethod == "VNPay"
            Controller-->>User: HTTP Redirect to /member/vnpay-create?invoiceId={PendingInvoiceID}
        else paymentMethod == "Cash"
            Controller-->>User: HTTP Redirect to Success Info Page (Waiting for Staff Confirmation)
        end
    end
    
    deactivate Service


