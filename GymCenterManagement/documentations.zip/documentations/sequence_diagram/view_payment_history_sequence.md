﻿# Sơ S đồ Sequence Diagram - Xem Lịch Sử Thanh Toán (View Payment History - UC-19)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho chức năng **Xem lịch sử thanh toán (View Payment History)** dành cho cả hai đối tượng **Staff** và **Admin**.

---

## 1. Sơ đồ 1: Luồng Xem và Lọc Danh Sách Hóa Đơn (GET List)

```mermaid
sequenceDiagram
    autonumber
    actor User as Admin / Staff (User)
    participant Sidebar as dashboard_header.jsp
    participant ViewList as payment-list.jsp
    participant Filter as Filter Script (JS Client)
    participant Auth as AuthenticationFilter
    participant Controller as RecordPaymentController
    participant Service as InvoiceServiceImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DB as SQL Server

    User->>Sidebar: Click "Lịch sử thanh toán" (Admin) or "Thanh toán hóa đơn" (Staff)
    activate Sidebar
    Sidebar->>Auth: HTTP GET /admin/payment-history or /staff/record-payment
    deactivate Sidebar
    activate Auth

    Auth->>Auth: Verify role access permissions (RBAC)
    Note over Auth: Role Admin matches /admin/* <br> Role Staff/Admin matches /staff/*
    Auth->>Controller: Forward to Controller
    deactivate Auth
    activate Controller

    Controller->>Service: getAllInvoices()
    activate Service
    Service->>InvoiceDAO: findAll()
    activate InvoiceDAO
    InvoiceDAO->>DB: SQL SELECT (Get all invoices)
    activate DB
    DB-->>InvoiceDAO: ResultSet
    deactivate DB
    InvoiceDAO-->>Service: List~Invoice~
    deactivate InvoiceDAO
    Service-->>Controller: List~Invoice~
    deactivate Service

    Controller-->>ViewList: setAttribute("invoices") & Forward
    deactivate Controller
    activate ViewList
    ViewList-->>User: Render payment-list.jsp (Dynamic Page Title & Action buttons)
    deactivate ViewList

    %% ==================== CLIENT SIDE FILTER FLOW ====================
    Note over User, Filter: client-side interaction: Filter and search
    User->>ViewList: Inputs search text, select status, or set Date range (Từ ngày - Đến ngày)
    activate ViewList
    ViewList->>Filter: triggers input/change events
    activate Filter
    Filter->>Filter: Loop through each row class="invoice-row"
    Filter->>Filter: Match text against data-search
    Filter->>Filter: Match status against data-status
    Filter->>Filter: Match date range against data-date (YYYY-MM-DD)
    Filter-->>ViewList: Hide/Show rows in real-time (display: none/block)
    deactivate Filter
    ViewList-->>User: Update list table immediately
    deactivate ViewList
```

---

## 2. Sơ đồ 2: Luồng Xem Chi Tiết Giao Dịch Hóa Đơn (GET Detail)

```mermaid
sequenceDiagram
    autonumber
    actor User as Admin / Staff (User)
    participant ViewList as payment-list.jsp
    participant ViewDetail as payment-record-detail.jsp
    participant Auth as AuthenticationFilter
    participant Controller as RecordPaymentController
    participant Service as InvoiceServiceImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DB as SQL Server

    User->>ViewList: Click "Chi tiết" button on an invoice row
    activate ViewList
    ViewList->>Auth: HTTP GET {viewUrl}?invoiceId={id}
    deactivate ViewList
    activate Auth

    Auth->>Auth: Verify role access permissions (RBAC)
    Auth->>Controller: Forward
    deactivate Auth
    activate Controller

    Controller->>Service: getInvoiceById(id)
    activate Service
    Service->>InvoiceDAO: findById(id)
    activate InvoiceDAO
    InvoiceDAO->>DB: SQL SELECT by ID
    activate DB
    DB-->>InvoiceDAO: ResultSet
    deactivate DB
    InvoiceDAO-->>Service: Invoice
    deactivate InvoiceDAO
    Service-->>Controller: Invoice
    deactivate Service

    Controller-->>ViewDetail: setAttribute("invoice") & Forward
    deactivate Controller
    activate ViewDetail
    ViewDetail-->>User: Render payment-record-detail.jsp (Forms hidden for Admin)
    deactivate ViewDetail
```

