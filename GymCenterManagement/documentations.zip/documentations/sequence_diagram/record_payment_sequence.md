﻿# Tài liệu Thiết kế Chi tiết: Sequence Diagram - Ghi Nhận Thanh Toán (Record Payment - UC-17)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho chức năng **Ghi Nhận Thanh Toán (Record Payment)** dành cho nhân viên lễ tân (**Staff**). Thiết kế thể hiện rõ ràng luồng xử lý truy vấn dữ liệu hóa đơn, thiết lập ranh giới giao dịch cơ sở dữ liệu để đồng bộ hóa trạng thái hóa đơn tiền mặt (`Invoices`) và trạng thái gói tập hội viên (`MemberPackages`), cùng cơ chế hỗ trợ in ấn.

---

## 1. Các đối tượng tham gia (Lifelines/Objects)

*   `Staff (Actor)`: Nhân viên lễ tân thực hiện xử lý thanh toán trực tiếp tại quầy.
*   `payment-list.jsp` / `payment-record-detail.jsp` (View): Các trang giao diện hiển thị danh sách hóa đơn và phiếu chi tiết thu tiền.
*   `RecordPaymentController` (Controller): Servlet tiếp nhận điều hướng HTTP request.
*   `InvoiceServiceImpl` (Service): Lớp thực thi nghiệp vụ thanh toán, quản lý Transaction đồng bộ.
*   `InvoiceDAOImpl` (DAO): Lớp truy xuất bảng hóa đơn.
*   `MemberPackageDAOImpl` (DAO): Lớp truy xuất đăng ký gói tập của hội viên.
*   `DBContext` (Utility): Quản lý và cung cấp kết nối từ HikariCP Pool.
*   `SQL Server` (Database): Hệ quản trị cơ sở dữ liệu lưu trữ vật lý.

---

## 2. Sơ đồ Sequence Diagram (Mermaid)

### 2.1. Sơ đồ 1: Luồng Tra Cứu và Hiển Thị Chi Tiết Hóa Đơn (GET Request)

```mermaid
sequenceDiagram
    autonumber
    actor Staff as Staff (Receptionist)
    participant View_List as payment-list.jsp
    participant View_Detail as payment-record-detail.jsp
    participant Controller as RecordPaymentController
    participant Service as InvoiceServiceImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DB as SQL Server

    %% ==================== INVOICE LIST QUERY (GET LIST) ====================
    Note over Staff, DB: FLOW 1: VIEW PENDING INVOICES LIST (GET /staff/record-payment)
    
    Staff->>View_List: Click "Record Payment" menu
    activate View_List
    View_List->>Controller: HTTP GET /staff/record-payment
    deactivate View_List
    activate Controller

    Controller->>Service: getAllInvoices()
    activate Service
    Service->>InvoiceDAO: findAll()
    activate InvoiceDAO
    InvoiceDAO->>DB: SQL SELECT (Get all invoices)
    activate DB
    DB-->>InvoiceDAO: ResultSet
    deactivate DB
    InvoiceDAO-->>Service: List~Invoice~ (List of entities)
    deactivate InvoiceDAO
    deactivate Service

    Controller-->>View_List: setAttribute(invoices) & Forward
    deactivate Controller
    activate View_List
    View_List-->>Staff: Render invoice table (Status Paid/Pending/Cancelled as colored badges)
    deactivate View_List

    %% ==================== INVOICE DETAILS QUERY (GET DETAIL) ====================
    Note over Staff, DB: FLOW 2: VIEW INVOICE DETAILS (GET /staff/record-payment?invoiceId=...)

    Staff->>View_List: Click "Pay" or "Detail" button on an invoice row
    activate View_List
    View_List->>Controller: HTTP GET /staff/record-payment?invoiceId={invoiceId}
    deactivate View_List
    activate Controller

    Controller->>Service: getInvoiceById(invoiceId)
    activate Service
    Service->>InvoiceDAO: findById(invoiceId)
    activate InvoiceDAO
    InvoiceDAO->>DB: SQL SELECT (Get invoice detail by ID)
    activate DB
    DB-->>InvoiceDAO: ResultSet
    deactivate DB
    InvoiceDAO-->>Service: Invoice (Entity)
    deactivate InvoiceDAO
    deactivate Service

    Controller-->>View_Detail: setAttribute(invoice) & Forward
    deactivate Controller
    activate View_Detail
    View_Detail-->>Staff: Display detailed receipt (Receipt Card)
    deactivate View_Detail
```

---

### 2.2. Sơ đồ 2: Luồng Xác Nhận Thanh Toán hoặc Hủy Hóa Đơn (POST Request)

```mermaid
sequenceDiagram
    autonumber
    actor Staff as Staff (Receptionist)
    participant View as payment-record-detail.jsp
    participant Controller as RecordPaymentController
    participant Service as InvoiceServiceImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant MPDAO as MemberPackageDAOImpl
    participant DBContext as DBContext
    participant DB as SQL Server

    Note over Staff, DB: POST ACTION PROCESSING (POST /staff/record-payment)

    Staff->>View: Click "Confirm Payment" (or "Cancel Invoice") button
    activate View
    
    alt Staff selects "Confirm Payment" (Pay Action)
        View->>Controller: HTTP POST /staff/record-payment (invoiceId, action="pay")
        activate Controller
        Controller->>Service: recordCashPayment(invoiceId, staffUserId)
        activate Service
    else Staff selects "Cancel Invoice" (Cancel Action)
        View->>Controller: HTTP POST /staff/record-payment (invoiceId, action="cancel")
        Controller->>Service: cancelInvoice(invoiceId, staffUserId)
        activate Service
    end
    deactivate View

    %% Start connection and DB transaction in Service
    Service->>DBContext: getConnection()
    activate DBContext
    DBContext-->>Service: Connection (conn)
    deactivate DBContext
    Service->>DB: conn.setAutoCommit(false) (Start SQL Transaction)

    Service->>InvoiceDAO: findById(invoiceId, conn)
    activate InvoiceDAO
    InvoiceDAO->>DB: SQL SELECT (Check invoice and 'Pending' condition)
    activate DB
    DB-->>InvoiceDAO: ResultSet
    deactivate DB
    InvoiceDAO-->>Service: Invoice (Current invoice entity)
    deactivate InvoiceDAO

    alt Business Logic 1: Confirm Payment (Pay Action)
        Service->>InvoiceDAO: update(invoice) (Update Status = 'Paid', ProcessedBy = staffUserId, PaymentDate = NOW)
        activate InvoiceDAO
        InvoiceDAO->>DB: SQL UPDATE Invoices
        activate DB
        DB-->>InvoiceDAO: rowCount = 1
        deactivate DB
        InvoiceDAO-->>Service: boolean (true)
        deactivate InvoiceDAO

        opt Associated package is not null (memberPackageId != null)
            Service->>MPDAO: findById(memberPackageId, conn)
            activate MPDAO
            MPDAO->>DB: SQL SELECT (Get pending member package details)
            activate DB
            DB-->>MPDAO: ResultSet
            deactivate DB
            MPDAO-->>Service: MemberPackage (Entity)
            deactivate MPDAO
            
            Service->>MPDAO: update(memberPackage) (Update Status = 'Active')
            activate MPDAO
            MPDAO->>DB: SQL UPDATE MemberPackages
            activate DB
            DB-->>MPDAO: rowCount = 1
            deactivate DB
            MPDAO-->>Service: boolean (true)
            deactivate MPDAO
        end

    else Business Logic 2: Cancel Invoice (Cancel Action)
        Service->>InvoiceDAO: update(invoice) (Update Status = 'Cancelled', ProcessedBy = staffUserId)
        activate InvoiceDAO
        InvoiceDAO->>DB: SQL UPDATE Invoices
        activate DB
        DB-->>InvoiceDAO: rowCount = 1
        deactivate DB
        InvoiceDAO-->>Service: boolean (true)
        deactivate InvoiceDAO

        opt Associated package is not null (memberPackageId != null)
            Service->>MPDAO: delete(memberPackageId, conn) (Soft delete associated package)
            activate MPDAO
            MPDAO->>DB: SQL UPDATE MemberPackages (Set IsDeleted = 1)
            activate DB
            DB-->>MPDAO: rowCount = 1
            deactivate DB
            MPDAO-->>Service: boolean (true)
            deactivate MPDAO
        end
    end

    %% Commit or rollback transaction
    alt SQL operations execute without errors
        Service->>DB: conn.commit() (Commit database changes)
    else SQL error or exception occurs
        Service->>DB: conn.rollback() (Rollback all temporary changes)
    end
    Service->>DB: conn.close() (Return connection to Pool)

    Service-->>Controller: boolean (true/false)
    deactivate Service

    Controller-->>View: HTTP Redirect to /staff/record-payment?invoiceId={invoiceId}&successMsg=Saved
    deactivate Controller
    activate View
    View-->>Staff: Reload invoice details (disable buttons, enable print if Paid)
    deactivate View

