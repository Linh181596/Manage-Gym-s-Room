# Sơ đồ Sequence Diagram - Gia Hạn & Chuyển Nhượng Gói Tập (Renew & Transfer Package - UC-10)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho hai luồng nghiệp vụ: **Gia hạn gói tập** và **Chuyển nhượng gói tập** dành cho nhân viên lễ tân (**Staff**).

---

## 1. Sơ đồ 1: Luồng Gia Hạn Gói Tập (Renew Package)

Sơ đồ dưới đây gộp chung luồng Tải trang nhập liệu gia hạn (GET) và Luồng thực thi đăng ký gia hạn (POST).

```mermaid
sequenceDiagram
    autonumber
    actor Member as Member
    participant Members as portal.jsp
    participant View as package-renew.jsp
    participant Controller as MemberRenewPackageController
    participant MemberDAO as MemberDAOImpl
    participant Service as MemberPackageServiceImpl
    participant GymPkgDAO as GymPackageDAOImpl
    participant PkgDAO as MemberPackageDAOImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DB as SQL Server

    Note over Member, DB: 1. Luồng tải trang nhập liệu gia hạn (GET)
    Member->>Members: Click "Gia hạn" button on an active member row
    activate Members
    Members->>Controller: HTTP GET /member/renew-package
    deactivate Members
    activate Controller

    Controller->>Service: getMemberPackageById(id)
    activate Service
    Service->>PkgDAO: findById(id)
    activate PkgDAO
    PkgDAO->>DB: SQL SELECT (Get member package details)
    activate DB
    DB-->>PkgDAO: ResultSet
    deactivate DB
    PkgDAO-->>Service: MemberPackage
    deactivate PkgDAO
    Service-->>Controller: MemberPackage
    deactivate Service

    Controller-->>View: setAttribute(activePkg) and Forward
    deactivate Controller
    activate View
    View-->>Member: Display renew form (Calculating renew date ranges in real-time)
    deactivate View

    Note over Member, DB: 2. Luồng thực thi đăng ký gia hạn (POST)
    Member->>View: Confirm renewal
    activate View
    View->>Controller: HTTP POST /member/renew-package (memberId, packageId, paymentMethod)
    deactivate View
    activate Controller

    Controller->>MemberDAO: findByUserId(userId)
    activate MemberDAO
    MemberDAO-->>Controller: Member object (or null)
    deactivate MemberDAO

    alt Member does not exist
        Controller-->>Member: Redirect/Forward with error "Không tìm thấy thông tin hội viên."
    else Member exists
        Controller->>Service: getLatestPackageByMemberId(memberId)
        activate Service
        Service-->>Controller: latestPkg
        deactivate Service
        
        alt packageId != latestPkg.packageId OR remaining time > 1 month
            Controller-->>Member: Redirect with error "Gói tập không hợp lệ hoặc thời gian còn lại lớn hơn 1 tháng."
        else Validation passed
            Controller->>Service: renewMemberPackage(memberId, packageId, paymentMethod)
            activate Service
            Note over Service, DB: Database Transaction Boundary (setAutoCommit false)

        Service->>GymPkgDAO: findById(packageId)
        activate GymPkgDAO
        GymPkgDAO-->>Service: GymPackage
        deactivate GymPkgDAO

        alt GymPackage is null OR status != "Active"
            Note over Service, DB: Rollback Transaction
            Service-->>Controller: Return null
            Controller-->>Member: Display error "Gym package not found or is inactive."
        else GymPackage is active
            Service->>Service: Validate no existing Pending transaction for this user
            Service->>Service: Calculate new EndDate (cộng dồn thời hạn mới vào gói hiện tại)
            
            Service->>PkgDAO: updateEndDate(packageId, newEndDate, conn)
            activate PkgDAO
            PkgDAO->>DB: SQL UPDATE MemberPackages SET EndDate = newEndDate
            activate DB
            DB-->>PkgDAO: row count
            deactivate DB
            PkgDAO-->>Service: success
            deactivate PkgDAO

            Service->>InvoiceDAO: insert(newInvoice) (Status: Pending)
            activate InvoiceDAO
            InvoiceDAO->>DB: INSERT INTO Invoices
            activate DB
            DB-->>InvoiceDAO: Return generated InvoiceID
            deactivate DB
            InvoiceDAO-->>Service: newInvoiceId
            deactivate InvoiceDAO

            Note over Service, DB: Commit Transaction
            Service-->>Controller: newInvoice
            deactivate Service

            alt paymentMethod == "VNPay"
                Controller-->>Member: Redirect to /member/vnpay-create?invoiceId={newInvoiceId}
            else paymentMethod == "Cash"
                Controller-->>Member: Redirect to /member/renew-package (Success Message)
            end
            deactivate Controller
        end
        end
    end
```

---

## 2. Sơ đồ 2: Luồng Chuyển Nhượng Gói Tập (Transfer Package)

Sơ đồ dưới đây gộp chung luồng Tải trang chuyển nhượng (GET) và Luồng thực thi chuyển nhượng (POST).

```mermaid
sequenceDiagram
    autonumber
    actor Staff as Staff (Receptionist)
    participant Members as members.jsp
    participant View as package-transfer.jsp
    participant Controller as TransferPackageController
    participant MemberDAO as MemberDAOImpl
    participant Service as MemberPackageServiceImpl
    participant PkgDAO as MemberPackageDAOImpl
    participant InvoiceDAO as InvoiceDAOImpl
    participant DB as SQL Server

    Note over Staff, DB: 1. Luồng tải trang chuyển nhượng (GET)
    Staff->>Members: Click "Chuyển nhượng" button on an active member row
    activate Members
    Members->>Controller: HTTP GET /staff/package/transfer?senderPkgId={id}
    deactivate Members
    activate Controller

    Controller->>Service: getMemberPackageById(id)
    activate Service
    Service->>PkgDAO: findById(id)
    activate PkgDAO
    PkgDAO->>DB: SQL SELECT (Get sender's package info)
    activate DB
    DB-->>PkgDAO: ResultSet
    deactivate DB
    PkgDAO-->>Service: MemberPackage (Sender)
    deactivate PkgDAO
    Service-->>Controller: MemberPackage
    deactivate Service

    Controller-->>View: setAttribute(senderPkg) and Forward
    deactivate Controller
    activate View
    View-->>Staff: Display transfer form (Search receiver member box)
    deactivate View

    Note over Staff, DB: 2. Luồng thực thi chuyển nhượng (POST)
    Staff->>View: Search receiver, click "Xác nhận chuyển nhượng"
    activate View
    View->>Controller: HTTP POST /staff/package/transfer (senderPkgId, receiverId, note)
    deactivate View
    activate Controller

    Controller->>MemberDAO: findByUserId() for sender & receiver
    activate MemberDAO
    MemberDAO-->>Controller: sender (Member), receiver (Member)
    deactivate MemberDAO

    Controller->>Service: transferMemberPackage(senderPkgIdStr, receiver.getMemberId(), staffUserId, note)
    activate Service
    Note over Service, DB: Database Transaction Boundary (setAutoCommit false)

    Service->>PkgDAO: findActiveByMemberId(sender.MemberId)
    activate PkgDAO
    PkgDAO-->>Service: MemberPackage (Sender)
    deactivate PkgDAO

    Service->>Service: Validate sender has no existing Pending transfer invoice for this package
    Service->>Service: Validate receiver has no existing Pending transaction for any package
    Service->>Service: Calculate remainingDays based on effectiveStartDate and EndDate
    Service->>Service: Calculate end date for receiver (StartDate = effectiveStartDate, EndDate = effectiveStartDate + remainingDays)

    Service->>PkgDAO: insert(newReceiverPackage) (Status: Pending)
    activate PkgDAO
    PkgDAO->>DB: INSERT INTO MemberPackages (Receiver)
    activate DB
    DB-->>PkgDAO: Return generated ID
    deactivate DB
    PkgDAO-->>Service: receiverPkgId
    deactivate PkgDAO

    Service->>InvoiceDAO: insert(transferInvoice) (Status: Pending, Amount: 5000 * remainingDays)
    activate InvoiceDAO
    InvoiceDAO->>DB: INSERT INTO Invoices
    activate DB
    DB-->>InvoiceDAO: Return generated InvoiceID
    deactivate DB
    InvoiceDAO-->>Service: invoiceId
    deactivate InvoiceDAO

    Note over Service, DB: Commit Transaction
    Service-->>Controller: invoiceId
    deactivate Service

    Controller-->>Staff: Redirect to /staff/record-payment?invoiceId={invoiceId}
    deactivate Controller
```

