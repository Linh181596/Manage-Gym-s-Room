﻿# Tài liệu Thiết kế Chi tiết: Sequence Diagram - Quản lý Gói Tập (Manage Package - UC-15)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho chức năng **Quản lý Gói Tập (Manage Package)** dành cho quản trị viên (**Admin**). Tài liệu phân tách luồng thành 4 sơ đồ tuần tự độc lập đại diện cho quy trình CRUD: Xem danh sách (Read), Tạo mới (Create), Cập nhật (Update), và Xóa mềm (Soft Delete).

---

## 1. Các đối tượng tham gia (Lifelines/Objects)

*   `Admin (Actor)`: Quản trị viên thực hiện các thao tác trên hệ thống.
*   `package-list.jsp` / `package-form.jsp` (View): Các trang giao diện JSP hiển thị dữ liệu và nhập liệu.
*   `ManagePackageController` (Controller): Servlet tiếp nhận điều hướng HTTP request.
*   `GymPackageServiceImpl` (Service): Lớp thực thi nghiệp vụ CRUD.
*   `GymPackageDAOImpl` (DAO): Lớp truy xuất bảng danh mục gói tập.
*   `DBContext` (Utility): Quản lý và cung cấp kết nối từ HikariCP Pool.
*   `SQL Server` (Database): Hệ quản trị cơ sở dữ liệu lưu trữ bảng `GymPackages`.

---

## 2. Sơ đồ Sequence Diagram (Mermaid)

### 2.1. Luồng Xem Danh Sách Gói Tập (Read)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Admin
    participant View as package-list.jsp
    participant Controller as ManagePackageController
    participant Service as GymPackageServiceImpl
    participant DAO as GymPackageDAOImpl
    participant DBContext as DBContext
    participant DB as SQL Server

    Admin->>View: Click "Gym Package Management" menu
    activate View
    View->>Controller: HTTP GET /admin/packages?action=list
    deactivate View
    activate Controller

    Controller->>Service: getAllPackages()
    activate Service
    Service->>DAO: findAll()
    activate DAO
    DAO->>DBContext: getConnection()
    activate DBContext
    DBContext-->>DAO: Connection (conn)
    deactivate DBContext
    DAO->>DB: SQL SELECT (Get gym packages where IsDeleted = 0)
    activate DB
    DB-->>DAO: ResultSet
    deactivate DB
    DAO-->>Service: List~GymPackage~ (List of entities)
    deactivate DAO
    deactivate Service

    Controller-->>View: setAttribute(packages) & Forward
    deactivate Controller
    activate View
    View-->>Admin: Display gym package list table
    deactivate View
```

---

### 2.2. Luồng Tạo Mới Gói Tập (Create)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Admin
    participant View_List as package-list.jsp
    participant View_Form as package-form.jsp
    participant Controller as ManagePackageController
    participant Service as GymPackageServiceImpl
    participant DAO as GymPackageDAOImpl
    participant DB as SQL Server

    Admin->>View_List: Click "Create New" button
    activate View_List
    View_List->>Controller: HTTP GET /admin/packages?action=create
    deactivate View_List
    activate Controller
    Controller-->>View_Form: Forward (Empty Form)
    deactivate Controller
    activate View_Form
    View_Form-->>Admin: Display empty input Form interface
    deactivate View_Form

    Admin->>View_Form: Fill in details and click "Save"
    activate View_Form
    View_Form->>View_Form: Validate Client-side (Ensure valid input values)
    View_Form->>Controller: HTTP POST /admin/packages (Form data without ID)
    deactivate View_Form
    activate Controller

    Controller->>Controller: Validate Server-side & Extract Admin Name from Session
    Controller->>Service: createPackage(pkg)
    activate Service
    Service->>DAO: insert(pkg)
    activate DAO
    DAO->>DB: SQL INSERT (Add new record, CreatedBy = AdminName, IsDeleted = 0)
    activate DB
    DB-->>DAO: Return Generated PackageID
    deactivate DB
    DAO-->>Service: boolean (true)
    deactivate DAO
    deactivate Service

    Controller-->>Admin: HTTP Redirect to /admin/packages?successMsg=Created Successfully
    deactivate Controller
```

---

### 2.3. Luồng Chỉnh Sửa Gói Tập (Update)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Admin
    participant View_List as package-list.jsp
    participant View_Form as package-form.jsp
    participant Controller as ManagePackageController
    participant Service as GymPackageServiceImpl
    participant DAO as GymPackageDAOImpl
    participant DB as SQL Server

    Admin->>View_List: Click "Edit" button on a package row
    activate View_List
    View_List->>Controller: HTTP GET /admin/packages?action=edit&id={packageId}
    deactivate View_List
    activate Controller

    Controller->>Service: getPackageById(packageId)
    activate Service
    Service->>DAO: findById(packageId)
    activate DAO
    DAO->>DB: SQL SELECT (Get existing package details)
    activate DB
    DB-->>DAO: ResultSet
    deactivate DB
    DAO-->>Service: GymPackage (Entity)
    deactivate DAO
    deactivate Service
    Controller-->>View_Form: setAttribute(pkg) & Forward (Populate existing data)
    deactivate Controller
    activate View_Form
    View_Form-->>Admin: Display Form interface with existing data
    deactivate View_Form

    Admin->>View_Form: Modify details and click "Save"
    activate View_Form
    View_Form->>View_Form: Validate Client-side
    View_Form->>Controller: HTTP POST /admin/packages (Form data with hidden packageId)
    deactivate View_Form
    activate Controller

    Controller->>Controller: Validate Server-side & Extract Admin Name from Session
    Controller->>Service: updatePackage(pkg)
    activate Service
    Service->>DAO: update(pkg)
    activate DAO
    DAO->>DB: SQL UPDATE (Modify record, UpdatedBy = AdminName, UpdatedDate = NOW)
    activate DB
    DB-->>DAO: rowCount = 1 (Update successful)
    deactivate DB
    DAO-->>Service: boolean (true)
    deactivate DAO
    deactivate Service

    Controller-->>Admin: HTTP Redirect to /admin/packages?successMsg=Updated Successfully
    deactivate Controller
```

---

### 2.4. Luồng Xóa Mềm Gói Tập (Soft Delete)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Admin
    participant View as package-list.jsp
    participant Controller as ManagePackageController
    participant Service as GymPackageServiceImpl
    participant DAO as GymPackageDAOImpl
    participant DBContext as DBContext
    participant DB as SQL Server

    Admin->>View: Click "Delete" button on the corresponding package row
    activate View
    View->>View: Display Bootstrap Modal Confirmation asking for verification
    Admin->>View: Click "Confirm Delete"
    View->>Controller: HTTP GET /admin/packages?action=delete&id={packageId}
    deactivate View
    activate Controller

    Controller->>Service: deletePackage(packageId)
    activate Service
    Service->>DAO: delete(packageId)
    activate DAO
    DAO->>DBContext: getConnection()
    activate DBContext
    DBContext-->>DAO: Connection (conn)
    deactivate DBContext
    DAO->>DB: SQL UPDATE (Set IsDeleted = 1 for corresponding PackageID)
    activate DB
    DB-->>DAO: rowCount = 1 (Confirm modification)
    deactivate DB
    DAO-->>Service: boolean (true)
    deactivate DAO
    deactivate Service

    Controller-->>Admin: HTTP Redirect to /admin/packages?successMsg=Deleted Successfully
    deactivate Controller
```

