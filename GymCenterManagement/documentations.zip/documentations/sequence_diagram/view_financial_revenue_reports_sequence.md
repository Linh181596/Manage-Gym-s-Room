# Tài liệu Thiết kế Chi tiết: Sequence Diagram - Xem Báo Cáo Tài Chính & Doanh Thu (View Financial & Revenue Reports - UC-20)

Tài liệu này mô tả chi tiết sơ đồ tuần tự (Sequence Diagram) cho chức năng **Xem Báo Cáo Tài Chính & Doanh Thu (View Financial & Revenue Reports)** dành cho quản trị viên (**Admin**). Dữ liệu doanh thu được tích hợp và hiển thị trực tiếp trên trang Dashboard của Admin thông qua biểu đồ trực quan.

---

## 1. Các đối tượng tham gia (Lifelines/Objects)

*   `Admin (Actor)`: Quản trị viên truy cập hệ thống.
*   `dashboard.jsp` (View): Trang giao diện JSP của Admin chứa các biểu đồ hiển thị doanh thu (sử dụng thư viện Chart.js).
*   `AdminDashboardController` (Controller): Servlet tiếp nhận yêu cầu truy cập Dashboard của Admin.
*   `DashboardServiceImpl` (Service): Lớp thực thi nghiệp vụ tổng hợp thống kê, xử lý danh sách điểm dữ liệu thành JSON để phục vụ việc vẽ biểu đồ.
*   `DashboardDAOImpl` (DAO): Lớp truy xuất cơ sở dữ liệu để lấy số liệu thống kê.
*   `DBContext` (Utility): Quản lý và cung cấp kết nối từ HikariCP Pool.
*   `SQL Server` (Database): Hệ quản trị cơ sở dữ liệu.

---

## 2. Sơ đồ Sequence Diagram (Mermaid)

```mermaid
sequenceDiagram
    autonumber
    actor Admin
    participant View as dashboard.jsp
    participant Controller as AdminDashboardController
    participant Service as DashboardServiceImpl
    participant DAO as DashboardDAOImpl
    participant DB as SQL Server
    
    Admin->>View: Truy cập trang Admin Dashboard (Click menu)
    activate View
    View->>Controller: HTTP GET /admin/dashboard
    deactivate View
    activate Controller
    
    Controller->>Service: getAdminDashboardData()
    activate Service
    
    Service->>DAO: getRevenueTrend(REVENUE_DAYS)
    activate DAO
    
    DAO->>DB: Thực thi Query tổng hợp (SQL SELECT GROUP BY Date, SUM(Amount))
    activate DB
    DB-->>DAO: ResultSet (Dữ liệu doanh thu theo ngày)
    deactivate DB
    
    DAO-->>Service: List<RevenuePoint>
    deactivate DAO
    
    Service->>Service: Điền các ngày bị thiếu (fillMissingRevenueDays)
    Service->>Service: Trích xuất JSON Labels & Values cho Chart.js
    Service->>Service: Đóng gói vào đối tượng AdminDashboardData
    
    Service-->>Controller: AdminDashboardData
    deactivate Service
    
    Controller-->>View: setAttribute("dashboardData") & Forward
    deactivate Controller
    activate View
    
    View->>View: Render biểu đồ doanh thu bằng JS (truyền chuỗi JSON vào cấu hình biểu đồ)
    
    View-->>Admin: Hiển thị Bảng điều khiển (Dashboard) với số liệu & biểu đồ tài chính
    deactivate View
```
