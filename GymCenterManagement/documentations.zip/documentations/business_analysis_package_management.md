# Tài Liệu Phân Tích Nghiệp Vụ - Quản Lý Gói Tập (Register, Renew, Transfer)

Dựa trên các yêu cầu nghiệp vụ mới nhất mà bạn cung cấp, tài liệu này sẽ phân tích các sai sót, lỗ hổng trong luồng hoạt động hiện tại của hệ thống GCMS, đồng thời đánh giá tính khả thi và cung cấp các đề xuất thiết kế để vá lại các thiếu sót này.

---

## 1. Phân Tích Yêu Cầu Nghiệp Vụ Mới
Các rule (quy tắc) mới được đề xuất:
1. **Chuyển nhượng (Transfer)**: Tối thiểu 6 tháng (180 ngày), tối đa 12 tháng (360 ngày). Quy ước 1 tháng = 30 ngày. Không cho phép chuyển nhượng số ngày lẻ (ví dụ: dư 15 ngày, hoặc 6.5 tháng).
2. **Cộng dồn thời hạn**: Khi đăng ký (nếu nối tiếp), gia hạn, hoặc nhận chuyển nhượng, hệ thống chỉ cộng dồn thời hạn (Duration). 
3. **Mô hình 1-1 (1 Người - 1 Gói)**: Một hội viên chỉ sở hữu duy nhất một gói tập (thời hạn). Không hiển thị tên nhiều gói tập mà chỉ hiển thị **Tổng thời hạn (số ngày/tháng) còn lại**.
4. **Phí chuyển nhượng**: Cố định là 5,000 VNĐ / ngày chuyển nhượng.
5. **Chặn đăng ký mới (Register)**: Đã có gói tập (đang Active hoặc Expired nhưng vẫn còn trên hệ thống) thì không được đăng ký gói mới, chỉ được phép đi theo luồng **Gia hạn (Renew)** để cộng dồn ngày.

---

## 2. Các Sai Sót & Lỗ Hổng Của Hệ Thống Hiện Tại

Dựa vào mã nguồn và tài liệu hiện có của luồng `Register` và `Renew & Transfer`:

> [!WARNING]
> **Lỗ hổng 1: Không có ràng buộc giới hạn thời gian chuyển nhượng**
> Hiện tại, ở hàm `transferMemberPackage()`, hệ thống chỉ kiểm tra `remainDays = EndDate - Today > 0` là cho phép chuyển nhượng toàn bộ số ngày này cho người khác. Điều này dẫn đến việc hội viên có thể "pass" lẻ 5 ngày, 10 ngày, làm hệ thống bị lạm dụng và phát sinh chi phí quản lý vô ích, gây thất thu.

> [!WARNING]
> **Lỗ hổng 2: Phí chuyển nhượng tùy chỉnh (Nhân viên tự nhập)**
> Theo tài liệu hiện tại, "Phí tùy chỉnh do Staff nhập" khi tạo hóa đơn `Pending`. Điều này là một **lỗ hổng cực kỳ nghiêm trọng** về mặt tài chính. Nhân viên có thể thông đồng với hội viên nhập phí chuyển nhượng bằng 0 hoặc số tiền rất nhỏ để gian lận.

> [!WARNING]
> **Lỗ hổng 3: Dữ liệu phân mảnh, cho phép nhiều gói song song**
> Mặc dù `Register` có kiểm tra gói active gần nhất, nhưng nếu luồng `Register` vẫn mở cho người đã có gói, hệ thống sẽ chèn thêm một record mới vào bảng `MemberPackages`. Điều này đi ngược lại định hướng "1 người 1 gói duy nhất" và gây khó khăn cho việc cộng dồn thời gian.

> [!CAUTION]
> **Lỗ hổng 4: Logic "Nhận chuyển nhượng toàn bộ" bị vỡ**
> Nếu hệ thống hiện tại đang tự động lấy toàn bộ `remainDays` của người gửi để chuyển cho người nhận, thì khi áp dụng luật "tối thiểu 6, tối đa 12 tháng, không pass lẻ", nếu người gửi còn 200 ngày (6 tháng 20 ngày), họ chỉ được phép chuyển 6 tháng (180 ngày). Giao diện và API hiện tại chưa hỗ trợ người gửi **chọn số tháng muốn chuyển**, dẫn đến việc mất trắng hoặc không thể chuyển 20 ngày lẻ còn lại.

---

## 3. Các Nghiệp Vụ Trên Có Đủ Vá Thiếu Sót Không?

Các rule mới **rất xuất sắc và thực tế**, giải quyết triệt để bài toán doanh thu và chống gian lận. Tuy nhiên, để hệ thống hoạt động trơn tru mà không bị lỗi logic, **chưa đủ**, bạn cần bổ sung thêm các ràng buộc phái sinh sau:

1. **Quy tắc trích xuất thời gian chuyển nhượng (Transfer by specific date)**: 
   - Gói được chuyển nhượng sẽ tính từ một **ngày chỉ định** cho đến **End Date** của người gửi. 
   - Tổng thời gian từ ngày chỉ định đến End Date phải nằm trong khoảng từ 6 đến 12 tháng (180 đến 360 ngày) và **bắt buộc phải là bội số của 30 ngày (không lẻ)**.
   - *Ví dụ:* A có hạn đến 31/12 (còn 200 ngày tính từ hôm nay). A muốn chuyển 6 tháng (180 ngày) cho B. Ngày chỉ định bắt buộc phải là ngày cách 31/12 đúng 180 ngày (tức là 20 ngày sau kể từ hôm nay). Khi đó, A sẽ kết thúc gói sớm vào đúng ngày chỉ định (tập nốt 20 ngày đầu). B sẽ được cộng dồn 180 ngày kể từ ngày chỉ định.
2. **Quy tắc làm tròn tháng**: 
   - 1 tháng = 30 ngày. Số tháng được chuyển nhượng `N` nằm trong `[6, 12]`.
   - Giao diện chuyển nhượng cho phép **chọn số tháng N (6, 7, 8... 12)**. Hệ thống tự động tính ra **Ngày chỉ định (Transfer Start Date)** = `EndDate - (N * 30)`. Ngày chỉ định này phải đảm bảo >= Ngày hiện tại.
3. **Thanh toán phí chuyển nhượng**: 
   - Hóa đơn phí chuyển nhượng sẽ được gán cứng công thức: `Fee = Số ngày chuyển * 5,000 VNĐ`.
4. **Hợp nhất luồng Register & Renew**:
   - Nếu "đã đăng ký không thể đăng ký tiếp, chỉ có thể gia hạn", thì về bản chất cơ sở dữ liệu `MemberPackages` của một user chỉ nên có **đúng 1 dòng dữ liệu (record)**. 
   - Khi gia hạn, hệ thống chạy lệnh `UPDATE MemberPackages SET EndDate = DATEADD(day, X, EndDate)`.
   - Giao diện Register sẽ chỉ hiển thị cho tài khoản User hoàn toàn mới (chưa từng mua gói nào).

---

## 4. Kế Hoạch Tái Cấu Trúc (Re-design Plan)

### A. Tầng Database (Cơ sở dữ liệu)
- **Bảng `MemberPackages`**: Không cần tạo record mới khi gia hạn. Chỉ cần cập nhật cột `EndDate` (Cộng dồn số ngày).
- Nếu bắt buộc phải lưu lịch sử mua gói (để truy vết), hãy tạo bảng `TransactionHistory` riêng, còn bảng `MemberPackages` vẫn duy trì quan hệ 1-1 với `Members`.

### B. Tầng Business Logic (Service Layer)

1. **Luồng Đăng ký (Register)**:
   - *Validation*: `SELECT COUNT(*) FROM MemberPackages WHERE MemberID = ?`. Nếu `> 0`, lập tức chặn và redirect sang luồng Renew.

2. **Luồng Gia hạn (Renew)**:
   - Cho phép chọn các mức gia hạn (Ví dụ: 1 tháng, 3 tháng, 6 tháng, 1 năm). 
   - *Logic*: Lấy `EndDate` hiện tại (nếu đang Active) cộng thêm `(Số tháng * 30) ngày`. Nếu `EndDate` đã qua trong quá khứ, lấy `Ngày hiện tại (Today) + (Số tháng * 30) ngày`.

3. **Luồng Chuyển nhượng (Transfer)**:
   - *Validation 1*: Người gửi phải có tổng số ngày còn lại `remainDays >= 180` (tối thiểu 6 tháng).
   - *Input*: Nhận tham số `transferMonths` (từ 6 đến 12).
   - *Logic Ngày Chỉ Định*: Tính toán `TransferStartDate = EndDate - (transferMonths * 30)`.
   - *Validation 2*: `TransferStartDate >= Today` (hoặc `transferMonths * 30 <= remainDays`). Đảm bảo không chuyển nhượng quá số ngày hiện có.
   - *Invoice*: Sinh hóa đơn phí chuyển nhượng = `remainingDays * 5,000`.
   - *Transaction*: 
     - Cập nhật người gửi: `UPDATE MemberPackages SET EndDate = TransferStartDate`. (Người gửi kết thúc gói sớm tại ngày chỉ định).
     - Cập nhật người nhận: Nhận thêm `transferMonths * 30` ngày. Tương tự hàm Renew, cộng dồn vào `EndDate` của người nhận. Cần lưu ý người nhận cũng chỉ được có tối đa 1 gói.

### C. Tầng View (Giao diện JSP)
- **Dashboard Hội Viên**: Thay đổi giao diện, ẩn tên gói tập gốc. Hiển thị một đồng hồ đếm ngược hoặc text: **"Thời gian tập luyện còn lại: 195 ngày (~ 6.5 tháng)"**.
- **Màn hình Transfer**: Thêm thanh trượt (slider) hoặc Dropdown box cho phép Staff chọn số tháng chuyển nhượng (6 -> 12). Hiển thị tức thời (Live calculation) phí chuyển nhượng = Số tháng * 60k để Staff thu tiền.
